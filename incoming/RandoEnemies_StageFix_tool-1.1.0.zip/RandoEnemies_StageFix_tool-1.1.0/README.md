# Phase A `.stage` fix: stage tool 1.1.0 and stage Lua 1.1.0 (v0.76-DEV4, kit 10.0.43)

**Status: built and statically verified. Not installed. Not run in the game.** The static checks show the file is a correct, minimal and self-consistent change. They cannot show how the game behaves with it.

## 1. What is in this folder

| Folder | Contents |
|---|---|
| `candidate/` | **The new build.** It contains `RandoEnemies.stage`, `18_rando_stage_manifest.lua`, `stage_enemies_manifest.json`, `STATIC_VERIFICATION.txt`, `BYTE_DIFF.txt` and `poc_candidates.json`. The tool's backup of the original zone is not included because it is byte-identical to the backup you already have (sha256 `e6b22e71…0edcf`). |
| `kit_changes/` | Only the kit files I changed or added, at their kit paths. Copy this folder over your v0.76-DEV4 kit folder. |
| `kit_changes.patch` | The same changes as a diff against the kit zip you uploaded. |
| `verification/` | The output of every command and test run for this report, plus `independent_check.py`, a checker that shares no code with the tool. |

Game files to install: `candidate/RandoEnemies.stage`, `candidate/18_rando_stage_manifest.lua`, and the two updated scripts `kit_changes/scripts/16_rando_spawners.lua` and `kit_changes/scripts/18_rando_stage_enemies.lua`. The tool does the copying; see section 8.

## 2. The change in the candidate

| | |
|---|---|
| Zone | `levels\i29\instance\ardolis\ardolis_main\ard_firstvisit_gp.zone`, id `AE530D22FE113E2B`, span 0, 539268 bytes |
| Spawner | `CECB812E81FB7301`: Script Actions #387, class `2E910F8C`, Script Plugs #460 `Templates`, Script Vars #153. That plug is the variable's only plug in the zone. |
| Entry | Zone Script Vars +4896, zone +413760, 32 bytes |
| Original | uid `899208BF8F48C554`, index **15**: Zone Actors #15 `TEMPLATE_PIRATE_SHOOTER_V2`, asset `enm_pirate_robot_shooter.actor` |
| Corrected | uid `92C793D47A4657B6`, index **25**: Zone Actors #25 `TEMPLATE_PIRATE_MELEE_V2`, asset `enm_pirate_robot_melee.actor` |
| Bytes | **9** in total. Zone +413764: `0F` → `19` (the index). Zone +413776..+413783: the uid. Inside the `.stage` member, add 36 to each offset. |
| Entry before | `05 00 FF FF 0F 00 FF FF  FF 17 91 F3 D5 E7 1B A6  54 C5 48 8F BF 08 92 89  00…00` |
| Entry after | `05 00 FF FF 19 00 FF FF  FF 17 91 F3 D5 E7 1B A6  B6 57 46 7A D4 93 C7 92  00…00` |
| `.stage` | sha256 `fd93536cb2f740f68d32a52b423377ad6faa0ab58b839d676a01dc2f7b494ec2`. Members: `info.json` (game RCRA) and `0/AE530D22FE113E2B` (original 36-byte header + zone). |
| Zone sha256 | Original `d40540ed…e016`, which is what your probe read. Patched `3618346c…d774`. |

The replacement uid with index 25 is exactly the reference factory `E6705A36656EB7B9` already has (SV #799). That factory spawned brawlers on every load in your logs.

The build is reproducible: building again gives the same sha256 on this Python. If you rebuild on Windows the zip hash will differ, but the zone member will not. Compare `zone_sha256_patched` instead.

## 3. Static verification (full list in `candidate/STATIC_VERIFICATION.txt`, result: PASS)

These checks run on both the original zone and the patched zone. Every one passes.

- **Sections and record sizes.** All 26 sections are inside DAT1, none overlap and all tags are unique. Record counts: Script Vars 1048 × 32, Script Plugs 2020 × 12, Script Actions 926 × 40, Zone Actors 586 × 32, actor-asset table 67 × 12, Actor Names 508 × 4.
- **Indices.** Every plug points at an existing Script Vars entry. Every action's plug range lies inside the plug table. Action keys are unique. Every plug belongs to exactly one action (2020 of 2020).
- **Template identity.** For all 67 actor-asset entries, CRC64 of the stored path equals the stored id. Zone Actors indices are in range and no uid appears twice.
- **C1 (every actor reference consistent).** 648 type-5 entries, all of a known form: 302 local (uid and index agree), 23 external, 251 group, 72 empty. Zero problems before and after the patch.
- **C2 (ownership).** Only one plug in the zone points at SV #153: #460 `Templates`, owned by CECB812E81FB7301. The tool refuses the 30 `Templates` variables that another node also reads.
- **C3 (identity from the zone).** Zone Actors → actor-asset table → path: shooter → brawler. A registry or log name that disagreed would stop the build.
- **C4 (entry form).** Plain local form (type 5, aux FFFF, aux2 FFFF, tail 0) before and after.
- **C5 (byte diff).** Every changed byte is in the index or uid of that one entry. Size, the 36-byte header, the DAT1 header and the section table are byte-identical.
- **Loadable.** The header's block sizes still add up to the zone (`[520784, 18484]` = 539268), so rivet_hook can load it.
- **Read-back.** The written `.stage` reads back to the same header and zone.

Independent check (`verification/independent_check_output.txt`, own zip, DAT1, CRC32, CRC64 and table code): **PASS**. It also confirms that SV #153 is the one inconsistent reference in the 1.0.1 POC.

The 1.0.1 POC now **fails** both `verify` and `check-zone`:

> `Script Vars #153 (zone +413760): INCONSISTENT REFERENCE: uid 92C793D47A4657B6 is Zone Actors record 25 (enm_pirate_robot_melee) but the index field says record 15 (enm_pirate_robot_shooter)`

## 4. Corrections to the root-cause analysis

The root cause itself stands. Two details of the analysis change:

1. **Script Plugs records start at +0, not +8.** They are `{u32 plug name hash, u32 Script Vars index, u32 kind}`, and 2020 of them fill the section exactly. Read from +0, the two plug ranges in each action (+18/+20 and +22/+24) cover every plug exactly once, and all 43 factory nodes have one `Templates` plug. Read from +8, as `refs153.py`, `nodes.py` and `ref_consistency_check.py` do, only 37 of 43 do. Every plug read from +8 is shifted by one record. For CECB812E81FB7301 the shift stays inside its own range (#459–465), so the ownership conclusion was right, but by luck.
2. **The actor-asset table (`78684035`) is 67 × u64 id followed by 67 × u32 path offset**, not 100 × u64. Each stored path's CRC64 equals its id (67/67). This proves the layout and the CRC64 on the zone itself, so the hand-typed `KNOWN` tables in `actors.py` and `index_check.py` are no longer needed.

The other weaknesses you listed are all fixed in `zone.py`:

- Sections come from the table, so no offsets are hard-coded.
- Duplicate uids are found and kept out of the uid map, which makes references to them "ambiguous".
- Every size, bound and count is checked.
- Ownership is enforced, not just printed.
- CRC32 is validated four ways. The bitwise form (`wiring.py`) and the table form agree. `Templates` = 3990217346, the game's value. Seven plug names stored as strings in the zone hash to the plug hashes in the same zone. The engine hash is not standard CRC-32 (zlib gives a different value).

## 5. What changed in the code (`kit_changes/`, `kit_changes.patch`)

- **`tools/stage_enemies/zone.py` (new).** It decodes the zone tables listed above with every rule checked. A reference is treated as {uid, index}. It also provides:
  - `plan_swap`: refuses anything except a single-owner `Templates` variable that points at a local template of the same zone, with a unique uid.
  - `compare_zones`: accepts only differences in the index and uid fields of consistent references.
- **`stage_enemies.py` 1.1.0.** This is the existing pipeline, not a second tool.
  - `probe` decodes every zone.
  - `poc` writes both halves of the reference, with identity taken from the zone. It takes `--spawner`, `--replacement` and `--original`, refuses an `--out` folder that already holds a build, and writes `STATIC_VERIFICATION.txt` and `BYTE_DIFF.txt`.
  - `verify` decodes the game's zone and the `.stage` zone. It checks the manifest and that the game's scripts folder has 16 and 18 at stage Lua 1.1.0, and no longer needs `--log`.
  - `install` runs `verify` first and stops on any problem. It keeps an already-installed `.stage` as `.bak-*`.
  - New `check-zone` command works without a game folder.
- **`knowledge.py`**: movement family looked up by kind name, used only when every source agrees. **`rcra.py`**: label for the unnamed section. **`fakegame.py`**: synthetic zones with the real layouts.
- **`scripts/16_rando_spawners.lua` (stage Lua 1.1.0).**
  - It reads the uid of the actor behind a variable's handle (`rivet.uid`). A mismatch logs `RANDO-ERROR TEMPLATE REFERENCE MISMATCH`, and that template is never marked MIXED, never written to the registry and never used as a replacement.
  - A spawner the installed `.stage` changed never writes the registry or MIXED, even when `rivet.uid` does not answer.
  - If `rivet.uid` answers something else entirely (4 disagreements and no agreement in a session), the check turns itself off and says so, instead of flagging every template.
- **`scripts/18_rando_stage_enemies.lua` (stage Lua 1.1.0).**
  - New log line `STAGE REFERENCE … AGREE / DISAGREE` for the patched spawner. This is R1 from the root-cause report.
  - Every `STAGE SPAWN` line now includes the handle's uid.
  - It reports an error if the manifest was built by tool < 1.1.0 or if 16 has a different stage Lua version.
- **`dev_scripts/dev(reg_repair).lua` (new, optional).** See section 7.
- **Tests:**
  - `tests/v076dev4/test_stage_zone_fix.py` (new).
  - `tests/v076dev4/test_stage_lua_fix.py` (new).
  - `tests/v076dev4/mirror.py` (new test helper).
  - `selftest.py` rewritten for the real layouts.
  - `test_stage_dev4.py` updated to the 1.1.0 manifest fields.
- **Also updated:** `tools/validate_dev_zip.py` (new file list), `docs/STAGE_ENEMY_RANDOMIZER.md` (new section 9), `docs/CHANGELOG.md`, `tools/stage_enemies/README.md`, `tests/v076dev4/README.txt`.

Kit stamps stay at 10.0.43 because 16 and 18 are the only scripts that changed.

### Tests (outputs in `verification/`)

| Test | Result |
|---|---|
| `stage_enemies.py selftest` | 63 checks, 0 failed |
| `test_stage_zone_fix.py --zone … --old-stage … --new-stage …` | 60 PASS, 0 failures. Covers the real zone: 1.0.1 fails, 1.1.0 passes; uid-only and index-only edits are refused; shared and external variables are refused. |
| `test_stage_lua_fix.py` (lupa) | 28 PASS, 0 failures |
| `test_stage_dev4.py` and all v076dev2, v076 and dev8 suites | 0 failures |
| `validate_dev_zip.py` on a full kit zip including these changes | VALIDATION PASSED (103 files, every test from a fresh extraction) |

## 6. Why `18_rando_stage_enemies.lua` did not run (item 12)

- **It was not in `<game>\scripts` when the game started.** The script always logs a `RANDO-STAGE` line when it runs: either "16 … is not installed" or "loaded (10.0.43)". Your log had none. rivet_hook reported `loaded 20 of 20 scripts`, so it was not a load error either: the file was simply not there (19 kit scripts + manifest + dev(debug) would be 21).
- **Nothing warned you.** `10_rando_runtime.lua` lists 18 in `R.DEV_ONLY_OPTIONAL`, and the kit check never names a missing file on that list (that is deliberate for player packages). Tool 1.0.1's `install` only checked that 18 existed at the moment you installed. Nothing at game start checked it.
- **When or how it went missing** (for example, refreshing the scripts folder after installing) cannot be told from what I have here: the POC-session rivet.log was not in this upload.
- **What now prevents a repeat:**
  - `verify` and `install` refuse unless `<game>\scripts` holds 16 and 18 from this kit, both at stage Lua 1.1.0.
  - In the game, if the manifest is present and 18 is not loaded, 16 logs `RANDO-ERROR STAGE CHECK MISSING` and shows a message on screen.

## 7. The false `|mixed` entry for `92C793D47A4657B6` (item 13)

**How it happened:**

1. `V.tpl_of(handle, uid)` named the template from the variable's uid, which the save's registry knows as the brawler.
2. The handle came from index 15, so the game spawned a shooter.
3. `V.learn` saw two kinds from one template and marked it MIXED.
4. `V.reg_put` wrote `…|mixed` into the save's `enemy_reg`.

**Effect:** the runtime (Lua) route will never use this genuine brawler template in that save. In `.stage` mode it has no effect. The 1.1.0 Lua cannot create such an entry again (section 5).

**The cleanup is read-only unless you opt in:**

- With the new 16, every save load logs `registry: template 92C793D47A4657B6 is stored as "…|mixed": a FALSE mixed mark … Read-only: nothing changed.`
- To clear it:
  1. Back up `Documents\Ratchet & Clank - Rift Apart`.
  2. Copy `kit_changes/dev_scripts/dev(reg_repair).lua` into `<game>\scripts`.
  3. Start the game and load the save. Check for `registry: CLEARED the false MIXED mark` in rivet.log.
  4. Save once, then delete the file.
- It removes **only** the `|mixed` suffix of that one uid, and only when the stored value starts with `enm_pirate_robot_melee|swarmer|` and has no `|hb`. Any other value is left alone and logged. Every other entry is untouched; the tests cover this.

I have not seen your save. The expected stored value (`enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy|mixed`) is inferred from the `V.reg_put` format and your DEV3 learn line.

## 8. Installing (when you choose to; nothing here was installed)

1. Copy `kit_changes/` over your kit folder. Then copy `scripts\16_rando_spawners.lua` and `scripts\18_rando_stage_enemies.lua` into `<game>\scripts`.
2. Copy `candidate\` somewhere in the kit, for example `poc_out_1.1.0\`. Do not put it over your old `poc_out`.
3. Run:
   ```
   python tools\stage_enemies\stage_enemies.py verify  --game "E:\Users\Ray\Desktop\Games\Ratchet.and.Clank.Rift.Apart Modded" --stage poc_out_1.1.0\RandoEnemies.stage
   python tools\stage_enemies\stage_enemies.py install --game "E:\Users\Ray\Desktop\Games\Ratchet.and.Clank.Rift.Apart Modded" --build poc_out_1.1.0
   ```
   `verify` re-reads your real toc, so it catches a game update. It also checks the scripts and rivet.toml. `install` runs `verify` again before copying anything. It keeps the installed 1.0.1 `mods\RandoEnemies.stage` as `.bak-*` and replaces `scripts\18_rando_stage_manifest.lua`.

The candidate was built from your original zone bytes (backup sha256 `e6b22e71…`, zone sha256 `d40540ed…` = your probe) through a one-zone stand-in game folder, because your game is not available here. If you rebuild it yourself, use `poc --spawner CECB812E81FB7301 --replacement 92C793D47A4657B6 --out <new folder>`. Without your rivet.log the ranking alone would pick a different spawner.

## 9. What was not touched

- **Game, rivet.toml, saves:** no access from this workspace at all. Nothing was installed, read or written.
- **Previous POC build and backup:** the uploads are read-only and unchanged (sha256 below). The extracted copies of the POC `.stage`, backup and manifests are byte-identical to the zip members. `verify` and `check-zone` only read them.
- **Previous builds:** every new output went to new folders, and `poc` now refuses to write into a folder that already holds a build.

| Upload | sha256 |
|---|---|
| `RandoEnemies_POC_v0.76-DEV4.zip` | `b1093919025045019582bb389c4731992e38926097ea0c34d911a1b8219f175d` |
| `…Scripts-Only-stagetool-1.0.1.zip` | `24a268cdbbede33595e2c2fc1aee093f47b6aa44a8a2781e196a9c5c3abe942f` |
| `RandoEnemies_POC_RootCause.zip` | `3c9db20d68577fa34ff8473d5f22df55acf559ab8cc431ac7bdfed4221199bd2` |
| `ROOT_CAUSE_REPORT.md` | `039acbc5993c2156a0b02f1a14f7876bacdee56715382e702ab3c56c2f4b64b2` |
| POC `RandoEnemies.stage` (1.0.1) | `0264377a3524e4294b591852a6aafbb3d449fb0840ada5fe692bc5de9c76a527` |
| POC `backup/AE530D22FE113E2B.zone.orig` | `e6b22e71f4d4a51a7107ea59239dd0a507f7447fef82ec6a33f090202fc0edcf` |

## 10. Limits

- **Still not observed in the game:** that the engine resolves the reference through the index (handle). That is the inference from your logs (E6705A36656EB7B9 vs CECB812E81FB7301), and both halves now agree, so the build no longer depends on which half the game reads. The new `STAGE REFERENCE` line will show it directly when you next run it.
- **Not checked statically:** other Script Vars consumers outside the plug table, such as Script Priuses. Ownership is proven through the plug table, which covers every plug exactly once.
- **Pair behaviour:** the shooter → brawler pair is combat-verified in the Zurkon arena, not at this spawn point.
- **Repository:** attaching the private dev repo was refused again, so these changes are not pushed. They are in `kit_changes/` and `kit_changes.patch`.
