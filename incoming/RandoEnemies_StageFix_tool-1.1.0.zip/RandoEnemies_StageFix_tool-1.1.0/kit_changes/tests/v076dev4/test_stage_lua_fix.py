# Stage tool 1.1.0, the Lua side: a handle/uid disagreement can no longer poison the template registry as MIXED; the
# patched spawner's reference is checked in the game (R1); a manifest without 18_rando_stage_enemies.lua is an error;
# the false "|mixed" registry entry of 92C793D47A4657B6 is only reported unless dev(reg_repair).lua is present.
# Same fake-memory harness as test_stage_dev4.py.  Run from the kit folder:  python tests/v076dev4/test_stage_lua_fix.py .
import os
import sys

from lupa import LuaRuntime

KIT = sys.argv[1] if len(sys.argv) > 1 else "."
sys.path.insert(0, os.path.join(KIT, "tools", "stage_enemies"))
import stage_enemies as SE  # noqa: E402

fails = 0


def check(c, m):
    global fails
    print(("PASS " if c else "FAIL ") + m)
    if not c:
        fails += 1


MEM, WRITES, UIDS = {}, [], {}


def put(a, bs):
    for i, b in enumerate(bs):
        MEM[a + i] = b


def py_read(addr, n):
    a = int(str(addr), 16)
    out = []
    for i in range(int(n)):
        if a + i not in MEM:
            break
        out.append("%02X" % MEM[a + i])
    return " ".join(out) if out else None


def py_write(addr, text):
    a = int(str(addr), 16)
    WRITES.append((a, str(text)))
    put(a, [int(x, 16) for x in str(text).split()])
    return True


def py_uid(h):
    return UIDS.get(int(h))


BASE, VS = 0x10000000, 0x40
SH, ME, SW = ("enm_pirate_robot_shooter", "ground", 11, "899208BF8F48C554"), ("enm_pirate_robot_melee", "swarmer", 12, "92C793D47A4657B6"), \
             ("enm_pirate_robot_melee_b", "swarmer", 13, "AF0189E66C49DA08")


def set_var(idx, uid_hex, actors, gen=1, typ=5):
    a = BASE + idx * VS
    put(a, [0] * VS)
    put(a, list(bytes.fromhex(uid_hex))[::-1])
    put(a + 0x10, list(actors.to_bytes(4, "little")))
    put(a + 0x34, list(typ.to_bytes(2, "little")))
    put(a + 0x36, list(gen.to_bytes(2, "little")))


def make(with_uid=True, load18=True, reg=None, repair=False, config_extra=""):
    MEM.clear()
    WRITES.clear()
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals()
    LOG, SAID, CHANGED = [], [], []
    g.py_log = lambda *a: LOG.append("\t".join(str(x) for x in a))
    g.py_say = lambda t, *a: SAID.append(str(t))
    g.py_changed = lambda: CHANGED.append(1)
    g.py_read, g.py_write, g.py_uid = py_read, py_write, py_uid
    lua.execute('rivet = setmetatable({ log = function(...) py_log(...) end, read = function(a, n) return py_read(a, n) end, '
                'write = function(a, t) return py_write(a, t) end %s }, { __index = function() return function() return nil end end })'
                % (", uid = function(h) return py_uid(h) end" if with_uid else ", uid = false"))
    for f in ("01_rando_data.lua", "02_rando_generator.lua"):
        lua.execute(open(os.path.join(KIT, "scripts", f), encoding="utf-8").read())
    lua.execute('RANDO = { config = { enemy_compat = "killable", enemy_randomizer = true %s }, state = { enemy_combat = {}, enemy_reg = {} }, '
                'mark_changed = function() py_changed() end, say = function(t) py_say(t) end, subscribe = function() end }' % config_extra)
    for uid, v in (reg or {}).items():
        lua.execute('RANDO.state.enemy_reg["%s"] = "%s"' % (uid, v))
    if repair:
        lua.execute(open(os.path.join(KIT, "dev_scripts", "dev(reg_repair).lua"), encoding="utf-8").read())
    lua.execute(open(os.path.join(KIT, "scripts", "16_rando_spawners.lua"), encoding="utf-8").read())
    if load18:
        lua.execute(open(os.path.join(KIT, "scripts", "18_rando_stage_enemies.lua"), encoding="utf-8").read())
    lua.execute('''
local V = RANDO_SPAWNERS.V
SC = { base = %d, max = 64 }
V.scene = function() return SC end
V.enabled = function() return true end
V.role_on = function() return true end
RANDO_SPAWNERS.frame = 100
''' % BASE)
    return lua, LOG, SAID, CHANGED


def level(lua):
    lua.execute('''
local V = RANDO_SPAWNERS.V
V.new_level("planet Ardolis")
V.lvl.scans = 1
for i = 1, 3 do V.add_rec({ kind = "factory", actor = 900 + i, key = "F" .. i, var = { idx = i, gen = 1 } }) end
for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end
''')


def spawn(lua, rec_i, h, kind):
    """V.process_one for a spawn of spawner F<rec_i> that made `kind` (the real spawn path, call site included)."""
    lua.execute('''local V = RANDO_SPAWNERS.V
local e = { h = %d, fac = 0, resolved = true, r = V.lvl.order[%d], a = { name = "%s", family = "%s", class = "x" }, A = false }
V.process_one(SC, e)''' % (h, rec_i, kind[0], kind[1]))


def manifest(lua, tool="1.1.0"):
    m = {"label": "test", "stage_sha256": "00", "changes": [{
        "zone": "levels/ard/z.zone", "zone_id": "AE530D22FE113E2B", "section": "Zone Script Vars", "entry_rel": 4896, "var_index": 153,
        "original_uid": SH[3], "original_index": 15, "original": SH[0], "original_family": SH[1],
        "replacement_uid": ME[3], "replacement_index": 25, "replacement": ME[0], "replacement_family": ME[1],
        "original_refs_in_script_vars": 1, "replacement_refs_in_script_vars": 1,
        "pair": "factory|enm_pirate_robot_sh/ground>enm_pirate_robot_me/swarmer", "spawner_keys": ["F1"]}]}
    src = SE.manifest_lua(m)
    if tool != "1.1.0":
        src = src.replace('tool = "1.1.0"', 'tool = "%s"' % tool)
    lua.execute(src)


reg_of = lambda lua, u: lua.eval('RANDO.state.enemy_reg["%s"]' % u)

# 0. both files say stage Lua 1.1.0 (the tool's install / verify look for exactly this)
src16 = open(os.path.join(KIT, "scripts", "16_rando_spawners.lua"), encoding="utf-8").read()
src18 = open(os.path.join(KIT, "scripts", "18_rando_stage_enemies.lua"), encoding="utf-8").read()
check(SE.STAGE_LUA_RE.search(src16).group(1) == SE.STAGE_LUA == SE.STAGE_LUA_RE.search(src18).group(1),
      "16 and 18 carry stage Lua %s, the value stage_enemies.py install / verify require" % SE.STAGE_LUA)

# 1. the POC, reproduced WITHOUT the fix's input (rivet.uid not answering, no manifest): the old false MIXED
for with_uid, label in ((False, "rivet.uid not answering"), (True, "rivet.uid answering")):
    UIDS.clear()
    UIDS.update({11: SH[3], 12: ME[3], 13: SW[3]})
    lua, LOG, SAID, CH = make(with_uid=with_uid, reg={ME[3]: "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy"})
    set_var(1, ME[3], 11)       # the POC: the brawler's uid, the SHOOTER's handle (index 15 -> handle of record 15)
    set_var(2, ME[3], 12)       # E6705A36656EB7B9: brawler uid, brawler handle
    set_var(3, SH[3], 11)
    level(lua)
    spawn(lua, 1, 7001, SH)
    if not with_uid:
        check(reg_of(lua, ME[3]).endswith("|mixed") and any("MIXED, never used" in l for l in LOG),
              "%s, no manifest: the 1.0.1 behaviour stays for an UNPROVEN case (genuinely mixed templates are still marked)" % label)
    else:
        check(reg_of(lua, ME[3]) == "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy",
              "%s, no manifest: the brawler template is NOT marked MIXED (registry unchanged)" % label)
        check(any("RANDO-ERROR TEMPLATE REFERENCE MISMATCH" in l and ME[3] in l and SH[3] in l for l in LOG),
              "%s: the disagreement is a RANDO-ERROR naming the variable uid and the handle's uid" % label)
        check(not any("MIXED, never used" in l for l in LOG), "%s: no 'MIXED, never used' line" % label)
        check(lua.eval("RANDO_SPAWNERS.V.usable(RANDO_SPAWNERS.V.lvl.tpl[11])") is False,
              "%s: the template behind the inconsistent reference is never used as a replacement" % label)
        check(lua.eval("RANDO_SPAWNERS.V.lvl.tpl[11].name") == SH[0], "%s: it is named after the handle's uid (a shooter)" % label)

# 2. .stage mode: a spawner the .stage changed never teaches the registry, even when rivet.uid does not answer
UIDS.clear()
lua, LOG, SAID, CH = make(with_uid=False, reg={ME[3]: "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy"})
manifest(lua)
set_var(1, ME[3], 11)
set_var(2, ME[3], 12)
set_var(3, SH[3], 11)
level(lua)
spawn(lua, 1, 7002, SH)
check(reg_of(lua, ME[3]) == "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy" and not any("MIXED, never used" in l for l in LOG),
      ".stage mode, patched spawner F1, rivet.uid silent: NOT marked MIXED, registry unchanged")
check(any("NOT marked MIXED" in l and "teaches the registry nothing" in l for l in LOG), ".stage mode: the log says why nothing was learned")
n_reg = lua.eval("(function() local n = 0 for _ in pairs(RANDO.state.enemy_reg) do n = n + 1 end return n end)()")
spawn(lua, 2, 7003, ME)
check(lua.eval("(function() local n = 0 for _ in pairs(RANDO.state.enemy_reg) do n = n + 1 end return n end)()") == n_reg,
      ".stage mode: an unpatched spawner still learns as before (no change to the registry here: it already knew)")

# 3. R1 in 18_rando_stage_enemies.lua: AGREE / DISAGREE / not answered
for case, var1, hu, want in (("corrected .stage", (ME[3], 12), ME[3], "uid and Zone Actors index AGREE"),
                             ("1.0.1 POC .stage", (ME[3], 11), SH[3], "RANDO-ERROR STAGE REFERENCE"),
                             ("no rivet.uid answer", (ME[3], 12), None, "NOT checked")):
    UIDS.clear()
    if hu:
        UIDS.update({var1[1]: hu})
    lua, LOG, SAID, CH = make(with_uid=hu is not None)
    manifest(lua)
    set_var(1, *var1)
    set_var(2, SH[3], 11)
    set_var(3, SW[3], 13)
    level(lua)
    lua.execute("RANDO_SPAWNERS.V.stage_tick(100, true, true)")
    check(any("STAGE REFERENCE factory F1" in l and want in l for l in LOG), "R1, %s: %s" % (case, want))
    if case == "1.0.1 POC .stage":
        spawn(lua, 1, 7004, SH)
        check(any("STAGE SPAWN 7004" in l and "handle uid %s" % SH[3] in l and "uid and index disagree" in l for l in LOG),
              "R1, 1.0.1 POC: STAGE SPAWN says the original spawned because the handle is the original's actor")

# 4. a manifest without 18_rando_stage_enemies.lua is an error (the POC ran this way, silently)
lua, LOG, SAID, CH = make(load18=False)
manifest(lua)
level(lua)
lua.execute("pcall(RANDO_SPAWNERS.V.tick, 100, true)")
check(any("RANDO-ERROR STAGE CHECK MISSING" in l for l in LOG) and any("18_rando_stage_enemies.lua is missing" in s for s in SAID),
      "manifest installed, 18 not loaded: RANDO-ERROR in rivet.log and a note on screen")
lua.execute("pcall(RANDO_SPAWNERS.V.tick, 101, true)")
check(sum("STAGE CHECK MISSING" in l for l in LOG) == 1, "... said once")
lua, LOG, SAID, CH = make(load18=True)
manifest(lua)
level(lua)
lua.execute("pcall(RANDO_SPAWNERS.V.tick, 100, true)")
check(not any("STAGE CHECK MISSING" in l for l in LOG) and any("STAGE MODE ON" in l for l in LOG), "with 18 loaded: no such error, STAGE MODE ON")
lua, LOG, SAID, CH = make(load18=True)
manifest(lua, tool="1.0.1")
lua.execute("RANDO_SPAWNERS.V.stage_tick(100, true, true)")
check(any("RANDO-ERROR this .stage was built by stage tool 1.0.1" in l for l in LOG), "a manifest of tool 1.0.1 is reported as the malformed POC build")
lua = LuaRuntime(unpack_returned_tuples=True)
LOG2 = []
lua.globals().py_log = lambda *a: LOG2.append("\t".join(str(x) for x in a))
lua.execute('rivet = setmetatable({ log = function(...) py_log(...) end }, { __index = function() return function() return nil end end })')
lua.execute('RANDO_SPAWNERS = { V = { stage_mode = function() return false end, STAGE_LUA = "1.0.0" } }')
lua.execute(src18)
check(any("RANDO-ERROR 16_rando_spawners.lua is stage Lua 1.0.0" in l for l in LOG2), "18 with an older 16: RANDO-ERROR")

# 5. the false |mixed registry entry: read-only by default, cleared only with dev(reg_repair).lua, only that value
FALSE = "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy|mixed"
OTHER = {"8416CF7558A4694D": "enm_pirate_robot_shooter|ground|GameBotShooter|enemy",
         "1234567812345678": "enm_x|ground|X|enemy|mixed"}
lua, LOG, SAID, CH = make(reg=dict(OTHER, **{ME[3]: FALSE}))
lua.execute("pcall(RANDO_SPAWNERS.V.tick, 100, true)")
check(reg_of(lua, ME[3]) == FALSE and not any("CLEARED" in l for l in LOG) and all(reg_of(lua, u) == v for u, v in OTHER.items()),
      "no dev(reg_repair).lua: the false entry and every other entry are NOT changed")
check(any("FALSE mixed mark" in l and "Read-only" in l for l in LOG), "no dev(reg_repair).lua: rivet.log names the false entry and how to clear it")
lua, LOG, SAID, CH = make(reg=dict(OTHER, **{ME[3]: FALSE}), repair=True)
lua.execute("pcall(RANDO_SPAWNERS.V.tick, 100, true)")
n0 = len(CH)
check(reg_of(lua, ME[3]) == "enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy" and n0 > 0, "dev(reg_repair).lua: the |mixed suffix is removed, the save marked changed")
check(all(reg_of(lua, u) == v for u, v in OTHER.items()), "dev(reg_repair).lua: every other entry untouched (another MIXED one included)")
check(any("CLEARED the false MIXED mark" in l for l in LOG), "dev(reg_repair).lua: the clear is logged")
check(lua.eval('RANDO_SPAWNERS.V.reg_get("%s").mixed' % ME[3]) is False, "after the repair the registry reads the template as usable again")
for bad in ("enm_pirate_robot_melee|swarmer|GameBotMeleeSwarmer|enemy|hb|mixed", "enm_pirate_robot_shooter|ground|GameBotShooter|enemy|mixed"):
    lua, LOG, SAID, CH = make(reg={ME[3]: bad}, repair=True)
    lua.execute("pcall(RANDO_SPAWNERS.V.tick, 100, true)")
    check(reg_of(lua, ME[3]) == bad and any("unexpected value" in l for l in LOG), "an unexpected stored value is left alone: %s" % bad)

# 6. rivet.uid answering something else for template actors: the check switches itself off (no mass false alarms)
UIDS.clear()
UIDS.update({11: "AAAAAAAAAAAAAAA1", 12: "AAAAAAAAAAAAAAA2", 13: "AAAAAAAAAAAAAAA3", 14: "AAAAAAAAAAAAAAA4", 15: "AAAAAAAAAAAAAAA5"})
lua, LOG, SAID, CH = make()
lua.execute('''local V = RANDO_SPAWNERS.V
V.new_level("x")
for h = 11, 15 do V.tpl_of(h, string.format("%016X", h)) end''')
check(any("template handle check OFF for this session" in l for l in LOG)
      and lua.eval("RANDO_SPAWNERS.V.lvl.tpl[15].ref_mismatch") is None,
      "rivet.uid never agreeing: after %d disagreements the handle check is off for the session" % 4)

print("FAILURES", fails)
sys.exit(1 if fails else 0)
