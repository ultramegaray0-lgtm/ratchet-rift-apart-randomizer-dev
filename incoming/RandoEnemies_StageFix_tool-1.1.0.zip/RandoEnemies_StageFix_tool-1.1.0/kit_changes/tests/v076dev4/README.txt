v0.76-DEV4 offline tests (Python 3 + lupa: pip install lupa). Run from the kit folder:
  python tests/v076dev4/test_stage_dev4.py .                    the Lua side of the .stage Enemy Randomizer: every script
                                                               compiles; no manifest = the runtime route unchanged; a manifest
                                                               = no runtime spawner write (variable route, V.arm, Chaos slots),
                                                               earlier changes put back; STAGE VARIABLE / SPAWN / DEATH / SUMMARY
                                                               tell a loaded .stage from one that did not load; enemy_source
  python tools/stage_enemies/stage_enemies.py selftest          the companion: asset ids against the game's own, LZ4 against the
                                                               reference compressor, probe -> poc -> verify -> install ->
                                                               uninstall on a synthetic game folder, every refusal
  python tests/v076dev4/test_stage_zone_fix.py . [--zone poc_out/backup/AE530D22FE113E2B.zone.orig] [--old-stage <1.0.1 .stage>] [--new-stage <1.1.0 .stage>]
                                                               stage tool 1.1.0: zone decoding, bounds, duplicates, ownership,
                                                               hashes; with --zone the real Ardolis zone (1.0.1 POC fails, 1.1.0 passes)
  python tests/v076dev4/test_stage_lua_fix.py .                stage Lua 1.1.0 (lupa): no false MIXED, R1 STAGE REFERENCE, missing
                                                               18 reported, dev(reg_repair) only clears the false entry
  tests/v076dev4/mirror.py                                     a one-zone stand-in game folder from a poc backup (test helper)
The tests in tests/v076dev2, tests/v076 and tests/dev8 still apply (dev8 test_gen and dev9 test_owned need older kit folders).
