# v0.76-DEV4 .stage Enemy Randomizer, the Lua side: .stage mode never writes a spawner, the runtime route is unchanged
# without a manifest, and 18_rando_stage_enemies.lua tells a loaded .stage from one that was not loaded.
# Same harness as tests/v076dev2/test_enemy_dev2.py (a fake scene of script variables in memory).
# Run from the kit folder:  python tests/v076dev4/test_stage_dev4.py .
import os
import sys

from lupa import LuaRuntime

KIT = sys.argv[1] if len(sys.argv) > 1 else "."
sys.path.insert(0, os.path.join(KIT, "tools", "stage_enemies"))
import stage_enemies as SE  # noqa: E402  (the manifest the tool writes is the one tested here)

fails = 0


def check(c, m):
    global fails
    print(("PASS " if c else "FAIL ") + m)
    if not c:
        fails += 1


MEM = {}


def put(a, bs):
    for i, b in enumerate(bs):
        MEM[a + i] = b


def py_read(addr, n):
    a = int(str(addr), 16)
    out = []
    for i in range(int(n)):
        if a + i not in MEM:
            break
        out.append("%02X" % MEM[a + i])
    return " ".join(out) if out else None


WRITES = []


def py_write(addr, text):
    a = int(str(addr), 16)
    WRITES.append((a, str(text)))
    put(a, [int(x, 16) for x in str(text).split()])
    return True


BASE, VS = 0x10000000, 0x40


def set_var(idx, uid_hex, actors, gen=1, typ=5):
    a = BASE + idx * VS
    put(a, [0] * VS)
    put(a, list(bytes.fromhex(uid_hex))[::-1])
    put(a + 0x10, list(actors.to_bytes(4, "little")))
    put(a + 0x34, list(typ.to_bytes(2, "little")))
    put(a + 0x36, list(gen.to_bytes(2, "little")))


def get_var(idx):
    a = BASE + idx * VS
    uid = "".join("%02X" % MEM[a + i] for i in range(7, -1, -1))
    act = int.from_bytes(bytes(MEM[a + 0x10 + i] for i in range(4)), "little")
    return uid, act


KINDS = [("enm_neo_nefarious_shooter", "ground", 11, "00000000000000B1"),
         ("enm_neo_nefarious_melee", "swarmer", 12, "00000000000000B2"),
         ("enm_neo_nefarious_swarmer", "swarmer", 13, "00000000000000B3")]


def make(config_extra=""):
    MEM.clear()
    WRITES.clear()
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals()
    LOG, SAID = [], []
    g.py_log = lambda *a: LOG.append("\t".join(str(x) for x in a))
    g.py_say = lambda t, *a: SAID.append(str(t))
    g.py_read, g.py_write = py_read, py_write
    lua.execute('rivet = setmetatable({ log = function(...) py_log(...) end, read = function(a, n) return py_read(a, n) end, '
                'write = function(a, t) return py_write(a, t) end }, { __index = function() return function() return nil end end })')
    for f in ("01_rando_data.lua", "02_rando_generator.lua"):
        lua.execute(open(os.path.join(KIT, "scripts", f), encoding="utf-8").read())
    lua.execute('RANDO = { config = { enemy_compat = "killable", enemy_randomizer = true %s }, state = { enemy_combat = {} }, '
                'mark_changed = function() end, say = function(t) py_say(t) end, subscribe = function() end }' % config_extra)
    lua.execute(open(os.path.join(KIT, "scripts", "16_rando_spawners.lua"), encoding="utf-8").read())
    lua.execute(open(os.path.join(KIT, "scripts", "18_rando_stage_enemies.lua"), encoding="utf-8").read())
    lua.execute('''
local V = RANDO_SPAWNERS.V
SC = { base = %d, max = 64 }
V.scene = function() return SC end
V.enabled = function() return true end
V.role_on = function() return true end
RANDO_SPAWNERS.frame = 100
''' % BASE)
    return lua, LOG, SAID


def level(lua, label):
    lua.execute('''
local V = RANDO_SPAWNERS.V
V.new_level("%s")
V.lvl.scans = 1
for i = 1, 3 do V.add_rec({ kind = "factory", actor = 900 + i, key = "F" .. i, var = { idx = i, gen = 1 } }) end
for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end
''' % label)
    for n, fam, h, uid in KINDS:
        lua.execute('''local V = RANDO_SPAWNERS.V
local T = V.tpl_of(%d, "%s"); T.name, T.family, T.class = "%s", "%s", "x"; T.role = V.role_of(T)''' % (h, uid, n, fam))


def plan(lua):
    lua.execute("local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.plan_rec(SC, r) end")


def install_manifest(lua, spawner_keys=("F1",)):
    m = {"label": "test", "stage_sha256": "00", "changes": [{
        "zone": "levels/test/z.zone", "zone_id": "8000000000000001", "section": "Zone Script Vars", "entry_rel": 64, "var_index": 2,
        "original_uid": KINDS[1][3], "original_index": 1, "original": KINDS[1][0], "original_family": KINDS[1][1],
        "replacement_uid": KINDS[2][3], "replacement_index": 2, "replacement": KINDS[2][0], "replacement_family": KINDS[2][1],
        "original_refs_in_script_vars": 1, "replacement_refs_in_script_vars": 1,
        "pair": "factory|enm_neo_nefarious_m/swarmer>enm_neo_nefarious_s/swarmer", "spawner_keys": list(spawner_keys)}]}
    lua.execute(SE.manifest_lua(m))


for f in sorted(os.listdir(os.path.join(KIT, "scripts"))) + ["../dev_scripts/" + x for x in sorted(os.listdir(os.path.join(KIT, "dev_scripts")))]:
    if f.endswith(".lua"):
        L = LuaRuntime()
        src = open(os.path.join(KIT, "scripts", f), encoding="utf-8").read()
        ok = L.eval("function(s, n) local f, e = load(s, n) return f ~= nil, e end")(src, f)
        if not ok[0]:
            check(False, "compiles: %s: %s" % (f, ok[1]))
check(fails == 0, "every script and developer script compiles (Lua 5.4)")

# 1. no manifest: the runtime route is unchanged
lua, LOG, SAID = make()
for i, (n, fam, h, uid) in enumerate(KINDS):
    set_var(i + 1, uid, h)
level(lua, "planet NefCity")
check(lua.eval("RANDO_SPAWNERS.V.stage_mode()") is False, "no manifest, enemy_source auto: not .stage mode")
plan(lua)
check(lua.eval("#RANDO_SPAWNERS.V.lvl.arms") >= 2, "no manifest: the runtime route still changes spawners (Nefarious for Nefarious)")
lua.execute("RANDO_SPAWNERS.V.stage_tick(200, true, true)")
check(any("enemy source: Lua runtime route" in l for l in LOG), "no manifest: rivet.log says the Lua route is used")

# 2. manifest installed: nothing is written, earlier changes are put back
armed = {i: get_var(i) for i in (1, 2, 3)}
install_manifest(lua)
check(lua.eval("RANDO_SPAWNERS.V.stage_mode()") is True, "manifest installed: .stage mode")
WRITES.clear()
plan(lua)
check({i: get_var(i) for i in (1, 2, 3)} == {i + 1: (KINDS[i][3], KINDS[i][2]) for i in range(3)},
      "manifest installed mid-level: every earlier runtime change is put back (originals in place)")
changed = [i for i in (1, 2, 3) if armed[i] != (KINDS[i - 1][3], KINDS[i - 1][2])]
var_addrs = {BASE + i * VS + o for i in changed for o in (0, 0x10)}
check(changed and WRITES and all(w[0] in var_addrs for w in WRITES),
      "the only writes were put-backs of the %d changed variable(s)" % len(changed))
WRITES.clear()
plan(lua)
plan(lua)
check(WRITES == [], ".stage mode: planning again writes nothing")
check(lua.eval("RANDO_SPAWNERS.V.lvl.order[1].why_said") == lua.eval("RANDO_SPAWNERS.V.STAGE_WHY"), ".stage mode: the SPAWN reason says .stage mode")
lua.execute('''local V = RANDO_SPAWNERS.V
local r = V.lvl.order[2]
V.arm(SC, r, V.lvl.tpl[13], V.lvl.tpl[12], "enemy")''')
live = lua.eval("(function() local n = 0 for _, A in ipairs(RANDO_SPAWNERS.V.lvl.arms) do if not A.restored then n = n + 1 end end return n end)()")
check(WRITES == [] and live == 0, ".stage mode: V.arm called directly writes nothing (%d write(s), %d live change(s))" % (len(WRITES), live))
ok, why = lua.eval('RANDO_SPAWNERS.write_slot({}, { cur = 1, orig = 1, addr = 0 }, 2, "chaos")')
check(ok is False and ".stage mode" in str(why), ".stage mode: the legacy slot route (Chaos) refuses to write")

# 3. the .stage check: loaded / not loaded / spawn / death / summary
lua, LOG, SAID = make()
set_var(1, KINDS[2][3], 13)       # spawner F1: the .stage replaced melee (B2) by swarmer (B3) - loaded
set_var(2, KINDS[1][3], 12)
set_var(3, KINDS[0][3], 11)
install_manifest(lua)
level(lua, "planet NefCity")
lua.execute("RANDO_SPAWNERS.V.stage_tick(100, true, true)")
check(any("STAGE MODE ON" in l and "1 change(s)" in l for l in LOG), "first tick: STAGE MODE ON is logged with the change count")
check(any("STAGE CHANGE 1:" in l and "00000000000000B2" in l and "00000000000000B3" in l for l in LOG), "first tick: the change is logged")
check(any("[ENEMY RANDOMIZER] .stage mode" in s for s in SAID), "first tick: a corner note says .stage mode")
check(any("STAGE VARIABLE factory F1: holds 00000000000000B3" in l and "IS loaded" in l for l in LOG), "listing: the patched spawner holds the .stage value -> IS loaded")
check(any("STAGE VARIABLES of the listed spawners" in l and "held by 1 variable" in l for l in LOG), "listing: reference counts are logged")
lua.execute('''local V = RANDO_SPAWNERS.V
local r = V.lvl.order[1]
V.ledger_add({ h = 5001 }, r, { name = "enm_neo_nefarious_swarmer", family = "swarmer" }, nil, "NOT CHANGED", V.STAGE_WHY)''')
check(any("STAGE SPAWN 5001" in l and "(the patched spawner)" in l and "REPLACEMENT SPAWNED" in l for l in LOG), "spawn: the replacement spawned from the patched spawner")
lua.execute("RANDO_SPAWNERS.frame = 400; RANDO_SPAWNERS.V.on_death({ SenderHandle = 5001 })")
check(any("STAGE DEATH 5001" in l for l in LOG), "death: the replacement's death is logged")
lua.execute('RANDO_SPAWNERS.V.new_level("leaving"); RANDO_STAGE.level()')
check(any("STAGE SUMMARY" in l and "replacement 1" in l and "died 1" in l for l in LOG), "summary: per level, replacement 1, died 1")
check(any("STAGE SPAWNER F1" in l and "REPLACEMENT SPAWNED" in l for l in LOG), "summary: per patched spawner")

lua, LOG, SAID = make()
set_var(1, KINDS[1][3], 12)       # the zone file was NOT replaced: F1 still holds the original
set_var(2, KINDS[1][3], 12)
set_var(3, KINDS[0][3], 11)
install_manifest(lua)
level(lua, "planet NefCity")
lua.execute("RANDO_SPAWNERS.V.stage_tick(100, true, true)")
check(any("RANDO-ERROR STAGE VARIABLE factory F1: still holds the ORIGINAL" in l for l in LOG), "listing: a .stage that did not load is reported as an error")
lua.execute('''local V = RANDO_SPAWNERS.V
V.ledger_add({ h = 7001 }, V.lvl.order[1], { name = "enm_neo_nefarious_melee", family = "swarmer" }, nil, "NOT CHANGED", V.STAGE_WHY)''')
check(any("STAGE SPAWN 7001" in l and "not loaded" in l for l in LOG), "spawn: the original from the patched spawner says 'not loaded'")

# 4. the setting
lua, LOG, SAID = make(', enemy_source = "lua"')
install_manifest(lua)
lua.execute("RANDO_SPAWNERS.V.stage_tick(100, true, true)")
check(lua.eval("RANDO_SPAWNERS.V.stage_mode()") is True and any('enemy_source = "lua" is ignored' in l for l in LOG),
      'enemy_source = "lua" with a manifest installed: .stage mode anyway, and an error says why')
lua, LOG, SAID = make(', enemy_source = "stage"')
for i, (n, fam, h, uid) in enumerate(KINDS):
    set_var(i + 1, uid, h)
level(lua, "planet NefCity")
plan(lua)
check(lua.eval("RANDO_SPAWNERS.V.stage_mode()") is True and lua.eval("#RANDO_SPAWNERS.V.lvl.arms") == 0 and WRITES == [],
      'enemy_source = "stage" without a manifest: no runtime change at all')

print("FAILURES", fails)
sys.exit(1 if fails else 0)
