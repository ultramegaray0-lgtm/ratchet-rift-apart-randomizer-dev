# Stage tool 1.1.0: the zone decoder (tools/stage_enemies/zone.py) and the Phase A POC root cause, as tests.
#
#   python tests/v076dev4/test_stage_zone_fix.py .                              synthetic zones only (always run)
#   python tests/v076dev4/test_stage_zone_fix.py . --zone <AE530D22FE113E2B.zone.orig> [--old-stage <1.0.1 .stage>]
#                                                [--new-stage <1.1.0 .stage>]
# --zone is the poc backup of ard_firstvisit_gp.zone (header + zone; the game's own data, so it is not shipped in the kit).
# With it, the real zone is decoded and the POC's root cause is reproduced: the 1.0.1 .stage FAILS, the 1.1.0 build PASSES.
import hashlib
import os
import struct
import sys
import zipfile
import zlib

KIT = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith("--") else "."
sys.path.insert(0, os.path.join(KIT, "tools", "stage_enemies"))
import fakegame  # noqa: E402
import rcra  # noqa: E402
import zone as ZN  # noqa: E402


def arg(name):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else None


fails = 0


def check(c, m):
    global fails
    print(("PASS " if c else "FAIL ") + m)
    if not c:
        fails += 1


def raises(fn, needle=""):
    try:
        fn()
    except rcra.FormatError as ex:
        return needle in str(ex)
    return False


SH = "characters/enemy/q/actors/enm_pirate_robot_shooter.actor"
ME = "characters/enemy/q/actors/enm_pirate_robot_melee.actor"
U_SH, U_ME, U_SH2 = "1111111111111111", "2222222222222222", "3333333333333333"
T = [(U_SH, SH, "TEMPLATE_SHOOTER"), (U_ME, ME, "TEMPLATE_MELEE"), (U_SH2, SH, "TEMPLATE_SHOOTER_V2")]
K1, K2, K3, K4, K5 = (0xC000000000000001 + i for i in range(5))

# ---- 1. CRC / hash calculations against known values ----------------------------------------------------------------
print("1. hashes")


def crc32_bitwise(s):        # the root-cause wiring.py variant: one bit at a time
    c = 0xEDB88320
    for b in s.encode():
        c ^= b
        for _ in range(8):
            c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
    return c


words = ["Templates", "Template", "LastSpawn", "Factories", "Location", "Locations", "Zone Script Vars", "", "a" * 300,
         "FirepointSet", "CombatMarkupCollection", "Duration", "Position", "Camera", "Speed", "Value"]
check(all(crc32_bitwise(w) == rcra.crc32_engine(w) for w in words), "crc32: the bitwise (wiring.py) and table forms agree on %d strings" % len(words))
check(rcra.crc32_engine("Templates") == 3990217346 == 0xEDD5E282 == ZN.PLUG_TEMPLATES, "crc32 'Templates' = 3990217346 (the game's plug hash, rivet_hook)")
check(zlib.crc32(b"Templates") != rcra.crc32_engine("Templates"), "the engine hash is NOT standard CRC-32 (start EDB88320, no final xor): zlib differs")
KNOWN_ZONE_PLUGS = {"FirepointSet": 0xADF7B933, "CombatMarkupCollection": 0x624D34AE, "Duration": 0x7C5E3DB0, "Position": 0xBC2D5985,
                    "Camera": 0x0564A062, "Speed": 0x16753237, "Value": 0x042494F5}   # plug hashes found in ard_firstvisit_gp.zone
check(all(rcra.crc32_engine(n) == v for n, v in KNOWN_ZONE_PLUGS.items()), "crc32 of 7 plug names = the hashes stored in the real zone's plug table")
check(rcra.crc64_path("characters\\enemy\\enm_pirate_robot_q4b\\actors\\enm_pirate_robot_shooter.actor") == 0xA634A2F2985F6C56
      and rcra.crc64_path("characters/enemy/enm_pirate_robot_q4b/actors/enm_pirate_robot_melee.actor") == 0xBE93E997D265010B,
      "crc64 of the two .actor paths = the ids stored in the real zone's actor-asset table")
check(rcra.crc64_path("levels\\i29\\instance\\ardolis\\ardolis_main\\ard_firstvisit_gp.zone") == 0xAE530D22FE113E2B,
      "crc64 of the zone path = AE530D22FE113E2B (the id rivet_hook resolved in your log)")

# ---- 2. structure, bounds, duplicates, forms ------------------------------------------------------------------------
print("2. zone structure (synthetic zones with the real layouts)")
good = fakegame.spawner_zone(T, [(K1, U_SH), (K2, U_ME), (K3, U_SH2)], [(K4, K5, U_SH)])
z = ZN.Zone.parse(good)
check(all(ok for _, ok, _ in z.checks), "a well-formed zone passes every structural check")
check(z.reference_report()["forms"] == {"local": 4, "empty": 1, "group": 1, "external": 1}, "the four type-5 forms are recognised")
check([r["owner"] for r in z.spawner_refs()] == ["%016X" % K for K in (K1, K2, K3)], "single-owner Templates references only (the shared one left out)")
d = fakegame.dat1


def mutate_section(raw, tag, fn):
    dd = rcra.Dat1.parse(raw, 0)
    s = dd.sections[tag]
    b = bytearray(raw)
    fn(b, s.offset, s.size)
    return bytes(b)


bad = mutate_section(good, ZN.SCRIPT_PLUGS, lambda b, o, n: b.__setitem__(slice(o + 4, o + 8), struct.pack("<I", 9999)))
check(raises(lambda: ZN.Zone.parse(bad), "names an existing Script Vars"), "a plug pointing past Script Vars is refused")
bad = mutate_section(good, ZN.SCRIPT_ACTIONS, lambda b, o, n: b.__setitem__(slice(o + 24, o + 26), struct.pack("<H", 500)))
check(raises(lambda: ZN.Zone.parse(bad), "ranges inside the plug table"), "an action range past the plug table is refused")
bad = mutate_section(good, ZN.SCRIPT_ACTIONS, lambda b, o, n: b.__setitem__(slice(o + 40 + 22, o + 40 + 24), struct.pack("<H", 0)))
check(raises(lambda: ZN.Zone.parse(bad), "exactly one action"), "plugs owned twice / by none are refused (ownership must be a partition)")
bad = mutate_section(good, ZN.SCRIPT_ACTIONS, lambda b, o, n: b.__setitem__(slice(o + 40, o + 48), b[o:o + 8]))
check(raises(lambda: ZN.Zone.parse(bad), "keys unique"), "two actions with one key are refused")
bad = mutate_section(good, ZN.ACTOR_ASSETS, lambda b, o, n: b.__setitem__(o, b[o] ^ 1))
check(raises(lambda: ZN.Zone.parse(bad), "CRC64(path)"), "an actor-asset id that is not CRC64(its path) is refused")
bad = mutate_section(good, ZN.ZONE_ACTORS, lambda b, o, n: b.__setitem__(slice(o + 4, o + 8), struct.pack("<I", 77)))
check(raises(lambda: ZN.Zone.parse(bad), "asset index"), "a Zone Actors asset index out of range is refused")
bad = mutate_section(good, ZN.ACTOR_ASSETS, lambda b, o, n: b.__setitem__(slice(o + 8 * 2, o + 8 * 2 + 4), struct.pack("<I", 10 ** 7)))
check(raises(lambda: ZN.Zone.parse(bad), "outside DAT1"), "an actor-asset path offset outside DAT1 is refused")
dd = rcra.Dat1.parse(good, 0)
k = dd.order.index(ZN.SCRIPT_VARS)
bad = bytearray(good)
struct.pack_into("<I", bad, 16 + 12 * k + 8, dd.sections[ZN.SCRIPT_VARS].size - 4)
check(raises(lambda: ZN.Zone.parse(bytes(bad)), "whole records"), "a Script Vars size that is not whole 32-byte entries is refused")
bad = bytearray(good)
struct.pack_into("<I", bad, 16 + 12 * k + 4, dd.sections[ZN.SCRIPT_PLUGS].offset)
check(raises(lambda: ZN.Zone.parse(bytes(bad))), "overlapping sections are refused")
check(raises(lambda: ZN.Zone.parse(good[:200] + bytes(len(good) - 200))), "a damaged DAT1 is refused")

dup = fakegame.spawner_zone([(U_SH, SH, "A"), (U_SH, SH, "B"), (U_ME, ME, "C")], [(K1, U_ME), (K2, U_ME)])
zd = ZN.Zone.parse(dup)
check(zd.duplicate_uids == {int(U_SH, 16): [0, 1]} and int(U_SH, 16) not in zd.actor_of_uid, "a uid on two Zone Actors records is found, and kept out of the uid map")
check(raises(lambda: ZN.plan_swap(zd, 0, int(U_SH, 16)), "ambiguous"), "patching TO a duplicated uid is refused")
dup2 = fakegame.zone([SH], [(int(U_SH, 16), 0, "A"), (int(U_SH, 16), 0, "B")], [{"value": int(U_SH, 16), "index": 0}],
                     [(K1, 0x2E910F8C, [("Templates", 0, 1)])])
zd2 = ZN.Zone.parse(dup2)
check(zd2.vars[0].problem and "ambiguous" in zd2.vars[0].problem and not zd2.reference_report()["ok"],
      "a reference to a duplicated uid is a reference problem (ambiguous), never patched FROM")

ext_bad = fakegame.zone([SH], [(int(U_SH, 16), 0, "A")], [{"value": 0x8123456789ABCDEF, "index": 0}], [(K1, 1, [("Templates", 0, 1)])])
ze = ZN.Zone.parse(ext_bad)
check("not an actor of this zone" in (ze.vars[0].problem or ""), "an external uid with a zone index set is a reference problem")
bad_aux = fakegame.zone([SH], [(int(U_SH, 16), 0, "A")], [{"value": int(U_SH, 16), "index": 0, "aux": 2}], [(K1, 1, [("Templates", 0, 1)])])
check("undecoded" in (ZN.Zone.parse(bad_aux).vars[0].problem or ""), "an entry with aux set and a uid (undecoded form) is a reference problem")
tail = fakegame.zone([SH], [(int(U_SH, 16), 0, "A")], [{"value": int(U_SH, 16), "index": 0, "tail": 1}], [(K1, 1, [("Templates", 0, 1)])])
check("last 8 bytes" in (ZN.Zone.parse(tail).vars[0].problem or ""), "an entry with a non-zero tail is a reference problem")

# ---- 3. the patch: both halves, ownership, identity, diff --------------------------------------------------------------
print("3. the patch")
v0 = z.spawner_refs()[0]["var"]
changes, info = ZN.plan_swap(z, v0, int(U_ME, 16), "%016X" % K1)
check(sorted(c.field for c in changes) == ["actor_index", "uid"], "plan_swap changes BOTH the Zone Actors index and the uid")
check(info["replacement"]["index"] == 1 and info["replacement"]["kind"] == "enm_pirate_robot_melee", "identity of the replacement from the zone's actor-asset table")
new = ZN.apply_changes(good, changes)
res = ZN.compare_zones(good, new)
check(res["ok"] and [c["fields"] for c in res["changes"]] == [["actor_index", "uid"]], "compare_zones: the pair change passes")
check(raises(lambda: ZN.plan_swap(z, v0, int(U_ME, 16), "%016X" % K2), "not to the intended spawner"), "the wrong intended spawner is refused")
shared_var = [v.index for v in z.vars if v.form == "local" and len(z.owners(v.index)) == 2][0]
check(raises(lambda: ZN.plan_swap(z, shared_var, int(U_ME, 16)), "referenced by 2 plugs"), "a variable shared by two nodes is refused")
loc_var = [v.index for v in z.vars if v.type == 4][0]
check(raises(lambda: ZN.plan_swap(z, loc_var, int(U_ME, 16)), "not a valid local actor reference"), "a non-actor variable is refused")
check(raises(lambda: ZN.plan_swap(z, v0, 0x8123456789ABCDEF), "not an actor of this zone"), "a replacement that is not an actor of the zone is refused")
check(raises(lambda: ZN.plan_swap(z, v0, int(U_SH, 16)), "is the original"), "replacing a template by itself is refused")
check(raises(lambda: ZN.plan_swap(z, 10 ** 6, int(U_ME, 16)), "does not exist"), "a Script Vars index out of range is refused")
uid_only = bytearray(good)
ab = z.vars[v0].abs
uid_only[ab + 16:ab + 24] = rcra.uid_bytes(U_ME)
r = ZN.compare_zones(good, bytes(uid_only))
check(not r["ok"] and any("INCONSISTENT REFERENCE" in p for p in r["problems"]), "uid-only change (the 1.0.1 POC) FAILS compare_zones")
idx_only = bytearray(good)
idx_only[ab + 4:ab + 6] = struct.pack("<H", 1)
check(not ZN.compare_zones(good, bytes(idx_only))["ok"], "index-only change fails")
other = bytearray(new)
other[10] ^= 1
check(not ZN.compare_zones(good, bytes(other))["ok"], "a byte outside Script Vars fails")
two = bytearray(new)
v1 = z.spawner_refs()[2]["var"]
two[z.vars[v1].abs + 4:z.vars[v1].abs + 6] = struct.pack("<H", 1)
two[z.vars[v1].abs + 16:z.vars[v1].abs + 24] = rcra.uid_bytes(U_ME)
r = ZN.compare_zones(good, bytes(two))
check(r["ok"] and len(r["changes"]) == 2, "compare_zones reports every changed entry (stage_enemies poc / verify then require exactly the planned one)")
shared_patch = bytearray(good)
shared_patch[z.vars[shared_var].abs + 4:z.vars[shared_var].abs + 6] = struct.pack("<H", 1)
shared_patch[z.vars[shared_var].abs + 16:z.vars[shared_var].abs + 24] = rcra.uid_bytes(U_ME)
r = ZN.compare_zones(good, bytes(shared_patch))
check(not r["ok"] and any("not a single-owner Templates variable" in p for p in r["problems"]), "a change to a shared variable fails compare_zones")

# ---- 4. the real Ardolis zone (optional: needs the poc backup) --------------------------------------------------------
zpath = arg("--zone")
if not zpath:
    print("4. the real zone: skipped (pass --zone <AE530D22FE113E2B.zone.orig>)")
else:
    print("4. the real zone: %s" % zpath)
    blob = open(zpath, "rb").read()
    header, raw = blob[:36], blob[36:]
    check(hashlib.sha256(raw).hexdigest() == "d40540edad455dee68a274540cd53589b3142ce458bac16bde82a0d6f185e016",
          "zone sha256 = the probe of your game (d40540ed...)")
    rz = ZN.Zone.parse(raw)
    check(all(ok for _, ok, _ in rz.checks), "every structural check passes on the game's zone (%d checks)" % len(rz.checks))
    check(len(rz.asset_ids) == 67, "actor-asset table: 67 entries, CRC64(path) == id for all 67")
    check((len(rz.actors), len(rz.vars), len(rz.plugs), len(rz.actions)) == (586, 1048, 2020, 926), "586 actors, 1048 Script Vars, 2020 plugs, 926 actions")
    check(not rz.duplicate_uids, "no duplicate actor uid in the zone")
    rr = rz.reference_report()
    check(rr["ok"] and rr["forms"] == {"local": 302, "external": 23, "group": 251, "empty": 72},
          "C1 baseline: 648 type-5 entries - 302 local (uid/index agree), 23 external, 251 group, 72 empty, 0 problems")
    own = rz.owners(153)
    check(len(own) == 1 and own[0]["key"] == "CECB812E81FB7301" and own[0]["plug"] == 460 and own[0]["plug_is_templates"],
          "SV #153: exactly one plug in the zone, #460 'Templates' of CECB812E81FB7301 (Script Actions #387)")
    own799 = rz.owners(799)
    check(any(o["key"] == "E6705A36656EB7B9" and o["plug_is_templates"] for o in own799) and rz.vars[799].value == 0x92C793D47A4657B6
          and rz.vars[799].actor_index == 25, "SV #799 (Templates of E6705A36656EB7B9, spawns brawlers): uid 92C793D47A4657B6 with index 25")
    a15, a25 = rz.actors[15], rz.actors[25]
    check(a15.uid == 0x899208BF8F48C554 and a15.kind == "enm_pirate_robot_shooter" and a15.name == "TEMPLATE_PIRATE_SHOOTER_V2",
          "Zone Actors #15 = 899208BF8F48C554 enm_pirate_robot_shooter.actor (TEMPLATE_PIRATE_SHOOTER_V2)")
    check(a25.uid == 0x92C793D47A4657B6 and a25.kind == "enm_pirate_robot_melee" and a25.name == "TEMPLATE_PIRATE_MELEE_V2",
          "Zone Actors #25 = 92C793D47A4657B6 enm_pirate_robot_melee.actor (TEMPLATE_PIRATE_MELEE_V2)")
    # the decode correction: Script Plugs records start at +0, not +8 (the root-cause report's reading)
    PL = rz.sec(ZN.SCRIPT_PLUGS)
    fac = [a for a in rz.actions if a.cls == 0x2E910F8C]

    def one_templates(base):
        n = 0
        for a in fac:
            f, c = a.ranges.get("a", (0, 0))
            names = [struct.unpack_from("<I", PL, base + 12 * p + (0 if base == 0 else 4))[0] for p in range(f, f + c)
                     if base + 12 * p + 12 <= len(PL)]
            n += names.count(ZN.PLUG_TEMPLATES) == 1
        return n
    check(len(fac) == 43 and one_templates(0) == 43 and one_templates(8) < 43,
          "plug records from +0: 43 of 43 factory nodes have one Templates plug (read from +8, as the report did: %d)" % one_templates(8))
    changes, info = ZN.plan_swap(rz, 153, 0x92C793D47A4657B6, "CECB812E81FB7301")
    check([(c.field, c.abs, c.old.hex(), c.new.hex()) for c in changes] ==
          [("actor_index", 413764, "0f00", "1900"), ("uid", 413776, "54c5488fbf089289", "b657467ad493c792")],
          "the corrected patch: zone +413764 0F 00 -> 19 00 and zone +413776 uid 899208BF8F48C554 -> 92C793D47A4657B6")
    fixed = ZN.apply_changes(raw, changes)
    res = ZN.compare_zones(raw, fixed)
    check(res["ok"] and len(res["diff"]) == 9 and res["patched"]["type5_forms"] == rr["forms"], "the corrected zone passes every rule; 9 bytes differ")
    for nm, val in (("uid only (the 1.0.1 POC)", lambda b: b.__setitem__(slice(413776, 413784), rcra.uid_bytes("92C793D47A4657B6"))),
                    ("index only", lambda b: b.__setitem__(slice(413764, 413766), b"\x19\x00"))):
        b = bytearray(raw)
        val(b)
        r = ZN.compare_zones(raw, bytes(b))
        check(not r["ok"] and any("INCONSISTENT REFERENCE" in p for p in r["problems"]), "real zone, %s: REFUSED (inconsistent reference)" % nm)
    shared = [v.index for v in rz.vars if v.form == "local" and len(rz.owners(v.index)) > 1 and any(o["plug_is_templates"] for o in rz.owners(v.index))]
    check(len(shared) == 30 and raises(lambda: ZN.plan_swap(rz, shared[0], 0x92C793D47A4657B6), "plugs"),
          "the 30 Templates variables shared with another node are refused")
    ext = [v.index for v in rz.vars if v.form == "external"][0]
    check(raises(lambda: ZN.plan_swap(rz, ext, 0x92C793D47A4657B6), "not a valid local"), "an external reference is never patched")
    old = arg("--old-stage")
    if old:
        m = zipfile.ZipFile(old).read("0/AE530D22FE113E2B")
        r = ZN.compare_zones(raw, m[36:])
        check(not r["ok"] and any("Script Vars #153" in p and "INCONSISTENT REFERENCE" in p and "record 15 (enm_pirate_robot_shooter)" in p
                                  for p in r["problems"]), "the 1.0.1 POC .stage FAILS: SV #153 uid -> record 25 (brawler), index -> record 15 (shooter)")
    newst = arg("--new-stage")
    if newst:
        zf = zipfile.ZipFile(newst)
        check(zf.namelist() == ["info.json", "0/AE530D22FE113E2B"] and zf.testzip() is None, "the 1.1.0 .stage: info.json + one zone member, CRCs intact")
        m = zf.read("0/AE530D22FE113E2B")
        check(m == header + fixed, "the 1.1.0 .stage member = the original header + exactly the corrected zone")
        r = ZN.compare_zones(raw, m[36:])
        check(r["ok"] and len(r["diff"]) == 9, "the 1.1.0 .stage PASSES compare_zones (9 bytes, SV #153 index + uid)")

print("FAILURES", fails)
sys.exit(1 if fails else 0)
