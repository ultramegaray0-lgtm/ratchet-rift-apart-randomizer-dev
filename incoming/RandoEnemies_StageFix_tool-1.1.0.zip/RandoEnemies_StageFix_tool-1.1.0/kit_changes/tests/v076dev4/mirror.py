"""mirror.py - a read-only stand-in game folder holding ONE real zone, for testing the stage tool off the PC.

The zone and its 36-byte toc header come from a poc backup (<id>.zone.orig = header + zone, written by stage_enemies.py
poc from the real toc). The file is checked against its own .sha256 line and, if given, against the zone sha256 the
probe read from the real game, before anything is written. The toc / dag / DSAR container uses the kit's fakegame.py
helpers, so stage_enemies.py opens it exactly as it opens the game. Used by test_stage_zone_fix.py and the build round.

  python -I mirror.py <tools/stage_enemies dir> <zone.orig> <zone path in the game> <out game dir> [zone sha256]
"""
import hashlib
import os
import struct
import sys


def build(tools: str, orig_path: str, zone_path: str, out: str, zone_sha: str = None) -> int:
    sys.path.insert(0, tools)
    import fakegame  # noqa: E402
    import rcra  # noqa: E402
    blob = open(orig_path, "rb").read()
    header, raw = blob[:36], blob[36:]
    zid = rcra.crc64_path(zone_path)
    side = orig_path + ".sha256"
    want = open(side).read().split()[0] if os.path.isfile(side) else None
    checks = [("backup sha256 = its .sha256 line", want is None or hashlib.sha256(blob).hexdigest() == want),
              ("zone sha256 = the probe's (real game)", zone_sha is None or hashlib.sha256(raw).hexdigest() == zone_sha),
              ("DAT1 right after the 36-byte header", rcra.find_dat1(blob) == 36),
              ("header block sizes add up to the zone", sum(struct.unpack_from("<8I", header, 4)) == len(raw))]
    for name, ok in checks:
        print("  mirror: %-40s %s" % (name, "ok" if ok else "FAILED"))
    if not all(ok for _, ok in checks):
        raise SystemExit("the backup does not match - refusing to build the mirror")
    os.makedirs(os.path.join(out, "d"), exist_ok=True)
    with open(os.path.join(out, "d", "fake.archive"), "wb") as f:
        f.write(fakegame.dsar(raw, chunk=0x10000))
    spans = [(0, 1)] + [(1, 0)] * 255
    archives = b"d\\fake.archive".ljust(40, b"\0") + struct.pack("<QQIHI", 0, 0, 0, 0, 0)
    toc_dat = fakegame.dat1(0x51B8E006, [
        (rcra.TOC_ASSET_IDS, struct.pack("<Q", zid)),
        (rcra.TOC_SPANS, b"".join(struct.pack("<II", a, b) for a, b in spans)),
        (rcra.TOC_SIZES, struct.pack("<IIIi", len(raw), 0, 0, 0)),
        (rcra.TOC_ARCHIVES, archives),
        (rcra.TOC_HEADERS, header),
    ])
    with open(os.path.join(out, "toc"), "wb") as f:
        f.write(struct.pack("<II", rcra.TOC_MAGIC, len(toc_dat) + 8) + toc_dat)
    head = 16 + 12 * 5
    dag_dat = fakegame.dat1(0x2A077A51, [
        (rcra.DAG_ASSET_IDS, bytes(8)),
        (rcra.DAG_NAMES, struct.pack("<I", head)),
        (rcra.DAG_TYPES, bytes([1])),
        (rcra.DAG_LINKS, struct.pack("<i", -1)),
        (rcra.DAG_HEADS, struct.pack("<i", 0)),
    ], zone_path.encode() + b"\0")
    with open(os.path.join(out, "dag"), "wb") as f:
        f.write(struct.pack("<III", 0xB8EF3955, len(dag_dat) + 12, 0) + dag_dat)
    toc = rcra.Toc(out)
    e = toc.find(zid, 0)
    ok = e is not None and toc.header(e) == header and toc.read(e) == raw
    toc.close()
    print("  mirror: %-40s %s" % ("read back through rcra.Toc", "ok" if ok else "FAILED"))
    if not ok:
        raise SystemExit("mirror read-back failed")
    return zid


if __name__ == "__main__":
    build(*sys.argv[1:6])
