-- Rift Apart Randomizer v0.76-DEV4 (stage tool 1.1.0): ONE-TIME save registry repair. OPTIONAL developer file.
--
-- What it does: allows 16_rando_spawners.lua to clear the FALSE "|mixed" mark of the templates listed in
-- V.REG_FALSE_MIXED (today only 92C793D47A4657B6, Ardolis' brawler template, marked MIXED by the Phase A POC .stage whose
-- reference had the brawler's uid but the shooter's Zone Actors index). Only the "|mixed" suffix of that one entry is
-- removed, and only when the stored value is "enm_pirate_robot_melee|swarmer|...|mixed" - anything else is left alone.
-- Without this file 16_rando_spawners.lua only LOGS the false entry and changes nothing.
--
-- Use: back up Documents\Ratchet & Clank - Rift Apart first. Copy this file into <game>\scripts, start the game, load the
-- save, look for "registry: CLEARED the false MIXED mark" in rivet.log, save once, then DELETE this file.
RANDO_FILES = RANDO_FILES or {}; RANDO_FILES["dev(reg_repair)"] = "10.0.43"   -- the kit check (10_rando_runtime.lua)
RANDO_REG_REPAIR = true
pcall(rivet.log, "[rando]", "RANDO-ENEMIES", "dev(reg_repair).lua loaded: the false MIXED registry entries listed in " ..
    "16_rando_spawners.lua (V.REG_FALSE_MIXED) are cleared when the save is read - remove this file afterwards")
