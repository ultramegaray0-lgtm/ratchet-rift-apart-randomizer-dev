#!/usr/bin/env python3
"""stage_enemies.py - the .stage Enemy Randomizer companion (Rift Apart Randomizer v0.76-DEV4, Phase A, tool 1.1.0).

Reads the game's own files (toc, dag, archives) - never writes to them - and builds a .stage that rivet_hook (or
Overstrike) loads in place of one level zone. Phase A changes ONE template reference of ONE spawner, and only when the
zone's own tables prove it (zone.py).

  python stage_enemies.py selftest
  python stage_enemies.py levels   --game "C:/.../Ratchet & Clank - Rift Apart" --filter zurkon
  python stage_enemies.py probe    --game GAME --planet zurkon [--log rivet.log ...] [--out probe_out]
  python stage_enemies.py poc      --game GAME --probe probe_out/probe.json [--spawner KEY] [--replacement UID] [--out NEW_DIR]
  python stage_enemies.py verify   --game GAME --stage NEW_DIR/RandoEnemies.stage
  python stage_enemies.py check-zone ZONE_OR_STAGE [ZONE_OR_STAGE ...]        (read-only, no game folder needed)
  python stage_enemies.py install  --game GAME --build NEW_DIR
  python stage_enemies.py uninstall --game GAME

Tool 1.1.0 (the Phase A POC failure): a zone-local actor reference is the actor's uid AND its Zone Actors record index.
1.0.x changed only the uid; the game spawned what the index named. Now a reference is changed as a pair, the zone's
Script Actions -> Script Plugs -> Script Vars wiring must show exactly one Templates owner (the intended spawner), the
template's identity comes from the zone's own actor-asset table, and verify rejects every byte outside {index, uid} of
that one entry. Every command prints what it did and why; anything it cannot prove from the files it refuses (exit 2).
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import shutil
import struct
import sys
from math import gcd
from typing import Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import knowledge as K  # noqa: E402
import rcra  # noqa: E402
import zone as ZN  # noqa: E402

TOOL_VERSION = "1.1.0"   # 1.1.0: the reference is {uid, Zone Actors index}; ownership and identity from the zone itself
#                          1.0.1: spawner_keys = only the spawners logged holding the original uid
KIT_RELEASE = "v0.76-DEV4"
STAGE_NAME = "RandoEnemies.stage"
MANIFEST_LUA = "18_rando_stage_manifest.lua"
STAGE_MOD_PATH = "mods/" + STAGE_NAME
EXIT_REFUSED = 2
STAGE_LUA = "1.1.0"      # the Lua side this tool needs: 16_rando_spawners.lua and 18_rando_stage_enemies.lua say
#                          V.STAGE_LUA / ST.STAGE_LUA = "1.1.0" (handle/uid check, no false MIXED, missing-check alarm)

ZONE_SCRIPT_VARS = rcra.SEC["Zone Script Vars"]
ZONE_ACTORS = rcra.SEC["Zone Actors"]
ZONE_ASSET_REFS = rcra.SEC["Zone Asset References"]


def die(msg: str) -> None:
    print("REFUSED: " + msg)
    sys.exit(EXIT_REFUSED)


def default_scripts_dir() -> str:
    return os.path.normpath(os.path.join(HERE, "..", "..", "scripts"))


def load_knowledge(scripts_dir: str, logs: List[str]) -> K.Knowledge:
    k = K.Knowledge()
    K.load_scripts(k, scripts_dir)
    for p in logs or []:
        K.load_log(k, p)
    return k


def open_game(game: str) -> Tuple[rcra.Toc, Optional[rcra.Dag]]:
    if not os.path.isfile(os.path.join(game, "toc")):
        die("no 'toc' file in %s (pass the folder that holds RiftApart.exe and toc)" % game)
    toc = rcra.Toc(game)
    dag = rcra.Dag(game) if os.path.isfile(os.path.join(game, "dag")) else None
    return toc, dag


def read_zone(toc: rcra.Toc, zone_id: int):
    e = toc.find(zone_id, 0)
    if e is None:
        e = toc.find(zone_id)
    if e is None:
        return None, None, None
    return e, toc.header(e), toc.read(e)


def section_at(dat: rcra.Dat1, abs_off: int) -> Tuple[Optional[int], int]:
    for tag in dat.order:
        s = dat.sections[tag]
        a = dat.base + s.offset
        if a <= abs_off < a + s.size:
            return tag, abs_off - a
    return None, abs_off - dat.base


def scan_aligned(raw: bytes, needles: Dict[bytes, tuple], step: int = 4) -> List[Tuple[int, bytes]]:
    """Every 8-byte value at a `step`-aligned offset that is a needle."""
    want = {struct.unpack("<Q", b)[0]: b for b in needles}
    hits = []
    n = len(raw) - 8
    for phase in range(0, 8, step):
        if phase > n:
            break
        cnt = (n - phase) // 8 + 1
        vals = struct.unpack_from("<%dQ" % cnt, raw, phase)
        hits += [(phase + 8 * k, want[v]) for k, v in enumerate(vals) if v in want]
    hits.sort()
    return hits


def find_all(raw: bytes, needle: bytes) -> List[int]:
    out, i = [], raw.find(needle)
    while i >= 0:
        out.append(i)
        i = raw.find(needle, i + 1)
    return out


def diff_positions(a: bytes, b: bytes) -> List[int]:
    """Offsets where two equal-length buffers differ (block compare first: zones are megabytes)."""
    out = []
    n = min(len(a), len(b))
    step = 4096
    for s in range(0, n, step):
        if a[s:s + step] != b[s:s + step]:
            out += [i for i in range(s, min(n, s + step)) if a[i] != b[i]]
    out += list(range(n, max(len(a), len(b))))
    return out


def hexdump(b: bytes) -> str:
    return " ".join("%02X" % x for x in b)


# ======================================================================================================================
# levels
# ======================================================================================================================
def cmd_levels(a) -> None:
    toc, dag = open_game(a.game)
    if dag is None:
        die("no 'dag' file: the zone list comes from it")
    f = (a.filter or "").lower()
    rows = [(dag.names[i], dag.type_name(i)) for i in range(dag.count)
            if dag.type_name(i) in ("level", "zone") and f in dag.names[i].lower()]
    for n, t in sorted(rows):
        e = toc.find(rcra.crc64_path(n), 0)
        print("%-5s %-90s %s" % (t, n, ("%s %d bytes" % (rcra.hex64(e.asset_id), e.size)) if e else "not in toc span 0"))
    print("%d level/zone assets match '%s'" % (len(rows), f))


# ======================================================================================================================
# probe (read-only)
# ======================================================================================================================
def cmd_probe(a) -> None:
    k = load_knowledge(a.scripts or default_scripts_dir(), a.log)
    for n in k.notes:
        print("knowledge: " + n)
    toc, dag = open_game(a.game)
    if dag is None:
        die("no 'dag' file: the zone list comes from it")
    filters = [p.lower() for p in a.planet]
    zones = sorted({dag.names[i] for i in range(dag.count)
                    if dag.type_name(i) == "zone" and any(f in dag.names[i].lower() for f in filters)})
    if a.limit:
        zones = zones[:a.limit]
    if not zones:
        die("no zone asset name contains %s - run 'levels' to see the names" % ", ".join(filters))
    print("probing %d zone(s) for %s ..." % (len(zones), ", ".join(filters)))

    needles: Dict[bytes, tuple] = {}
    for uid, t in k.templates.items():
        needles[rcra.uid_bytes(uid)] = ("template", uid, t.name)
    for key, s in k.spawners.items():
        needles.setdefault(rcra.uid_bytes(key), ("spawner", key, s.adapter))
    for name, p in k.actor_paths.items():
        needles.setdefault(struct.pack("<Q", rcra.crc64_path(p)), ("actor_asset", rcra.hex64(rcra.crc64_path(p)), name))

    out_dir = a.out
    os.makedirs(out_dir, exist_ok=True)
    report = {"tool": TOOL_VERSION, "kit": KIT_RELEASE, "game": os.path.abspath(a.game), "filters": filters,
              "logs": [os.path.abspath(p) for p in a.log], "scripts": os.path.abspath(a.scripts or default_scripts_dir()),
              "knowledge": k.notes, "zones": [], "errors": []}
    totals: Dict[str, Dict[str, int]] = {}
    lines = []
    for zi, zname in enumerate(zones):
        zid = rcra.crc64_path(zname)
        try:
            e, header, raw = read_zone(toc, zid)
        except rcra.FormatError as ex:
            report["errors"].append({"zone": zname, "error": str(ex)})
            print("  [%d/%d] %s: %s" % (zi + 1, len(zones), zname, ex))
            continue
        if e is None:
            report["errors"].append({"zone": zname, "error": "not in toc"})
            continue
        z = {"zone": zname, "zone_id": rcra.hex64(zid), "span": e.span, "size": len(raw), "sha256": rcra.sha256(raw),
             "header": header.hex() if header else None, "dat1_at": rcra.find_dat1(raw), "sections": [], "hits": []}
        if header:
            schema, sizes = rcra.header_block_sizes(header)
            z["header_schema"] = "%08X" % schema
            z["header_sizes"] = sizes
            z["rivet_hook_ok"] = sum(sizes) == len(raw)
        dat = None
        if z["dat1_at"] >= 0:
            try:
                dat = rcra.Dat1.parse(raw, z["dat1_at"])
                z["dat1_type"] = "%08X" % dat.type_id
                z["sections"] = [{"tag": "%08X" % t, "name": rcra.section_name(t), "offset": dat.sections[t].offset,
                                  "size": dat.sections[t].size} for t in dat.order]
            except rcra.FormatError as ex:
                z["dat1_error"] = str(ex)
        # tool 1.1.0: the zone's own tables (zone.py). Only a zone that decodes and passes every rule can be patched.
        z["decode"] = decode_zone_report(raw, z["dat1_at"])
        for off, b in scan_aligned(raw, needles):
            kind, ident, label = needles[b]
            tag, rel = section_at(dat, off) if dat else (None, off)
            sname = rcra.section_name(tag) if tag is not None else "(outside DAT1 sections)"
            lo = max(0, off - 0x20)
            z["hits"].append({"kind": kind, "id": ident, "label": label, "section": sname, "rel": rel, "abs": off,
                              "context_at": lo, "context": hexdump(raw[lo:off + 0x40])})
            totals.setdefault(kind, {}).setdefault(sname, 0)
            totals[kind][sname] += 1
        # stride evidence for the template references in Script Vars
        rels = sorted({h["rel"] for h in z["hits"] if h["kind"] == "template" and h["section"] == "Zone Script Vars"})
        g = 0
        for x, y in zip(rels, rels[1:]):
            g = gcd(g, y - x)
        z["script_vars_template_refs"] = len(rels)
        z["script_vars_stride_gcd"] = g
        report["zones"].append(z)
        nh = len(z["hits"])
        dz = z["decode"]
        print("  [%d/%d] %-70s %8d bytes, %3d known value(s), %s%s" % (zi + 1, len(zones), zname, len(raw), nh,
              ("decoded: %d single-owner spawner reference(s), %d reference problem(s)" % (len(dz["spawner_refs"]), len(dz["reference_problems"])))
              if dz["ok"] else "not decodable (%s)" % dz["error"][:80],
              "" if z.get("rivet_hook_ok", True) else "  (header sizes != data: rivet_hook could not load a patched copy)"))
    toc.close()
    report["totals"] = totals
    with open(os.path.join(out_dir, "probe.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1)

    # human report
    lines.append("STAGE ENEMY PROBE (%s, tool %s) - %s" % (KIT_RELEASE, TOOL_VERSION, ", ".join(filters)))
    lines.append("zones probed: %d, errors: %d" % (len(report["zones"]), len(report["errors"])))
    lines.append("")
    lines.append("WHERE THE KNOWN VALUES ARE (4-byte aligned 64-bit matches)")
    for kind in ("template", "spawner", "actor_asset"):
        row = totals.get(kind, {})
        lines.append("  %-12s %s" % (kind, ", ".join("%s: %d" % (s, n) for s, n in sorted(row.items(), key=lambda x: -x[1])) or "none"))
    lines.append("")
    for z in report["zones"]:
        dz = z["decode"]
        if not z["hits"] and not (dz["ok"] and dz["spawner_refs"]) and not (dz["ok"] and dz["reference_problems"]):
            continue
        lines.append("ZONE %s (%s, %d bytes, DAT1 at %d, sections %d, rivet_hook-loadable: %s)" % (
            z["zone"], z["zone_id"], z["size"], z["dat1_at"], len(z["sections"]), z.get("rivet_hook_ok")))
        if not dz["ok"]:
            lines.append("  zone tables NOT decodable - nothing can be patched here: %s" % dz["error"])
        else:
            lines.append("  zone tables: %d actors (%d duplicate uids), %d actor assets (CRC64-verified), %d Script Vars, %d plugs, "
                         "%d actions; type-5 references %d %s, %d problem(s)" % (
                             dz["actors"], dz["duplicate_actor_uids"], dz["actor_assets"], dz["script_vars"], dz["plugs"],
                             dz["actions"], dz["type5"], dz["type5_forms"], len(dz["reference_problems"])))
            for pr in dz["reference_problems"][:10]:
                lines.append("  REFERENCE PROBLEM Script Vars #%d (zone +%d): %s" % (pr["var"], pr["abs"], pr["problem"]))
            for r in dz["spawner_refs"]:
                lines.append("  spawner %s  Templates -> Script Vars #%-5d uid %s  Zone Actors #%-4d %s (%s)" % (
                    r["owner"], r["var"], r["uid"], r["actor_index"], r["kind"], r["actor_name"]))
        if z["script_vars_template_refs"]:
            lines.append("  Script Vars: %d template reference(s), offsets gcd %d" % (z["script_vars_template_refs"], z["script_vars_stride_gcd"]))
        for h in z["hits"][:60]:
            lines.append("  %-11s %-18s %-34s %-24s +%-7d" % (h["kind"], h["id"], K.short(h["label"]), h["section"], h["rel"]))
        if len(z["hits"]) > 60:
            lines.append("  ... %d more in probe.json" % (len(z["hits"]) - 60))
    verdict = verdict_text(report)
    lines.append("")
    lines += verdict
    with open(os.path.join(out_dir, "probe_report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(verdict))
    print("written: %s, %s" % (os.path.join(out_dir, "probe.json"), os.path.join(out_dir, "probe_report.txt")))


def verdict_text(report) -> List[str]:
    t = report.get("totals", {}).get("template", {})
    sv = t.get("Zone Script Vars", 0)
    za = t.get("Zone Actors", 0)
    out = ["VERDICT"]
    dec = [z for z in report.get("zones", []) if z.get("decode", {}).get("ok")]
    refs = sum(len(z["decode"]["spawner_refs"]) for z in dec)
    bad = sum(len(z["decode"]["reference_problems"]) for z in dec)
    out.append("  zone tables decoded in %d of %d zone(s): %d single-owner spawner Templates reference(s), %d reference "
               "problem(s) in the game's own files" % (len(dec), len(report.get("zones", [])), refs, bad))
    if refs:
        out.append("  A single-spawner .stage patch (uid + Zone Actors index, one entry) is possible: run 'poc'.")
        return out
    if sv and za:
        out.append("  Template uids appear in Zone Script Vars (%d) and Zone Actors (%d): spawner variables reference their" % (sv, za))
        out.append("  template actor by uid ON DISK. A single-spawner .stage patch is possible: run 'poc'.")
    elif sv:
        out.append("  Template uids appear in Zone Script Vars (%d) but not in Zone Actors: the variable references are on disk," % sv)
        out.append("  but where the template actors are placed is not proven. 'poc' will only accept a replacement found in the same zone.")
    elif t:
        out.append("  Template uids appear only in %s - not in Zone Script Vars. Send probe_report.txt and probe.json:" % ", ".join(t))
        out.append("  the spawner variable format differs from the runtime one and must be decoded before any patch.")
    else:
        out.append("  No known template uid appears in these zones (4-byte aligned). Either the planet filter matched the wrong")
        out.append("  zones, or uids are not stored as plain 64-bit values on disk. Send probe_report.txt; nothing can be patched yet.")
    return out


def decode_zone_report(raw: bytes, dat1_at: int) -> Dict:
    """What probe.json keeps of a zone's decoded tables (zone.py): enough for poc to choose without guessing."""
    if dat1_at < 0:
        return {"ok": False, "error": "no DAT1 header"}
    try:
        zn = ZN.Zone.parse(raw, dat1_at)
    except rcra.FormatError as ex:
        return {"ok": False, "error": str(ex)}
    sm = zn.summary()
    tu = zn.template_uids()
    tinfo = {}
    for u in tu:
        a = zn.actor(int(u, 16))
        tinfo[u] = {"index": a.index, "kind": a.kind, "actor_name": a.name, "asset_path": a.asset_path, "prius": a.prius}
    return {"ok": True, "actors": sm["actors"], "duplicate_actor_uids": sm["duplicate_actor_uids"], "actor_assets": sm["actor_assets"],
            "script_vars": sm["script_vars"], "plugs": sm["plugs"], "actions": sm["actions"], "type5": sm["type5"],
            "type5_forms": sm["type5_forms"], "reference_problems": sm["reference_problems"], "spawner_refs": zn.spawner_refs(),
            "template_uids": tu, "templates": tinfo}


# ======================================================================================================================
# poc: choose one spawner reference and build the .stage
# ======================================================================================================================
def candidates(report, k: K.Knowledge, allow_same_faction: bool, prefer: List[str], spawner: Optional[str] = None,
               replacement: Optional[str] = None, original: Optional[str] = None, rejected: Optional[List[str]] = None) -> List[dict]:
    """Phase A candidates from the DECODED zone tables (tool 1.1.0). A candidate is one Script Vars entry that
      - is a valid local actor reference (uid and Zone Actors index agree) owned by exactly ONE plug in the zone, that
        plug being the Templates plug of one spawner node (C2),
      - names a regular enemy, identified by the zone's own actor asset (C3); the registry / your logs must not name
        that uid differently,
    and one replacement that is a Zone Actors record of the SAME zone already used as a Templates value by another
    spawner there (a proven template of this zone), same movement group, combat-verified pair (tier A) or, with
    --allow-same-faction, same faction (tier B). Your logs, when given, must agree with the zone about what the spawner
    held; they no longer decide anything on their own."""
    rej = rejected if rejected is not None else []
    out = []
    for z in report["zones"]:
        dz = z.get("decode") or {}
        if not dz.get("ok"):
            continue
        tinfo = dz["templates"]
        for ref in dz["spawner_refs"]:
            if spawner and ref["owner"].upper() != spawner.upper():
                continue
            if original and ref["uid"].upper() != original.upper():
                continue
            ua, na = ref["uid"], ref["kind"]
            where = "%s Script Vars #%d (spawner %s)" % (K.short(z["zone"]), ref["var"], ref["owner"])
            kt = k.templates.get(ua)
            if kt and K.short(kt.name) != na:
                rej.append("%s: the registry/logs name uid %s %s, the zone's actor asset is %s - identity disagrees" % (where, ua, kt.name, na))
                continue
            fa, ca, ra, srca, famsa = k.kind_info(na)
            if K.excluded(na) or ra not in (None, "enemy"):
                rej.append("%s: %s is not a regular enemy (role %s)" % (where, na, ra))
                continue
            if fa not in K.FAMILY_GROUP:
                rej.append("%s: the family of %s is %s (registry/logs: %s) - its movement group is not known" % (
                    where, na, fa or "unknown", famsa or "none"))
                continue
            ks = k.spawners.get(ref["owner"])
            if ks and ks.uids and ua not in ks.uids:
                rej.append("%s: your log saw this spawner's variable hold %s, the zone says %s - refused" % (where, sorted(ks.uids), ua))
                continue
            for ub, owners_b in sorted(tinfo.items()):
                if replacement and ub.upper() != replacement.upper():
                    continue
                if ub == ua:
                    continue
                ib = tinfo[ub]
                nb = ib["kind"]
                if (nb or "").lower() == (na or "").lower():
                    continue
                users_b = [o for o in dz["template_uids"].get(ub, []) if o != ref["owner"]]
                if not users_b:
                    rej.append("%s -> %s: no other spawner of the zone uses %s as its template" % (where, ub, nb))
                    continue
                kb = k.templates.get(ub)
                if kb and K.short(kb.name) != nb:
                    rej.append("%s -> %s: the registry/logs name it %s, the zone's actor asset is %s" % (where, ub, kb.name, nb))
                    continue
                fb, cb, rb, srcb, famsb = k.kind_info(nb)
                if K.excluded(nb) or rb not in (None, "enemy") or fb not in K.FAMILY_GROUP:
                    if replacement:
                        rej.append("%s -> %s (%s): not a regular enemy of a known movement group (family %s, role %s)" % (where, ub, nb, fb, rb))
                    continue
                if K.FAMILY_GROUP.get(fa) != K.FAMILY_GROUP.get(fb):
                    if replacement:
                        rej.append("%s -> %s: movement groups differ (%s %s, %s %s)" % (where, nb, na, fa, nb, fb))
                    continue
                st = k.pair_status_names(na, fa, nb, fb)
                if st and st[0] == "bad":
                    rej.append("%s -> %s: the pair is marked bad: %s" % (where, nb, st[1]))
                    continue
                tier = "A" if (st and st[0] == "ok") else "B"
                if tier == "B" and not (allow_same_faction and K.faction(na) == K.faction(nb)):
                    if replacement:
                        rej.append("%s -> %s: not a combat-verified pair (use --allow-same-faction for same-faction pairs)" % (where, nb))
                    continue
                held = bool(ks and ua in ks.uids)
                score = (10 if tier == "A" else 0) + (2 if held else 0) + (1 if users_b else 0)
                score += 1 if z.get("rivet_hook_ok") else -100
                score += 1 if any(p in z["zone"].lower() for p in prefer) else 0
                out.append({
                    "score": score, "tier": tier, "zone": z["zone"], "zone_id": z["zone_id"], "zone_sha256": z["sha256"],
                    "section": "Zone Script Vars", "var_index": ref["var"], "entry_rel": ref["rel"], "entry_abs": ref["abs"],
                    "rel": ref["rel"] + ZN.OFF_VALUE, "abs": ref["abs"] + ZN.OFF_VALUE,
                    "original_uid": ua, "original_index": ref["actor_index"], "original": na, "original_family": fa,
                    "original_actor_name": ref["actor_name"], "original_asset": ref["asset_path"],
                    "replacement_uid": ub, "replacement_index": ib["index"], "replacement": nb, "replacement_family": fb,
                    "replacement_actor_name": ib["actor_name"], "replacement_asset": ib["asset_path"],
                    "original_prius": tinfo[ua]["prius"] if ua in tinfo else None, "replacement_prius": ib["prius"],
                    "pair": K.pair_key("factory", na, fa, nb, fb),
                    "evidence": st[1] if st else "same faction (%s), not combat-verified" % K.faction(na),
                    "family_sources": {"original": srca, "replacement": srcb},
                    "owner": {"key": ref["owner"], "action": ref["owner_action"], "class": ref["owner_class"], "plug": ref["plug"]},
                    "replacement_used_by": users_b,
                    "original_refs_in_script_vars": len(dz["template_uids"].get(ua, [])),
                    "replacement_refs_in_script_vars": len(dz["template_uids"].get(ub, [])),
                    "spawner_keys": [ref["owner"]],
                    "spawner_keys_evidence": "zone tables: Script Actions #%d (key %s) -> Script Plugs #%d 'Templates' -> Script Vars #%d, "
                                             "the only plug of that variable%s" % (ref["owner_action"], ref["owner"], ref["plug"], ref["var"],
                                             "; your log saw its variable hold %s" % ua if held else ""),
                    "encounters": sorted(ks.encounters) if ks else [],
                    "encounters_of": "the spawner in spawner_keys (your logs)" if ks else "none in your logs",
                    "rivet_hook_ok": z.get("rivet_hook_ok"),
                })
    out.sort(key=lambda c: (-c["score"], c["zone"], c["entry_abs"], c["replacement_uid"]))
    return out


def lua_str(s) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def manifest_lua(m: dict) -> str:
    L = ["-- generated by tools/stage_enemies/stage_enemies.py %s (%s). DATA, not a script to edit." % (TOOL_VERSION, KIT_RELEASE),
         "-- It tells 18_rando_stage_enemies.lua which spawners the installed %s changed on disk." % STAGE_MOD_PATH,
         "-- Remove both with: python tools/stage_enemies/stage_enemies.py uninstall --game <game folder>",
         "RANDO_STAGE_ENEMIES = {",
         "  format = 1, tool = %s, kit = %s, label = %s, stage_lua = %s," % (lua_str(TOOL_VERSION), lua_str(KIT_RELEASE), lua_str(m["label"]),
                                                                            lua_str(STAGE_LUA)),
         "  stage_file = %s, stage_sha256 = %s," % (lua_str(STAGE_MOD_PATH), lua_str(m["stage_sha256"])),
         "  changes = {"]
    for c in m["changes"]:
        L.append("    { zone = %s, zone_id = %s, section = %s, offset = %d, var_index = %d," % (
            lua_str(c["zone"]), lua_str(c["zone_id"]), lua_str(c["section"]), c["entry_rel"], c["var_index"]))
        L.append("      original_uid = %s, original_index = %d, original = %s, original_family = %s," % (
            lua_str(c["original_uid"]), c["original_index"], lua_str(c["original"]), lua_str(c["original_family"])))
        L.append("      replacement_uid = %s, replacement_index = %d, replacement = %s, replacement_family = %s," % (
            lua_str(c["replacement_uid"]), c["replacement_index"], lua_str(c["replacement"]), lua_str(c["replacement_family"])))
        L.append("      original_refs = %d, replacement_refs = %d," % (
            c["original_refs_in_script_vars"], c["replacement_refs_in_script_vars"]))
        L.append("      pair = %s, spawner_keys = { %s } }," % (
            lua_str(c["pair"]), ", ".join(lua_str(x) for x in c["spawner_keys"])))
    L += ["  },", "}", ""]
    return "\n".join(L)


def hexrow(b: bytes) -> str:
    return " ".join("%02X" % x for x in b)


def static_report(c: dict, zone_check: dict, header: bytes, raw: bytes, new: bytes, stage_path: str, stage_sha: str,
                  member: str, reread_ok: bool) -> Tuple[List[str], List[str]]:
    """The human static-verification report and the exact byte-diff report of one build."""
    o, r = zone_check["orig"], zone_check["patched"]
    ch = zone_check["changes"][0]
    V = ["STATIC VERIFICATION - %s (stage tool %s, zone lib %s, %s)" % (os.path.basename(stage_path), TOOL_VERSION, ZN.ZONE_LIB_VERSION, KIT_RELEASE),
         "RESULT: %s" % ("PASS" if zone_check["ok"] and reread_ok else "FAIL"),
         "Static only: this proves the file is a correct, minimal, self-consistent change. It does not prove the game's behaviour.",
         "",
         "zone        %s (%s), span 0, %d bytes" % (c["zone"], c["zone_id"], len(raw)),
         "zone sha256 original %s" % rcra.sha256(raw),
         "            patched  %s" % rcra.sha256(new),
         "stage       %s sha256 %s, member %s (36-byte header + zone)" % (os.path.basename(stage_path), stage_sha, member),
         "",
         "THE CHANGE (one Script Vars entry, both halves of the actor reference)",
         "  spawner      %s (Script Actions #%d, class %s) -> Script Plugs #%d 'Templates' (crc32 %08X) -> Script Vars #%d" % (
             c["owner"]["key"], c["owner"]["action"], c["owner"]["class"], c["owner"]["plug"], ZN.PLUG_TEMPLATES, c["var_index"]),
         "  entry        Zone Script Vars +%d (zone +%d), 32 bytes" % (c["entry_rel"], c["entry_abs"]),
         "  original     uid %s + index %d = Zone Actors #%d %s -> %s" % (c["original_uid"], c["original_index"], c["original_index"],
                                                                         c["original_actor_name"], c["original_asset"]),
         "  replacement  uid %s + index %d = Zone Actors #%d %s -> %s" % (c["replacement_uid"], c["replacement_index"], c["replacement_index"],
                                                                         c["replacement_actor_name"], c["replacement_asset"]),
         "  pair         %s [tier %s] %s" % (c["pair"], c["tier"], c["evidence"]),
         "  replacement already the template of spawner(s) %s in this zone" % ", ".join(c["replacement_used_by"]),
         "  actor prius  original %s, replacement %s (per-template settings come with the template; informational)" % (
             c.get("original_prius"), c.get("replacement_prius")),
         "",
         "CHECKS"]
    rows = []
    for n, ok, d in o["checks"]:
        rows.append(("original zone: " + n, ok, d))
    for n, ok, d in r["checks"]:
        rows.append(("patched zone: " + n, ok, d))
    rows += [
        ("C1 original zone: every type-5 entry a known form, uid/index agree", not o["reference_problems"],
         "%d type-5 entries %s" % (o["type5"], o["type5_forms"])),
        ("C1 patched zone: every type-5 entry a known form, uid/index agree", not r["reference_problems"],
         "%d type-5 entries %s" % (r["type5"], r["type5_forms"])),
        ("C2 the variable has exactly one plug in the zone, the Templates plug of the intended spawner",
         len(ch.get("owners", [])) == 1 and ch["owners"][0]["plug_is_templates"] and ch["owners"][0]["key"] == c["spawner_keys"][0],
         ", ".join("%s plug #%d %08X" % (x["key"], x["plug"], x["plug_name"]) for x in ch.get("owners", []))),
        ("C3 identity from the zone: Zone Actors -> actor-asset table (CRC64-verified paths)",
         ch["original"]["kind"] == c["original"] and ch["replacement"]["kind"] == c["replacement"],
         "%s -> %s" % (ch["original"]["kind"], ch["replacement"]["kind"])),
        ("C4 the entry is the plain local form (type 5, aux FFFF, aux2 FFFF, tail 0) before and after",
         all(bytes.fromhex(ch[k])[0:2] == b"\x05\x00" and bytes.fromhex(ch[k])[2:4] == b"\xff\xff" and bytes.fromhex(ch[k])[6:8] == b"\xff\xff"
             and bytes.fromhex(ch[k])[24:32] == bytes(8) for k in ("before", "after")), "type 5, local, both"),
        ("C5 bytes changed only in {index, uid} of that one entry", zone_check["ok"] and ch["fields"] == ["actor_index", "uid"],
         "%d byte(s), fields %s" % (len(zone_check["diff"]), ch["fields"])),
        ("size unchanged, DAT1 header and section table byte-identical", len(raw) == len(new) and zone_check["ok"], "%d bytes" % len(new)),
        ("asset header block sizes add up to the zone (rivet_hook loads it)", sum(rcra.header_block_sizes(header)[1]) == len(new),
         "%s = %d" % (rcra.header_block_sizes(header)[1][:2], sum(rcra.header_block_sizes(header)[1]))),
        (".stage re-read: info.json RCRA, one member, header + zone byte-identical", reread_ok, member),
    ]
    width = max(len(n) for n, _, _ in rows)
    for n, ok, d in rows:
        V.append("  %-4s %-*s  %s" % ("ok" if ok else "FAIL", width, n, d))
    for p in zone_check["problems"]:
        V.append("  PROBLEM " + p)
    D = ["EXACT BYTE DIFF - %s, zone %s (%s)" % (os.path.basename(stage_path), c["zone"], c["zone_id"]),
         "offsets: zone = from the zone's first byte (DAT1 at %d); .stage member = zone + 36; Vars = from Zone Script Vars" % rcra.find_dat1(raw),
         "%d byte(s) differ, all in Script Vars #%d:" % (len(zone_check["diff"]), c["var_index"]),
         "  %-8s %-10s %-11s %-12s %-5s %-5s" % ("zone", "member", "Vars +", "field", "was", "now")]
    sv0 = c["entry_abs"] - c["entry_rel"]
    for pos in zone_check["diff"]:                  # compare_zones proved every one is in this entry's index / uid
        off = pos - c["entry_abs"]
        fname = next((n for n, (fo, fl) in ZN.REF_FIELDS.items() if fo <= off < fo + fl), "?")
        D.append("  +%-7d +%-9d +%-10d %-12s %02X    %02X" % (pos, pos + 36, pos - sv0, "%s[%d]" % (fname, off - ZN.REF_FIELDS[fname][0]) if fname != "?" else "?",
                                                         raw[pos], new[pos]))
    D += ["", "entry before  %s" % hexrow(raw[c["entry_abs"]:c["entry_abs"] + 32]),
          "entry after   %s" % hexrow(new[c["entry_abs"]:c["entry_abs"] + 32]),
          "              type  aux   index aux2  name (u64)              uid (u64)               tail (u64)",
          "index  %d (%02X %02X) -> %d (%02X %02X)" % (c["original_index"], c["original_index"] & 255, c["original_index"] >> 8,
                                                     c["replacement_index"], c["replacement_index"] & 255, c["replacement_index"] >> 8),
          "uid    %s -> %s (little-endian on disk)" % (c["original_uid"], c["replacement_uid"]),
          "every other byte of the zone, the 36-byte header and the DAT1 section table: identical"]
    return V, D


def cmd_poc(a) -> None:
    with open(a.probe, "r", encoding="utf-8") as f:
        report = json.load(f)
    if not any("decode" in z for z in report.get("zones", [])):
        die("%s was written by stage tool %s, before zone decoding (1.1.0): run 'probe' again with this tool" % (
            a.probe, report.get("tool", "?")))
    out_stage = os.path.join(a.out, STAGE_NAME)
    if os.path.exists(out_stage) or os.path.exists(os.path.join(a.out, "stage_enemies_manifest.json")):
        die("%s already holds a build: pass a NEW --out folder (earlier builds are never overwritten)" % a.out)
    logs = a.log or [p for p in report.get("logs", []) if os.path.isfile(p)]
    k = load_knowledge(a.scripts or report.get("scripts") or default_scripts_dir(), logs)
    rejected: List[str] = []
    cands = candidates(report, k, a.allow_same_faction, [p.lower() for p in (a.prefer or [])], a.spawner, a.replacement,
                       a.original, rejected)
    rejected = list(dict.fromkeys(rejected))
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "poc_candidates.json"), "w", encoding="utf-8") as f:
        json.dump({"candidates": cands[:200], "rejected": rejected[:400]}, f, indent=1)
    if not cands:
        for r in rejected[:20]:
            print("  rejected: " + r)
        die("no spawner reference in the probed zones satisfies the Phase A rules (single-owner Templates variable, valid "
            "uid+index reference, replacement a template of the same zone, combat-verified pair, same movement group, "
            "rivet_hook-loadable zone)%s. See poc_candidates.json." % (" for the --spawner/--replacement/--original you gave"
                                                                       if (a.spawner or a.replacement or a.original) else ""))
    print("Phase A candidates (best first):")
    for i, c in enumerate(cands[:15]):
        print("  [%d] score %2d tier %s  %s  Script Vars #%d  spawner %s  %s #%d -> %s #%d  (%s)" % (
            i, c["score"], c["tier"], K.short(c["zone"]), c["var_index"], c["spawner_keys"][0], K.short(c["original"]),
            c["original_index"], K.short(c["replacement"]), c["replacement_index"], c["evidence"][:50]))
    if a.pick >= len(cands):
        die("--pick %d: only %d candidate(s)" % (a.pick, len(cands)))
    c = cands[a.pick]
    if c["score"] < 0:
        die("the chosen candidate's zone cannot be loaded by rivet_hook as a patched copy (header sizes != data)")

    toc, _ = open_game(a.game)
    zid = int(c["zone_id"], 16)
    e, header, raw = read_zone(toc, zid)
    toc.close()
    if e is None or header is None:
        die("zone %s is not in the toc (or has no asset header)" % c["zone"])
    if rcra.sha256(raw) != c["zone_sha256"]:
        die("zone %s changed since the probe (game update?) - probe again" % c["zone"])
    schema, sizes = rcra.header_block_sizes(header)
    if sum(sizes) != len(raw):
        die("asset header block sizes %s add up to %d, the zone has %d bytes: rivet_hook would refuse it" % (sizes, sum(sizes), len(raw)))
    try:
        zn = ZN.Zone.parse(raw, rcra.find_dat1(raw))
        ref0 = zn.reference_report()
        if not ref0["ok"]:
            die("the game's own zone breaks the reference rule (%s): nothing is patched in it" % ref0["problems"][:2])
        changes, info = ZN.plan_swap(zn, c["var_index"], int(c["replacement_uid"], 16), c["spawner_keys"][0])
    except rcra.FormatError as ex:
        die("zone %s: %s" % (c["zone"], ex))
    if info["original"]["uid"] != c["original_uid"] or info["replacement"]["index"] != c["replacement_index"]:
        die("internal: the zone read now does not match the probe's tables")
    new = ZN.apply_changes(raw, changes)
    chk = ZN.compare_zones(raw, new, zn.base)
    planned = sorted(p for ch in changes for p in range(ch.abs, ch.abs + len(ch.new)) if raw[p] != new[p])
    if not chk["ok"] or chk["diff"] != planned or len(chk["changes"]) != 1:
        for p in chk["problems"]:
            print("PROBLEM: " + p)
        die("the patched zone fails the static checks - nothing written")

    bdir = os.path.join(a.out, "backup")
    os.makedirs(bdir, exist_ok=True)
    orig_blob = header + raw
    bpath = os.path.join(bdir, "%s.zone.orig" % c["zone_id"])
    with open(bpath, "wb") as f:
        f.write(orig_blob)
    with open(bpath + ".sha256", "w") as f:
        f.write("%s  %s\n" % (rcra.sha256(orig_blob), os.path.basename(bpath)))
    desc = "Phase A: %s Script Vars #%d (spawner %s) %s #%d -> %s #%d (uid + Zone Actors index)" % (
        K.short(c["zone"]), c["var_index"], c["spawner_keys"][0], K.short(c["original"]), c["original_index"],
        K.short(c["replacement"]), c["replacement_index"])
    entry = rcra.StageEntry(0, zid, header, new, c["zone"])
    rcra.write_stage(out_stage, "Rift Apart Randomizer - Enemy .stage (%s, tool %s)" % (KIT_RELEASE, TOOL_VERSION),
                     "Rift Apart Randomizer", desc, [entry])
    with open(out_stage, "rb") as f:
        stage_sha = rcra.sha256(f.read())
    info_j, files = rcra.read_stage(out_stage)
    reread_ok = (info_j.get("game") == rcra.STAGE_GAME_ID and list(files) == [entry.zip_name()]
                 and files[entry.zip_name()] == header + new)
    V, D = static_report(c, chk, header, raw, new, out_stage, stage_sha, entry.zip_name(), reread_ok)
    if not reread_ok:
        die("the written .stage does not read back as written")
    m = {"format": 1, "tool": TOOL_VERSION, "zone_lib": ZN.ZONE_LIB_VERSION, "kit": KIT_RELEASE, "stage_lua": STAGE_LUA,
         "label": "Phase A single spawner (uid + index)", "stage_sha256": stage_sha, "static_verification": "PASS",
         "changes": [dict(c, changed_bytes=len(chk["diff"]), changed_fields=chk["changes"][0]["fields"],
                          entry_before=chk["changes"][0]["before"], entry_after=chk["changes"][0]["after"],
                          byte_diff=[{"zone": p, "member": p + 36, "was": "%02X" % raw[p], "now": "%02X" % new[p]} for p in chk["diff"]],
                          zone_sha256_original=c["zone_sha256"], zone_sha256_patched=rcra.sha256(new),
                          zone_reference_forms_original=chk["orig"]["type5_forms"], zone_reference_forms_patched=chk["patched"]["type5_forms"])]}
    with open(os.path.join(a.out, "stage_enemies_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=1)
    with open(os.path.join(a.out, MANIFEST_LUA), "w", encoding="utf-8") as f:
        f.write(manifest_lua(m))
    with open(os.path.join(a.out, "STATIC_VERIFICATION.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(V) + "\n")
    with open(os.path.join(a.out, "BYTE_DIFF.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(D) + "\n")
    print("")
    print("BUILT %s (sha256 %s)" % (out_stage, stage_sha))
    print("  zone        %s (%s), %d bytes, header kept" % (c["zone"], c["zone_id"], len(raw)))
    print("  change      Script Vars #%d (+%d): uid %s -> %s AND Zone Actors index %d -> %d, %d byte(s) differ" % (
        c["var_index"], c["entry_rel"], c["original_uid"], c["replacement_uid"], c["original_index"], c["replacement_index"], len(chk["diff"])))
    print("              %s (%s) -> %s (%s)" % (c["original"], c["original_actor_name"], c["replacement"], c["replacement_actor_name"]))
    print("  spawner     %s - %s" % (c["spawner_keys"][0], c["spawner_keys_evidence"]))
    print("  pair        %s [%s] %s" % (c["pair"], c["tier"], c["evidence"]))
    print("  test where  %s" % ("; ".join(c["encounters"]) or "not in your logs (this spawner's encounter)"))
    print("  static      PASS - %s, %s" % (os.path.join(a.out, "STATIC_VERIFICATION.txt"), os.path.join(a.out, "BYTE_DIFF.txt")))
    print("  backup      %s" % bpath)
    print("next: python stage_enemies.py verify --game GAME --stage %s ; then install --game GAME --build %s" % (out_stage, a.out))


# ======================================================================================================================
# verify: the .stage against the game's originals and the other installed mods
# ======================================================================================================================
def toml_asset_paths(toml_text: str) -> Optional[List[str]]:
    m = re.search(r"^\[assets\][^\[]*?^\s*paths\s*=\s*\[(.*?)\]", toml_text, re.S | re.M)
    if not m:
        return None
    return re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))


def mod_asset_ids(game: str, rel: str) -> Dict[int, str]:
    """Asset ids (span 0..255 dirs, hex names or hashed paths) a listed mod path provides."""
    p = os.path.join(game, rel)
    out: Dict[int, str] = {}

    def add(path_in_mod: str):
        parts = re.split(r"[\\/]", path_in_mod)
        for i, s in enumerate(parts):
            if s.isdigit() and int(s) <= 255:
                rest = "/".join(parts[i + 1:])
                if not rest:
                    return
                name = parts[-1]
                aid = int(name, 16) if re.fullmatch(r"[0-9A-Fa-f]{16}", name) else rcra.crc64_path(rest)
                out[aid] = path_in_mod
                return
    if os.path.isfile(p) and p.lower().endswith(".stage"):
        import zipfile
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n != "info.json" and not n.endswith("/"):
                    add(n)
    elif os.path.isdir(p):
        for root, _, files in os.walk(p):
            for fn in files:
                add(os.path.relpath(os.path.join(root, fn), p))
    return out


LUA_STAMP_RE = re.compile(r'RANDO_FILES\["([^"]+)"\]\s*=\s*"([^"]+)"')
STAGE_LUA_RE = re.compile(r'(?:V|ST)\.STAGE_LUA\s*=\s*"([^"]+)"')


def lua_info(path: str) -> Dict:
    if not os.path.isfile(path):
        return {"present": False}
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()
    m = LUA_STAMP_RE.search(src)
    s = STAGE_LUA_RE.search(src)
    return {"present": True, "stamp": m.group(2) if m else None, "stage_lua": s.group(1) if s else None}


def scripts_problems(scripts_dir: str, kit_scripts: str) -> Tuple[List[str], List[str]]:
    """The game's scripts folder must hold the Lua side this .stage needs: 16_rando_spawners.lua and
    18_rando_stage_enemies.lua of the kit's version, both with the handle/uid checks (STAGE_LUA). The Phase A POC ran
    without 18_rando_stage_enemies.lua (no RANDO-STAGE line at all) and nothing said so: the kit check names a missing
    developer-only script on purpose, so this is checked here, before install, and again in the game by 16."""
    problems, notes = [], []
    kit16 = lua_info(os.path.join(kit_scripts, "16_rando_spawners.lua"))
    for f in ("16_rando_spawners.lua", "18_rando_stage_enemies.lua"):
        g = lua_info(os.path.join(scripts_dir, f))
        if not g["present"]:
            problems.append("%s is not in %s: %s" % (f, scripts_dir, "the runtime route would keep writing spawners" if f.startswith("16")
                            else "the in-game .stage check would not run (no RANDO-STAGE lines) - copy it from the kit's scripts folder"))
            continue
        if kit16.get("stamp") and g["stamp"] != kit16["stamp"]:
            problems.append("%s is kit %s, this kit is %s: copy the kit's scripts folder" % (f, g["stamp"], kit16["stamp"]))
        if g["stage_lua"] != STAGE_LUA:
            problems.append("%s is not the stage-tool %s Lua (it says %s): copy the updated file from the kit's scripts folder" % (
                f, STAGE_LUA, g["stage_lua"] or "nothing"))
        else:
            notes.append("%s: kit %s, stage Lua %s" % (f, g["stamp"], g["stage_lua"]))
    return problems, notes


def check_stage_members(files: Dict[str, bytes], original_of, label_of) -> Tuple[List[str], List[str], List[Dict]]:
    """Every member of a .stage against its original zone (zone.compare_zones). original_of(span, aid) -> (header, raw)."""
    problems, notes, changes = [], [], []
    for n, blob in sorted(files.items()):
        m = re.fullmatch(r"(\d+)/([0-9A-Fa-f]{16})", n)
        if not m:
            problems.append("%s: not 'span/16-hex-id'" % n)
            continue
        span, aid = int(m.group(1)), int(m.group(2), 16)
        got = original_of(span, aid)
        label = label_of(aid)
        if got is None:
            problems.append("%s: no such asset in the original" % n)
            continue
        oh, oraw = got
        h, raw = blob[:rcra.ASSET_HEADER_SIZE], blob[rcra.ASSET_HEADER_SIZE:]
        if oh is not None and h != oh:
            problems.append("%s: asset header differs from the game's" % label)
        _, sizes = rcra.header_block_sizes(h)
        if sum(sizes) != len(raw):
            problems.append("%s: header block sizes add to %d, data %d (rivet_hook rejects it)" % (label, sum(sizes), len(raw)))
        res = ZN.compare_zones(oraw, raw)
        for p in res["problems"]:
            problems.append("%s: %s" % (label, p))
        if res["orig"]:
            notes.append("%s: original zone tables OK (%d type-5 references %s); patched: %d problem(s)" % (
                label, res["orig"]["type5"], res["orig"]["type5_forms"], len(res["patched"]["reference_problems"]) if res["patched"] else -1))
        notes.append("%s: %d byte(s) differ" % (label, len(res["diff"])))
        for ch in res["changes"]:
            own = ch.get("owners") or []
            o, r = ch.get("original") or {}, ch.get("replacement") or {}
            notes.append("    Script Vars #%d (+%d) fields %s, owner %s: uid %s index %s (%s) -> uid %s (record %s, %s) index %s (%s)" % (
                ch["var"], ch["entry_rel"], ch["fields"], ",".join("%s/plug %d" % (x["key"], x["plug"]) for x in own) or "?",
                o.get("uid"), o.get("index"), o.get("kind"), r.get("uid"), r.get("uid_record"), r.get("kind"), r.get("index"),
                r.get("index_kind")))
            changes.append(dict(ch, asset=n))
    return problems, notes, changes


def cmd_verify(a) -> int:
    info, files = rcra.read_stage(a.stage)
    problems, notes = [], []
    if info.get("game") != rcra.STAGE_GAME_ID:
        problems.append("info.json game is %r, not RCRA" % info.get("game"))
    toc, dag = open_game(a.game)
    names = {}
    if dag:
        names = {dag.ids[i]: dag.names[i] for i in range(dag.count)}

    def original_of(span, aid):
        e = toc.find(aid, span)
        return None if e is None else (toc.header(e), toc.read(e))
    p_, n_, changes = check_stage_members(files, original_of, lambda aid: names.get(aid, rcra.hex64(aid)))
    problems += p_
    notes += n_
    toc.close()
    # the manifest built with this .stage must describe exactly these changes
    mpath = os.path.join(os.path.dirname(os.path.abspath(a.stage)), "stage_enemies_manifest.json")
    if os.path.isfile(mpath):
        with open(mpath, "r", encoding="utf-8") as f:
            man = json.load(f)
        with open(a.stage, "rb") as f:
            sha = rcra.sha256(f.read())
        if man.get("stage_sha256") != sha:
            problems.append("stage_enemies_manifest.json is for another .stage (sha256 %s, this one %s)" % (man.get("stage_sha256"), sha))
        want = sorted((c.get("var_index"), c.get("original_uid"), c.get("original_index"), c.get("replacement_uid"), c.get("replacement_index"))
                      for c in man.get("changes", []))
        got = sorted((c["var"], (c.get("original") or {}).get("uid"), (c.get("original") or {}).get("index"),
                      (c.get("replacement") or {}).get("uid"), (c.get("replacement") or {}).get("index")) for c in changes)
        if want != got:
            problems.append("the manifest's changes %s are not the .stage's %s" % (want, got))
        else:
            notes.append("manifest: matches the .stage (sha256 and every change)")
        for c in man.get("changes", []):
            own = [x for x in changes if x["var"] == c.get("var_index")]
            if own and [o["key"] for o in own[0].get("owners", [])] != c.get("spawner_keys"):
                problems.append("the manifest's spawner_keys %s are not the variable's owner %s" % (
                    c.get("spawner_keys"), [o["key"] for o in own[0].get("owners", [])]))
    else:
        notes.append("no stage_enemies_manifest.json next to the .stage: the manifest was not cross-checked")
    # the Lua side in the game folder
    sp, sn = scripts_problems(os.path.join(a.game, "scripts"), a.scripts or default_scripts_dir())
    problems += sp
    notes += sn
    # rivet.toml
    tpath = os.path.join(a.game, "rivet.toml")
    ids = [int(m.group(2), 16) for m in (re.fullmatch(r"(\d+)/([0-9A-Fa-f]{16})", n) for n in files) if m]
    if os.path.isfile(tpath):
        with open(tpath, "r", encoding="utf-8", errors="replace") as f:
            paths = toml_asset_paths(f.read())
        if paths is None:
            notes.append("rivet.toml: no [assets] paths list found")
        else:
            mine = [p for p in paths if p.replace("\\", "/").lower().endswith(STAGE_NAME.lower())]
            notes.append("rivet.toml [assets] paths: %s" % paths)
            if mine and paths.index(mine[0]) != len(paths) - 1:
                problems.append("%s is not the LAST [assets] path: a later mod would win over it" % mine[0])
            for p in paths:
                if p in mine:
                    continue
                other = mod_asset_ids(a.game, p)
                clash = [rcra.hex64(i) for i in ids if i in other]
                if clash:
                    problems.append("%s also replaces %s - the two mods cannot both change this zone" % (p, ", ".join(clash)))
    for n in notes:
        print(n)
    for p in problems:
        print("PROBLEM: " + p)
    print("VERIFY %s: %s" % (os.path.basename(a.stage), "OK (static)" if not problems else "%d problem(s)" % len(problems)))
    return 0 if not problems else EXIT_REFUSED


def cmd_check_zone(a) -> int:
    """Read-only, no game folder: the zone rules on zone files (header + zone, as in backup/<id>.zone.orig) or on the
    zone members of a .stage; with --original, the .stage/zone is also compared with that original byte for byte."""
    bad = 0
    orig = None
    if a.original:
        with open(a.original, "rb") as f:
            ob = f.read()
        orig = ob[rcra.ASSET_HEADER_SIZE:] if rcra.find_dat1(ob) == rcra.ASSET_HEADER_SIZE else ob
    for path in a.files:
        with open(path, "rb") as f:
            b = f.read()
        if b[:2] == b"PK":
            _, files = rcra.read_stage(path)
            items = [(path + ":" + n, blob[rcra.ASSET_HEADER_SIZE:]) for n, blob in sorted(files.items())]
        else:
            items = [(path, b[rcra.ASSET_HEADER_SIZE:] if rcra.find_dat1(b) == rcra.ASSET_HEADER_SIZE else b)]
        for label, raw in items:
            print("== " + label)
            try:
                z = ZN.Zone.parse(raw)
            except rcra.FormatError as ex:
                print("  NOT DECODABLE: %s" % ex)
                bad += 1
                continue
            for n, ok, d in z.checks:
                print("  %-4s %s  %s" % ("ok" if ok else "FAIL", n, d))
            r = z.reference_report()
            print("  %-4s C1 every type-5 entry a known form, uid/index agree  %d %s" % ("ok" if r["ok"] else "FAIL", r["type5"], r["forms"]))
            for p in r["problems"]:
                print("       Script Vars #%d (zone +%d): %s" % (p["var"], p["abs"], p["problem"]))
                for o in z.owners(p["var"]):
                    print("         owned by %s via plug #%d %s" % (o["key"], o["plug"], "Templates" if o["plug_is_templates"] else "%08X" % o["plug_name"]))
            bad += 0 if r["ok"] else 1
            if orig is not None:
                res = ZN.compare_zones(orig, raw)
                print("  %-4s against the original: %d byte(s) differ, changes %s" % (
                    "ok" if res["ok"] else "FAIL", len(res["diff"]), [(c["var"], c["fields"]) for c in res["changes"]]))
                for p in res["problems"]:
                    print("       " + p)
                bad += 0 if res["ok"] else 1
    print("CHECK-ZONE: %s" % ("PASS" if not bad else "FAIL (%d)" % bad))
    return 0 if not bad else 1


# ======================================================================================================================
# install / uninstall
# ======================================================================================================================
def edit_toml_paths(game: str, add: bool) -> str:
    tpath = os.path.join(game, "rivet.toml")
    if not os.path.isfile(tpath):
        return "rivet.toml not found: add \"%s\" as the LAST entry of [assets] paths yourself" % STAGE_MOD_PATH
    with open(tpath, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    m = re.search(r"(^\[assets\][^\[]*?^\s*paths\s*=\s*\[)(.*?)(\])", text, re.S | re.M)
    if not m:
        return "rivet.toml has no [assets] paths list: add paths = [\"%s\"] under [assets] yourself" % STAGE_MOD_PATH
    items = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(2))
    items = [p for p in items if p.replace("\\", "/").lower() != STAGE_MOD_PATH.lower()]
    if add:
        items.append(STAGE_MOD_PATH)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    n = 1
    while os.path.exists(tpath + ".bak-stage-" + stamp):        # never overwrite an earlier backup
        n += 1
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + "-%d" % n
    shutil.copy2(tpath, tpath + ".bak-stage-" + stamp)
    new = text[:m.start(2)] + ", ".join('"%s"' % p for p in items) + text[m.end(2):]
    with open(tpath, "w", encoding="utf-8") as f:
        f.write(new)
    return "rivet.toml [assets] paths = %s (backup rivet.toml.bak-stage-%s)" % (items, stamp)


def cmd_install(a) -> None:
    src_stage = os.path.join(a.build, STAGE_NAME)
    src_lua = os.path.join(a.build, MANIFEST_LUA)
    for p in (src_stage, src_lua):
        if not os.path.isfile(p):
            die("missing %s (run 'poc' first)" % p)
    # tool 1.1.0: install = verify first. Every static rule, the manifest, the Lua side (16 and 18 with the stage-tool
    # checks) and rivet.toml must pass, or nothing is copied.
    print("verify before install:")
    code = cmd_verify(argparse.Namespace(game=a.game, stage=src_stage, scripts=getattr(a, "scripts", None), log=[]))
    if code != 0:
        die("verify found problems (above): nothing was installed")
    sd = os.path.join(a.game, "scripts")
    os.makedirs(os.path.join(a.game, "mods"), exist_ok=True)
    dst = os.path.join(a.game, "mods", STAGE_NAME)
    if os.path.isfile(dst):                       # an earlier build (e.g. the 1.0.1 POC) is kept, never overwritten
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        bak = dst + ".bak-" + stamp
        n = 1
        while os.path.exists(bak):
            n += 1
            bak = dst + ".bak-%s-%d" % (stamp, n)
        shutil.copy2(dst, bak)
        print("kept the installed %s as %s" % (STAGE_NAME, bak))
    shutil.copy2(src_stage, dst)
    shutil.copy2(src_lua, os.path.join(sd, MANIFEST_LUA))
    print("copied %s -> mods/%s" % (src_stage, STAGE_NAME))
    print("copied %s -> scripts/%s" % (src_lua, MANIFEST_LUA))
    print(edit_toml_paths(a.game, True))
    print("installed. rivet.log must now show: [loader] mod path %s is overstrike stage format." % STAGE_MOD_PATH)


def cmd_uninstall(a) -> None:
    for p in (os.path.join(a.game, "mods", STAGE_NAME), os.path.join(a.game, "scripts", MANIFEST_LUA)):
        if os.path.isfile(p):
            os.remove(p)
            print("removed " + p)
    print(edit_toml_paths(a.game, False))


# ======================================================================================================================
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("selftest")
    s = sub.add_parser("levels"); s.add_argument("--game", required=True); s.add_argument("--filter", default="")
    s = sub.add_parser("probe"); s.add_argument("--game", required=True); s.add_argument("--planet", action="append", required=True)
    s.add_argument("--log", action="append", default=[]); s.add_argument("--scripts"); s.add_argument("--out", default="probe_out")
    s.add_argument("--limit", type=int, default=0)
    s = sub.add_parser("poc"); s.add_argument("--game", required=True); s.add_argument("--probe", required=True)
    s.add_argument("--log", action="append", default=[]); s.add_argument("--scripts"); s.add_argument("--out", default="poc_out")
    s.add_argument("--pick", type=int, default=0); s.add_argument("--allow-same-faction", action="store_true")
    s.add_argument("--prefer", action="append", default=[])
    s.add_argument("--spawner", help="only this spawner key (the owner of the Templates variable)")
    s.add_argument("--replacement", help="only this replacement template uid")
    s.add_argument("--original", help="only this original template uid")
    s = sub.add_parser("verify"); s.add_argument("--game", required=True); s.add_argument("--stage", required=True)
    s.add_argument("--log", action="append", default=[], help="(accepted for compatibility; identity now comes from the zone)")
    s.add_argument("--scripts")
    s = sub.add_parser("check-zone"); s.add_argument("files", nargs="+"); s.add_argument("--original")
    s = sub.add_parser("install"); s.add_argument("--game", required=True); s.add_argument("--build", required=True)
    s.add_argument("--scripts")
    s = sub.add_parser("uninstall"); s.add_argument("--game", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "selftest":
        import selftest
        return selftest.run()
    return {"levels": cmd_levels, "probe": cmd_probe, "poc": cmd_poc, "verify": cmd_verify, "check-zone": cmd_check_zone,
            "install": cmd_install, "uninstall": cmd_uninstall}[a.cmd](a) or 0


if __name__ == "__main__":
    sys.exit(main())
