# tools/stage_enemies - the .stage Enemy Randomizer companion (v0.76-DEV4, tool 1.1.0)

Python 3.9+, standard library only. Full description, evidence and the Phase A test: `docs/STAGE_ENEMY_RANDOMIZER.md`.

```
python stage_enemies.py selftest
python stage_enemies.py levels    --game GAME --filter zurkon
python stage_enemies.py probe     --game GAME --planet zurkon [--log rivet.log ...]
python stage_enemies.py poc       --game GAME --probe probe_out/probe.json --out NEW_DIR [--spawner KEY] [--replacement UID] [--pick N]
python stage_enemies.py verify    --game GAME --stage NEW_DIR/RandoEnemies.stage
python stage_enemies.py check-zone NEW_DIR/RandoEnemies.stage --original NEW_DIR/backup/<id>.zone.orig
python stage_enemies.py install   --game GAME --build NEW_DIR          (runs verify first)
python stage_enemies.py uninstall --game GAME
```

GAME = the folder holding RiftApart.exe, `toc` and `dag`. Only `install` / `uninstall` write there.
Exit code 2 = refused (the reason is printed); nothing was written to the game folder.

| File | |
|---|---|
| stage_enemies.py | the commands |
| rcra.py | toc / DSAR (LZ4) / dag / DAT1 / asset header readers, CRC32 / CRC64, .stage writer - each structure cites its source |
| zone.py | (1.1.0) a zone's actor and script tables decoded and checked; the reference = uid + Zone Actors index; plan_swap, compare_zones |
| knowledge.py | template uids, combat pairs, spawner keys and actor paths read from 16_rando_spawners.lua and rivet.logs |
| selftest.py, fakegame.py | the self-test and its synthetic game folder and zones (format-consistency only, not real game data) |
