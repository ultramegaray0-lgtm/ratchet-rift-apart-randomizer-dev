"""zone.py - a level zone's actor and script tables, decoded and CHECKED (stage tool 1.1.0).

Part of the .stage Enemy Randomizer (tools/stage_enemies). Python 3.9+, standard library only. Read-only: nothing here
writes a file. stage_enemies.py builds its patch through plan_swap() and accepts a patched zone only through
compare_zones().

WHY THIS MODULE EXISTS (Phase A, first in-game run). Tool 1.0.x treated a spawner's template reference as one 8-byte uid
and replaced only that. A zone-local actor reference in Zone Script Vars is TWO fields that must agree: the actor's uid
(entry +16) and its Zone Actors record index (entry +4). The POC changed the uid and left the index, the game spawned the
actor the index names, and every static check passed because none of them decoded the entry. Here a reference is the
pair, every zone is checked for the pair rule before and after a change, and a patch may touch nothing else.

LAYOUTS (each one is checked against the zone it is read from; a zone that does not fit is refused, never guessed at)
  Zone Script Vars  (D86A7934)  32-byte entries {u16 type, u16 aux, u16 actor_index, u16 aux2, u64 name, u64 value,
                                u64 0}. Type 5 = actor reference. Four forms are known (KNOWN_FORMS below); every type-5
                                entry of a zone must be one of them.
  Zone Script Plugs (BEAB52E7)  12-byte records {u32 plug name crc32, u32 Script Vars index, u32 kind} from +0. The
                                section is exactly records * 12. (The root-cause report read them from +8, one record
                                off; checked here: from +0 the action ranges partition all plugs exactly once.)
  Zone Script Actions (5E54ACCF) 40-byte records {u64 key, u64 key2, u16, u16 first_b, u16 count_b, u16 first_a,
                                u16 count_a, u16, u32 class, u32, u32}. Each action owns plugs [first, first+count) of
                                both ranges (first 0xFFFF = none, count must then be 0). Required: every plug is owned
                                by exactly one action range, and action keys are unique.
  Zone Actors (70682CB8)        32-byte records {u32 name index, u32 actor-asset index, u32 scene offset, u32 prius
                                index, u32, u32 flags, u64 uid}. A uid on two records makes every reference to it
                                ambiguous: such uids are reported and never patched to or from.
  actor-asset table (78684035)  n * u64 asset id, then n * u32 DAT1 string offset of the asset path. Required for every
                                entry: CRC64(path) == id. This proves both the layout and the CRC64 on the zone itself.
  Zone Actor Names (DC625B3D)   u32 DAT1 string offsets; Zone Actors' name index points here.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import rcra

ZONE_LIB_VERSION = "1.1.0"

SCRIPT_VARS = rcra.SEC["Zone Script Vars"]
SCRIPT_PLUGS = rcra.SEC["Zone Script Plugs"]
SCRIPT_ACTIONS = rcra.SEC["Zone Script Actions"]
ZONE_ACTORS = rcra.SEC["Zone Actors"]
ACTOR_NAMES = rcra.SEC["Zone Actor Names"]
ACTOR_ASSETS = rcra.ZONE_ACTOR_ASSET_TABLE
REQUIRED = (SCRIPT_VARS, SCRIPT_PLUGS, SCRIPT_ACTIONS, ZONE_ACTORS, ACTOR_NAMES, ACTOR_ASSETS)

VAR_SIZE, PLUG_SIZE, ACTION_SIZE, ACTOR_SIZE = 32, 12, 40, 32
VAR_TYPE_ACTOR = 5
NONE16 = 0xFFFF
# entry field offsets of a Script Vars entry: the TWO halves of an actor reference
OFF_TYPE, OFF_AUX, OFF_INDEX, OFF_AUX2, OFF_NAME, OFF_VALUE, OFF_TAIL = 0, 2, 4, 6, 8, 16, 24
REF_FIELDS = {"actor_index": (OFF_INDEX, 2), "uid": (OFF_VALUE, 8)}

# the plug names the randomizer uses (crc32_engine of the name; the self-test checks them against the game's values)
PLUG_TEMPLATES = rcra.crc32_engine("Templates")
if PLUG_TEMPLATES != 3990217346:                       # rivet_hook / 16_rando_spawners.lua V.PLUG_TEMPLATES
    raise rcra.FormatError("crc32_engine('Templates') = %d, the game's plug hash is 3990217346" % PLUG_TEMPLATES)

# type-5 entry forms. "local" is the only one a Phase A patch may read or write.
FORM_LOCAL = "local"          # aux FFFF, aux2 FFFF, uid of a Zone Actors record of this zone, actor_index = that record
FORM_EXTERNAL = "external"    # aux FFFF, aux2 FFFF, uid not an actor of this zone, actor_index FFFF
FORM_GROUP = "group"          # aux set, aux2 FFFF, uid 0, actor_index FFFF (undecoded: never touched)
FORM_EMPTY = "empty"          # aux FFFF, aux2 FFFF, uid 0, actor_index FFFF
KNOWN_FORMS = (FORM_LOCAL, FORM_EXTERNAL, FORM_GROUP, FORM_EMPTY)


class ZoneError(rcra.FormatError):
    """The zone does not have the structure this module checks for. Nothing is patched in such a zone."""


def short_asset(path: Optional[str]) -> Optional[str]:
    if not path:
        return None
    n = path.replace("\\", "/").split("/")[-1]
    return n[:-6] if n.lower().endswith(".actor") else n


@dataclass
class Actor:
    index: int
    name_index: int
    asset_index: int
    scene_offset: int
    prius: int
    flags: int
    uid: int
    name: str = ""            # Zone Actor Names (e.g. TEMPLATE_PIRATE_SHOOTER_V2)
    asset_id: int = 0
    asset_path: str = ""

    @property
    def kind(self) -> Optional[str]:
        """The enemy kind as the randomizer names it: the .actor file name (enm_pirate_robot_shooter)."""
        return short_asset(self.asset_path)


@dataclass
class Var:
    index: int
    rel: int                  # offset in Zone Script Vars
    abs: int                  # offset in the zone (DAT1 base included)
    type: int
    aux: int
    actor_index: int
    aux2: int
    name: int
    value: int
    tail: int
    form: Optional[str] = None
    problem: Optional[str] = None


@dataclass
class Plug:
    index: int
    name: int
    var: int
    kind: int
    owner: int = -1           # Script Actions record
    rng: str = ""             # "a" (+22/+24) or "b" (+18/+20)


@dataclass
class Action:
    index: int
    key: int
    key2: int
    cls: int
    ranges: Dict[str, Tuple[int, int]] = field(default_factory=dict)


class Zone:
    """One zone's tables. Zone.parse raises ZoneError when any structural rule fails."""

    def __init__(self, raw: bytes, dat: rcra.Dat1):
        self.raw = raw
        self.dat = dat
        self.base = dat.base
        self.actors: List[Actor] = []
        self.actor_of_uid: Dict[int, int] = {}
        self.duplicate_uids: Dict[int, List[int]] = {}
        self.asset_ids: List[int] = []
        self.asset_paths: List[str] = []
        self.actor_names: List[str] = []
        self.vars: List[Var] = []
        self.plugs: List[Plug] = []
        self.actions: List[Action] = []
        self.action_of_key: Dict[int, int] = {}
        self.plugs_of_var: Dict[int, List[int]] = {}
        self.checks: List[Tuple[str, bool, str]] = []

    # ---- parsing ------------------------------------------------------------------------------------------------
    @staticmethod
    def parse(raw: bytes, base: Optional[int] = None) -> "Zone":
        if base is None:
            base = rcra.find_dat1(raw)
        if base < 0:
            raise ZoneError("no DAT1 header in the zone")
        dat = rcra.Dat1.parse(raw, base)
        z = Zone(raw, dat)
        z._check_sections()
        z._parse_assets()
        z._parse_names()
        z._parse_actors()
        z._parse_vars()
        z._parse_plugs()
        z._parse_actions()
        z._classify_vars()
        return z

    def _ok(self, name: str, ok: bool, fail: str = "", passed: str = "") -> None:
        """A structural rule: recorded (with `passed` as its detail) or, when it fails, a ZoneError with `fail`."""
        self.checks.append((name, bool(ok), passed if ok else fail))
        if not ok:
            raise ZoneError("%s: %s" % (name, fail))

    def sec(self, tag: int) -> bytes:
        return self.dat.section(tag)

    def sec_abs(self, tag: int) -> int:
        return self.dat.abs_offset(tag)

    def _check_sections(self) -> None:
        d = self.dat
        self._ok("DAT1 size field", d.size <= len(self.raw) - self.base,
                 "DAT1 says %d bytes, %d available" % (d.size, len(self.raw) - self.base), "%d bytes of %d" % (d.size, len(self.raw) - self.base))
        missing = ["%08X %s" % (t, rcra.section_name(t)) for t in REQUIRED if not d.has(t)]
        self._ok("required sections present", not missing, "missing " + ", ".join(missing), "%d of %d sections" % (len(REQUIRED), len(d.order)))
        spans = sorted((d.sections[t].offset, d.sections[t].offset + d.sections[t].size, t) for t in d.order)
        table_end = 16 + 12 * len(d.order)
        bad = []
        for (a0, a1, t), (b0, b1, u) in zip(spans, spans[1:]):
            if a1 > b0:
                bad.append("%08X [%d,%d) overlaps %08X [%d,%d)" % (t, a0, a1, u, b0, b1))
        if spans and spans[0][0] < table_end:
            bad.append("%08X starts inside the section table" % spans[0][2])
        if spans and spans[-1][1] > d.size:
            bad.append("%08X ends at %d, past the DAT1 size %d" % (spans[-1][2], spans[-1][1], d.size))
        self._ok("sections inside DAT1 and not overlapping", not bad, "; ".join(bad), "%d sections" % len(spans))
        dup = len(d.order) != len(set(d.order))
        self._ok("section tags unique", not dup, "a section tag appears twice", "%d tags" % len(set(d.order)))
        for tag, size in ((SCRIPT_VARS, VAR_SIZE), (SCRIPT_PLUGS, PLUG_SIZE), (SCRIPT_ACTIONS, ACTION_SIZE),
                          (ZONE_ACTORS, ACTOR_SIZE), (ACTOR_ASSETS, 12), (ACTOR_NAMES, 4)):
            n = d.sections[tag].size
            self._ok("%s size is whole records" % rcra.section_name(tag), n % size == 0,
                     "%d bytes is not a multiple of %d" % (n, size), "%d x %d bytes" % (n // size, size))

    def _cstring(self, off: int, what: str) -> str:
        if not 0 <= off < self.dat.size:
            raise ZoneError("%s: string offset %d outside DAT1 (%d bytes)" % (what, off, self.dat.size))
        a = self.base + off
        e = self.raw.find(b"\0", a, self.base + self.dat.size)
        if e < 0:
            raise ZoneError("%s: string at %d is not terminated inside DAT1" % (what, off))
        return self.raw[a:e].decode("utf-8", "replace")

    def _parse_assets(self) -> None:
        b = self.sec(ACTOR_ASSETS)
        n = len(b) // 12
        self.asset_ids = list(struct.unpack_from("<%dQ" % n, b, 0))
        offs = struct.unpack_from("<%dI" % n, b, 8 * n)
        self.asset_paths = [self._cstring(o, "actor-asset path %d" % i) for i, o in enumerate(offs)]
        bad = [i for i in range(n) if rcra.crc64_path(self.asset_paths[i]) != self.asset_ids[i]]
        self._ok("actor-asset table: CRC64(path) == asset id for every entry", not bad,
                 "%d of %d entries differ (first: [%d] %s)" % (len(bad), n, bad[0], self.asset_paths[bad[0]]) if bad else "",
                 "%d of %d" % (n, n))

    def _parse_names(self) -> None:
        b = self.sec(ACTOR_NAMES)
        offs = struct.unpack_from("<%dI" % (len(b) // 4), b, 0)
        self.actor_names = [self._cstring(o, "actor name %d" % i) for i, o in enumerate(offs)]

    def _parse_actors(self) -> None:
        b = self.sec(ZONE_ACTORS)
        n = len(b) // ACTOR_SIZE
        bad, seen = [], {}
        for i in range(n):
            ni, ai, so, pr, _, fl, uid = struct.unpack_from("<IIIIIIQ", b, ACTOR_SIZE * i)
            if ai >= len(self.asset_ids):
                bad.append("record %d: asset index %d >= %d" % (i, ai, len(self.asset_ids)))
                continue
            if ni >= len(self.actor_names):
                bad.append("record %d: name index %d >= %d" % (i, ni, len(self.actor_names)))
                continue
            if uid == 0:
                bad.append("record %d: uid 0" % i)
                continue
            a = Actor(i, ni, ai, so, pr, fl, uid, self.actor_names[ni], self.asset_ids[ai], self.asset_paths[ai])
            self.actors.append(a)
            seen.setdefault(uid, []).append(i)
        self._ok("Zone Actors: indices in range, uids non-zero", not bad, "; ".join(bad[:5]), "%d records" % n)
        self.duplicate_uids = {u: r for u, r in seen.items() if len(r) > 1}
        self.actor_of_uid = {u: r[0] for u, r in seen.items() if len(r) == 1}
        self.checks.append(("Zone Actors records", True, "%d, %d duplicate uid(s) (never patched to or from)" % (
            n, len(self.duplicate_uids))))

    def _parse_vars(self) -> None:
        b = self.sec(SCRIPT_VARS)
        a0 = self.sec_abs(SCRIPT_VARS)
        for i in range(len(b) // VAR_SIZE):
            t, aux, idx, aux2, name, val, tail = struct.unpack_from("<HHHHQQQ", b, VAR_SIZE * i)
            self.vars.append(Var(i, VAR_SIZE * i, a0 + VAR_SIZE * i, t, aux, idx, aux2, name, val, tail))

    def _parse_plugs(self) -> None:
        b = self.sec(SCRIPT_PLUGS)
        nv = len(self.vars)
        bad = []
        for p in range(len(b) // PLUG_SIZE):
            name, vi, kind = struct.unpack_from("<III", b, PLUG_SIZE * p)
            if vi >= nv:
                bad.append("plug %d -> Script Vars %d (only %d)" % (p, vi, nv))
            self.plugs.append(Plug(p, name, vi, kind))
            self.plugs_of_var.setdefault(vi, []).append(p)
        self._ok("Script Plugs: every plug names an existing Script Vars entry", not bad, "; ".join(bad[:5]),
                 "%d plugs, %d Script Vars entries" % (len(self.plugs), nv))

    def _parse_actions(self) -> None:
        b = self.sec(SCRIPT_ACTIONS)
        np_ = len(self.plugs)
        bad = []
        owned = [0] * np_
        for r in range(len(b) // ACTION_SIZE):
            key, key2 = struct.unpack_from("<QQ", b, ACTION_SIZE * r)
            fb, nb, fa, na = struct.unpack_from("<HHHH", b, ACTION_SIZE * r + 18)
            cls = struct.unpack_from("<I", b, ACTION_SIZE * r + 28)[0]
            act = Action(r, key, key2, cls)
            for rng, first, cnt in (("b", fb, nb), ("a", fa, na)):
                if first == NONE16:
                    if cnt:
                        bad.append("action %d range %s: first FFFF with count %d" % (r, rng, cnt))
                    continue
                if first + cnt > np_:
                    bad.append("action %d range %s: plugs %d..%d, only %d plugs" % (r, rng, first, first + cnt - 1, np_))
                    continue
                act.ranges[rng] = (first, cnt)
                for p in range(first, first + cnt):
                    owned[p] += 1
                    self.plugs[p].owner, self.plugs[p].rng = r, rng
            if key in self.action_of_key:
                bad.append("action key %016X on records %d and %d" % (key, self.action_of_key[key], r))
            self.action_of_key[key] = r
            self.actions.append(act)
        self._ok("Script Actions: ranges inside the plug table, keys unique", not bad, "; ".join(bad[:5]),
                 "%d actions, %d unique keys" % (len(self.actions), len(self.action_of_key)))
        multi = [p for p, c in enumerate(owned) if c > 1]
        none = [p for p, c in enumerate(owned) if c == 0]
        self._ok("Script Actions -> Script Plugs: every plug owned by exactly one action", not multi and not none,
                 "%d plug(s) owned twice (first %s), %d owned by none (first %s)" % (
                     len(multi), multi[:1], len(none), none[:1]), "%d of %d plugs, each exactly once" % (np_ - len(none), np_))

    # ---- the actor reference rule -----------------------------------------------------------------------------------
    def classify(self, v: Var) -> Tuple[Optional[str], Optional[str]]:
        """(form, problem) of a type-5 entry. problem is None exactly when the entry is one of KNOWN_FORMS."""
        if v.type != VAR_TYPE_ACTOR:
            return None, None
        if v.tail != 0:
            return None, "the last 8 bytes are not zero"
        if v.aux2 != NONE16:
            return None, "aux2 is %04X, not FFFF (undecoded form)" % v.aux2
        if v.aux != NONE16:
            if v.value == 0 and v.actor_index == NONE16:
                return FORM_GROUP, None
            return None, "aux %04X with uid %016X / index %d (undecoded form)" % (v.aux, v.value, v.actor_index)
        if v.value == 0:
            return (FORM_EMPTY, None) if v.actor_index == NONE16 else (None, "uid 0 with actor index %d" % v.actor_index)
        if v.value in self.duplicate_uids:
            return None, "uid %016X is on Zone Actors records %s: ambiguous" % (v.value, self.duplicate_uids[v.value])
        rec = self.actor_of_uid.get(v.value)
        if rec is None:
            if v.actor_index == NONE16:
                return FORM_EXTERNAL, None
            return None, "uid %016X is not an actor of this zone but the index says record %d" % (v.value, v.actor_index)
        if v.actor_index == rec:
            return FORM_LOCAL, None
        return None, ("INCONSISTENT REFERENCE: uid %016X is Zone Actors record %d (%s) but the index field says %s" % (
            v.value, rec, self.actors[rec].kind, ("record %d (%s)" % (v.actor_index, self.actors[v.actor_index].kind))
            if v.actor_index < len(self.actors) else "%d (no such record)" % v.actor_index))

    def _classify_vars(self) -> None:
        for v in self.vars:
            v.form, v.problem = self.classify(v)

    def reference_report(self) -> Dict:
        """C1: every type-5 entry is one of the known forms; the uid/index pair agrees for every local reference."""
        forms: Dict[str, int] = {}
        problems = []
        for v in self.vars:
            if v.type != VAR_TYPE_ACTOR:
                continue
            if v.problem:
                problems.append({"var": v.index, "abs": v.abs, "problem": v.problem})
            else:
                forms[v.form] = forms.get(v.form, 0) + 1
        return {"type5": sum(forms.values()) + len(problems), "forms": forms, "problems": problems,
                "ok": not problems}

    # ---- ownership and identity ---------------------------------------------------------------------------------
    def owners(self, var_index: int) -> List[Dict]:
        out = []
        for p in self.plugs_of_var.get(var_index, []):
            pl = self.plugs[p]
            a = self.actions[pl.owner]
            out.append({"plug": p, "plug_name": pl.name, "plug_is_templates": pl.name == PLUG_TEMPLATES,
                        "kind": pl.kind, "action": a.index, "key": "%016X" % a.key, "class": "%08X" % a.cls,
                        "range": pl.rng})
        return out

    def actor(self, uid: int) -> Optional[Actor]:
        r = self.actor_of_uid.get(uid)
        return self.actors[r] if r is not None else None

    def spawner_refs(self) -> List[Dict]:
        """Every Templates variable that is a valid local actor reference with exactly ONE plug in the whole zone,
        that plug named Templates (C2). These are the only entries a Phase A patch may change."""
        out = []
        for v in self.vars:
            if v.form != FORM_LOCAL:
                continue
            own = self.owners(v.index)
            if len(own) != 1 or not own[0]["plug_is_templates"]:
                continue
            a = self.actors[v.actor_index]
            out.append({"var": v.index, "rel": v.rel, "abs": v.abs, "uid": "%016X" % v.value, "actor_index": v.actor_index,
                        "kind": a.kind, "asset_path": a.asset_path, "actor_name": a.name, "owner": own[0]["key"],
                        "owner_action": own[0]["action"], "owner_class": own[0]["class"], "plug": own[0]["plug"]})
        return out

    def template_uids(self) -> Dict[str, List[str]]:
        """uid -> owner keys of every Templates variable (any owner count) that holds it as a local reference."""
        out: Dict[str, List[str]] = {}
        for v in self.vars:
            if v.form != FORM_LOCAL:
                continue
            for o in self.owners(v.index):
                if o["plug_is_templates"]:
                    out.setdefault("%016X" % v.value, []).append(o["key"])
        return out

    def summary(self) -> Dict:
        ref = self.reference_report()
        return {"zone_lib": ZONE_LIB_VERSION, "actors": len(self.actors), "duplicate_actor_uids": len(self.duplicate_uids),
                "actor_assets": len(self.asset_ids), "script_vars": len(self.vars), "plugs": len(self.plugs),
                "actions": len(self.actions), "type5": ref["type5"], "type5_forms": ref["forms"],
                "reference_problems": ref["problems"], "checks": [(n, ok, d) for n, ok, d in self.checks]}


# ======================================================================================================================
# the patch: one reference, both halves
# ======================================================================================================================
@dataclass
class FieldChange:
    var: int
    field: str
    abs: int
    old: bytes
    new: bytes


def plan_swap(z: Zone, var_index: int, new_uid: int, spawner_key: Optional[str] = None) -> Tuple[List[FieldChange], Dict]:
    """The bytes that make Script Vars entry `var_index` reference the zone actor `new_uid`: its uid AND its Zone
    Actors record index. Refuses (ZoneError) anything but a single-owner Templates local reference -> another local
    template actor of this zone."""
    if not 0 <= var_index < len(z.vars):
        raise ZoneError("Script Vars entry %d does not exist (%d entries)" % (var_index, len(z.vars)))
    v = z.vars[var_index]
    if v.form != FORM_LOCAL:
        raise ZoneError("Script Vars #%d is not a valid local actor reference (%s)" % (var_index, v.problem or v.form))
    own = z.owners(var_index)
    if len(own) != 1:
        raise ZoneError("Script Vars #%d is referenced by %d plugs %s: a change would reach every owner" % (
            var_index, len(own), [o["key"] for o in own]))
    if not own[0]["plug_is_templates"]:
        raise ZoneError("Script Vars #%d is the %08X plug of %s, not its Templates plug" % (var_index, own[0]["plug_name"], own[0]["key"]))
    if spawner_key is not None and own[0]["key"].upper() != spawner_key.upper():
        raise ZoneError("Script Vars #%d belongs to %s, not to the intended spawner %s" % (var_index, own[0]["key"], spawner_key))
    if new_uid in z.duplicate_uids:
        raise ZoneError("replacement uid %016X is on several Zone Actors records %s: ambiguous" % (new_uid, z.duplicate_uids[new_uid]))
    rec = z.actor_of_uid.get(new_uid)
    if rec is None:
        raise ZoneError("replacement uid %016X is not an actor of this zone" % new_uid)
    if rec > 0xFFFE:
        raise ZoneError("replacement record %d does not fit the 16-bit index field" % rec)
    if new_uid == v.value:
        raise ZoneError("the replacement is the original")
    changes = []
    for fname, (off, n), newb in (("actor_index", REF_FIELDS["actor_index"], struct.pack("<H", rec)),
                                  ("uid", REF_FIELDS["uid"], struct.pack("<Q", new_uid))):
        a = v.abs + off
        old = z.raw[a:a + n]
        if old != newb:
            changes.append(FieldChange(var_index, fname, a, old, newb))
    old_a, new_a = z.actors[v.actor_index], z.actors[rec]
    info = {"var": var_index, "entry_abs": v.abs, "entry_rel": v.rel, "owner": own[0], "entry_before": z.raw[v.abs:v.abs + VAR_SIZE].hex(),
            "original": {"uid": "%016X" % v.value, "index": v.actor_index, "kind": old_a.kind, "actor_name": old_a.name,
                         "asset_path": old_a.asset_path, "prius": old_a.prius},
            "replacement": {"uid": "%016X" % new_uid, "index": rec, "kind": new_a.kind, "actor_name": new_a.name,
                            "asset_path": new_a.asset_path, "prius": new_a.prius}}
    return changes, info


def apply_changes(raw: bytes, changes: List[FieldChange]) -> bytes:
    out = bytearray(raw)
    for c in changes:
        if out[c.abs:c.abs + len(c.old)] != c.old:
            raise ZoneError("bytes at %d are not the expected original" % c.abs)
        out[c.abs:c.abs + len(c.new)] = c.new
    return bytes(out)


# ======================================================================================================================
# original vs patched: the only accepted difference is {actor_index, uid} of single-owner Templates references
# ======================================================================================================================
def diff_positions(a: bytes, b: bytes) -> List[int]:
    out = []
    n = min(len(a), len(b))
    step = 4096
    for s in range(0, n, step):
        if a[s:s + step] != b[s:s + step]:
            out += [i for i in range(s, min(n, s + step)) if a[i] != b[i]]
    out += list(range(n, max(len(a), len(b))))
    return out


def field_of(z: Zone, pos: int) -> Tuple[Optional[int], Optional[str]]:
    """(Script Vars entry, field name) of a zone byte offset; (None, None) outside Script Vars."""
    a0 = z.sec_abs(SCRIPT_VARS)
    if not a0 <= pos < a0 + len(z.vars) * VAR_SIZE:
        return None, None
    vi, off = divmod(pos - a0, VAR_SIZE)
    for name, (o, n) in (("type", (OFF_TYPE, 2)), ("aux", (OFF_AUX, 2)), ("actor_index", REF_FIELDS["actor_index"]),
                         ("aux2", (OFF_AUX2, 2)), ("name", (OFF_NAME, 8)), ("uid", REF_FIELDS["uid"]), ("tail", (OFF_TAIL, 8))):
        if o <= off < o + n:
            return vi, name
    return vi, "?"


def compare_zones(orig: bytes, patched: bytes, base: Optional[int] = None) -> Dict:
    """Every static rule a patched zone must pass. Returns {"ok", "problems", "changes", "diff", "orig", "patched"}."""
    problems: List[str] = []
    res = {"ok": False, "problems": problems, "changes": [], "diff": [], "orig": None, "patched": None}
    if len(orig) != len(patched):
        problems.append("size %d, the original has %d" % (len(patched), len(orig)))
        return res
    try:
        z0 = Zone.parse(orig, base)
    except rcra.FormatError as ex:
        problems.append("original zone: " + str(ex))
        return res
    try:
        z1 = Zone.parse(patched, z0.base)
    except rcra.FormatError as ex:
        problems.append("patched zone: " + str(ex))
        return res
    res["orig"], res["patched"] = z0.summary(), z1.summary()
    if [(t, z0.dat.sections[t].offset, z0.dat.sections[t].size) for t in z0.dat.order] != \
       [(t, z1.dat.sections[t].offset, z1.dat.sections[t].size) for t in z1.dat.order]:
        problems.append("the DAT1 section table differs")
    hdr = z0.base + 16 + 12 * len(z0.dat.order)
    if orig[:hdr] != patched[:hdr]:
        problems.append("the DAT1 header / section table bytes differ")
    r0, r1 = z0.reference_report(), z1.reference_report()
    if not r0["ok"]:
        problems.append("the ORIGINAL zone already breaks the reference rule: %s" % r0["problems"][:3])
    if not r1["ok"]:
        problems += ["patched zone: Script Vars #%d (zone +%d): %s" % (p["var"], p["abs"], p["problem"]) for p in r1["problems"]]
    diff = diff_positions(orig, patched)
    res["diff"] = diff
    if not diff:
        problems.append("no byte differs from the original")
    touched: Dict[int, set] = {}
    for pos in diff:
        vi, fname = field_of(z0, pos)
        if vi is None:
            tag, rel = None, None
            for t in z0.dat.order:
                s = z0.dat.sections[t]
                if z0.base + s.offset <= pos < z0.base + s.offset + s.size:
                    tag, rel = t, pos - z0.base - s.offset
            problems.append("byte %d (%s +%s) changed: outside Zone Script Vars" % (
                pos, rcra.section_name(tag) if tag is not None else "outside every section", rel))
            continue
        if fname not in REF_FIELDS:
            problems.append("byte %d changed: Script Vars #%d field '%s' (only actor_index and uid may change)" % (pos, vi, fname))
            continue
        touched.setdefault(vi, set()).add(fname)
    for vi in sorted(touched):
        v0, v1 = z0.vars[vi], z1.vars[vi]
        ch = {"var": vi, "entry_abs": v0.abs, "entry_rel": v0.rel, "fields": sorted(touched[vi]),
              "before": orig[v0.abs:v0.abs + VAR_SIZE].hex(), "after": patched[v0.abs:v0.abs + VAR_SIZE].hex()}
        res["changes"].append(ch)
        ch["owners"] = z0.owners(vi)

        def side(zz, v):
            rec = zz.actor_of_uid.get(v.value)
            a = zz.actors[rec] if rec is not None else None
            ai = zz.actors[v.actor_index] if v.actor_index < len(zz.actors) else None
            return {"uid": "%016X" % v.value, "index": v.actor_index, "kind": a.kind if a else None,
                    "actor_name": a.name if a else None, "asset_path": a.asset_path if a else None, "prius": a.prius if a else None,
                    "uid_record": rec, "index_kind": ai.kind if ai else None}
        ch["original"], ch["replacement"] = side(z0, v0), side(z1, v1)
        if v0.form != FORM_LOCAL:
            problems.append("Script Vars #%d was not a valid local actor reference before the change (%s)" % (vi, v0.problem or v0.form))
            continue
        if v1.form != FORM_LOCAL:
            problems.append("Script Vars #%d is not a valid local actor reference after the change (%s)" % (vi, v1.problem or v1.form))
            continue
        if touched[vi] != set(REF_FIELDS):
            problems.append("Script Vars #%d: only %s of the reference changed" % (vi, sorted(touched[vi])))
        own = ch["owners"]
        if len(own) != 1 or not own[0]["plug_is_templates"]:
            problems.append("Script Vars #%d has %d plug(s) %s: not a single-owner Templates variable" % (
                vi, len(own), [(o["key"], "%08X" % o["plug_name"]) for o in own]))
        if v1.value == v0.value:
            problems.append("Script Vars #%d: the uid did not change" % vi)
    res["ok"] = not problems
    return res
