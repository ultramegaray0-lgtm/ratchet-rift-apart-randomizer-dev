# The .stage Enemy Randomizer (v0.76-DEV4, kit 10.0.43, stage tool 1.1.0)

> **Stage tool 1.1.0 (after the first in-game run): section 9.** The Phase A POC (tool 1.0.1) changed only the uid of a
> two-part actor reference; the game spawned what the unchanged Zone Actors index named. Sections 4-6 below describe 1.1.0.

> **STATUS: Phase A tooling, built and tested offline. Probe RUN on your game files (template uids found in Zone Script
> Vars and Zone Actors); the single-spawner POC is built and statically verified (Ardolis, ard_firstvisit_gp.zone).
> NOT YET RUN IN THE GAME.**
> Nothing below is advertised as working in the game. What is proven, and how, is listed per item.
> The next step is yours: section 6, "Phase A on your PC" (about 15 minutes), then send back the files it lists.

## 1. Why a new route

The runtime ("variable") route writes another enemy's template into a spawner's script variable in memory, racing the
game. Your DEV3 log (`rivet.log`, Nefarious City, Savali, Sargasso, Ardolis, Scarstu, Corson V):

| Result of 692 enemy spawns | Count | What the .stage route does about it |
|---|---|---|
| SUCCESS (replacement spawned) | 135 | - |
| ORIGINAL - the variable held the replacement, the game spawned the original anyway | 62 | gone by construction: the zone file itself names the replacement; nothing to race |
| spawned before the randomizer read / planned its spawner | 50 | gone by construction: the change exists before the level loads |
| not tied to a listed spawner | 64 | not needed: nothing is tied at runtime |
| no other walker / flyer kind known or loaded on this level | 222 | **the same limit** - a replacement must be a template actor placed in the same zone (section 5) |
| no proven-killable replacement / kind not known yet | 130 | the same compatibility rules apply (section 5); "not known yet" goes away (uids come from the files) |
| frame-budget errors in the log | 15 | the .stage route does no per-frame work |

## 2. What the investigation established

Sources: Overstrike (Tkachov/Overstrike, the mod manager and Modding Tool), Ripped Apart (chaoticgd/ripped_apart),
rivet_hook 2.0.1 and rivet (neptuwunium), RiftRipper (VELD-Dev), and your own logs and scripts. Each finding says how it was
checked. "Code" = read in that tool's source; "game" = checked against values the game itself produced.

1. **How level assets are stored.** A level is a `.level` asset made of `.zone` assets. Both are DAT1 containers
   (magic `DAT1`, a table of sections by CRC32 id, 16-byte aligned) stored in the toc's archives (DSAR; chunks are LZ4,
   only textures use GDeflate). Every asset of span 0 has a 36-byte header in the toc (schema + 8 block sizes; for a zone,
   block 0 = content, 1 = physics ...). *Code: Overstrike DAT1.cs, TOC.cs, DSAR.cs; rivet docs/format; Ripped Apart libra.*
2. **Where spawner definitions are.** A zone has these sections: Zone Actors, Zone Actor Names, Zone Actor Priuses,
   Zone Asset References, **Zone Script Actions, Zone Script Plugs, Zone Script Vars, Zone Script Strings,
   Zone Script Priuses**. The spawner nodes (SunsetSpawnerFactoryScriptAction, SpawnerScriptAction) are script actions
   "as the zone loader builds them" (rivet_hook game/script.hpp), and their `Template` / `Templates` are script
   variables. *Code: the section ids recompute from their names (selftest, 39 of 39).*
3. **What a spawner's template reference IS.** rivet_hook's reverse-engineered `ScriptVar`: an actors variable holds
   `actorUid` - "resolved into actors on first read" - the uid of a template actor placed in the level. Your randomizer
   saw the same uids in every game (round42 and round43, 16_rando_spawners.lua V.REG_BUILTIN: "a template actor's uid is
   level data"). So the reference is level data, and the engine resolves it itself. *Code + game (your logs).*
   **Not yet proven:** that the zone FILE stores it as the same 8 bytes. The probe (section 6) answers this from your files.
4. **Can modified assets be repacked and loaded?** Yes, for whole-asset replacement - that is what every .stage mod does.
   A `.stage` is a ZIP: `info.json` (`"game": "RCRA"`) and folders named by span (0-255) holding assets by path or by
   16-hex-digit id. rivet_hook loads a `.stage` listed in `rivet.toml` `[assets] paths` **at runtime, by asset id, without
   changing the toc** (runtime_loader.cpp); a built asset there is the 36-byte header followed by its data. Overstrike
   instead writes it into a new archive and the toc (StageInstaller.cs; format 1 = the same header + data layout).
   *Code. Asset ids: game - crc64 of 8 paths equals the ids the game's own create_asset_id gave in your rivet.log.*
5. **Coexisting with other mods.** rivet_hook: `[assets] paths` order is priority, the LAST entry wins, and a second mod
   replacing the same asset id unloads the first ("has a collision with ... unloading old"). So two mods can coexist unless
   both replace the same zone. `verify` checks every other listed mod for that. *Code.*
6. **Without runtime memory manipulation?** That is the design: the zone file names the replacement and the engine
   resolves it. **Unproven in the game** until Phase A runs.
7. **Across planets and encounters?** Only what the probe finds: a spawner can take a template actor placed in the SAME
   zone. Enemies of other planets would need their template actor (and its asset references and dependencies) added to a
   zone - a structural change this phase does not make. **Unknown.**

Risks the tooling guards against: a patched zone must keep its exact size (rivet_hook copies the header's block sizes
from the buffer; `poc` refuses a zone whose header blocks do not add up to its data); only one 8-byte value changes;
the section table must be identical after the patch; a zone that changed since the probe (game update) is refused.

## 3. Architecture

```
your rivet.logs + 16_rando_spawners.lua            your game folder (read only)
 (template uids, combat pairs, spawner keys)        toc, dag, d\*.archive
                 \                                  /
                  tools/stage_enemies/stage_enemies.py
                    probe   -> probe.json, probe_report.txt (evidence)
                    poc     -> RandoEnemies.stage + 18_rando_stage_manifest.lua + backup of the original zone
                    verify  -> the .stage against the game's originals and your other mods
                    install -> <game>\mods\RandoEnemies.stage (LAST in [assets] paths), <game>\scripts\18_rando_stage_manifest.lua
                                         |
            rivet_hook loads the zone from the .stage; the game spawns from it (no runtime write)
                                         |
  16_rando_spawners.lua: manifest present -> .stage mode: every runtime spawner write OFF (Enemy, Boss, Chaos)
  18_rando_stage_enemies.lua: STAGE VARIABLE / SPAWN / DEATH / GONE / ALIVE / SUMMARY lines verify it
```

The old Lua route is kept as the fallback and is unchanged when no manifest is installed (`enemy_source = "auto"`).
`enemy_source = "lua"` is ignored while a manifest is installed (two systems must never change the same spawners);
`"stage"` means no runtime enemy change at all.

## 4. The tool (tools/stage_enemies)

Python 3.9+, standard library only, Windows or Linux. It only READS the game folder, except `install` / `uninstall`
(mods\RandoEnemies.stage, scripts\18_rando_stage_manifest.lua and rivet.toml, which is backed up first).

| Command | What it does | Writes |
|---|---|---|
| `selftest` | 63 checks: asset ids vs the game's, plug and section ids, LZ4 vs the reference compressor, the whole flow on a synthetic game folder with the real zone table layouts, every refusal (uid-only and index-only changes included) | nothing |
| `levels --filter X` | the level / zone assets whose name contains X (from the game's dag) | nothing |
| `probe --planet X [--log rivet.log]` | reads every zone of X, DECODES its actor and script tables (zone.py, section 9) and lists every single-owner spawner Templates reference; also searches for the uids, keys and .actor ids your scripts and logs know | probe.json, probe_report.txt |
| `poc --probe probe.json [--spawner K] [--replacement U] --out NEW` | ranks Phase A candidates (section 5), changes ONE reference - uid AND Zone Actors index - checks the result, writes the .stage, a backup, the manifest, STATIC_VERIFICATION.txt and BYTE_DIFF.txt. Refuses an --out folder that already holds a build | NEW\ |
| `verify --stage S` | decodes S's zone and the game's: every byte that differs must be the index or uid of one single-owner Templates reference, every reference of the zone must stay consistent; the manifest next to S must match; the game's scripts must hold 16/18 of stage Lua 1.1.0; rivet.toml order and other mods | nothing |
| `check-zone FILE [--original O]` | the zone rules on a zone backup or a .stage, without a game folder | nothing |
| `install --build NEW` / `uninstall` | install runs verify first and stops on any problem; keeps an installed earlier .stage as `.bak-*`; copies / removes the .stage and the manifest, edits `[assets] paths` | game folder |

Same input, same output: rebuilding gives a byte-identical .stage (fixed zip timestamps and order; tested) on the same
Python. Another Python build (Windows vs Linux, zlib vs zlib-ng) compresses differently and marks another "created on"
system, so the .stage sha256 differs while every member is byte-identical: compare `zone_sha256_patched`, not the zip hash.

## 5. Compatibility rules (Phase A: conservative)

A candidate change = one Zone Script Vars reference to template A in a zone, replaced by template B - its uid AND its
Zone Actors index (tool 1.1.0). Required, all of:
- the zone decodes and passes every structural rule, and every type-5 reference of it is consistent (section 9);
- the variable has exactly ONE plug in the whole zone, the `Templates` plug of one spawner node (shared variables refused);
- A and B are identified by the zone itself (Zone Actors -> actor-asset table, CRC64-verified paths); a registry or log
  name that disagrees refuses the candidate; a log that saw the spawner hold another uid refuses it;
- B is a Zone Actors record of the same zone with a unique uid, already the template of another spawner there;
- A and B are regular enemies (role "enemy", a known movement family, not npc_/boss/ally/vendor/... names);
- same movement group (walkers = ground + swarmer, flyers, turrets) - V.FAMILY_GROUP;
- B's uid appears in the same zone OUTSIDE Script Vars (its template actor is placed there, so it loads with the zone);
- the pair is not "bad" in V.COMPAT_BUILTIN, and is **"ok" (combat-verified in your game)** - tier A. Same-faction
  unverified pairs (tier B) only with `--allow-same-faction`;
- the zone's header blocks add up to its data (rivet_hook can load the patched copy).
Ranking: tier A, B placed in Zone Actors, a spawner of the zone is in your logs (so we know the encounter to play),
A has a single reference, B's .actor is in the zone's asset references. The pair table is read from
16_rando_spawners.lua, so the tool and the game use the same evidence:
pirate robot shooter -> brawler (round37: 20 of 20, A1 completed twice) is the strongest; Nefarious pairs from round63 next.

Which spawner is the changed one (tool 1.0.1): the manifest's `spawner_keys` lists ONLY the spawners whose variable your
rivet.log saw holding A's uid - a `SPAWN ... | factory Templates KEY | ...` line ("learned from its first spawn") followed
directly by that spawn's `learned template ... (uid A) ... (spawn)` line (16_rando_spawners.lua logs both in one call).
Other spawners of the same kind may use another template actor of that kind and are NOT changed; they stay in the JSON as
`same_kind_spawner_keys` only. (Tool 1.0.0 put every same-kind spawner of the zone in `spawner_keys`, each twice, so
18_rando_stage_enemies.lua would have reported untouched spawners as "the spawner the .stage changed" and counted their
normal spawns as "original".) No log evidence = empty `spawner_keys`; the in-game check then goes by the uids alone.

Bosses: not in Phase A (story bosses stay protected; boss tier is a later experimental category).

## 6. Phase A on your PC

1. Install the DEV4 scripts as always (delete `<game>\scripts\*.lua`, copy all of `scripts\`). rivet.log:
   `RANDO-KIT release v0.76-DEV4 (kit 10.0.43)` and `RANDO-STAGE ... enemy source: Lua runtime route`.
2. In the kit folder (needs Python 3.9+ from python.org):
   ```
   python tools\stage_enemies\stage_enemies.py selftest
   python tools\stage_enemies\stage_enemies.py levels --game "<game folder>" --filter zurkon
   python tools\stage_enemies\stage_enemies.py probe  --game "<game folder>" --planet <name from levels> --log "<game folder>\rivet.log" --log <older logs>
   ```
   Pick the planet name from `levels` (the zone paths' folder). Zurkon's arena has the strongest pair; Nefarious City is
   the quickest to reach. Use every rivet.log you have: more logs = more spawner keys = a known encounter to test.
3. Read the VERDICT at the end of `probe`. If it says a single-spawner patch (uid + Zone Actors index) is possible:
   ```
   python tools\stage_enemies\stage_enemies.py poc     --game "<game folder>" --probe probe_out\probe.json --out poc_out_1_1_0
   python tools\stage_enemies\stage_enemies.py verify  --game "<game folder>" --stage poc_out_1_1_0\RandoEnemies.stage
   python tools\stage_enemies\stage_enemies.py install --game "<game folder>" --build poc_out_1_1_0
   ```
   `poc` prints the zone, the change, the pair's evidence and the encounter to play ("test where").
   If the VERDICT says anything else: STOP, send probe_report.txt and probe.json (nothing can be patched safely yet).
4. Start the game with the Enemy Randomizer ON (it only looks in .stage mode). rivet.log must show:
   - `[loader] mod path mods/RandoEnemies.stage is overstrike stage format.` and a `[loader] ... resolved to asset id` line;
   - `RANDO-STAGE STAGE MODE ON: ... 1 change(s)` and `STAGE CHANGE 1: ...`;
   - on the planet: `STAGE VARIABLE ... IS loaded` (or `RANDO-ERROR ... was NOT loaded`), `STAGE VARIABLES ...` counts.
5. Play the encounter. Look for `STAGE SPAWN ... REPLACEMENT SPAWNED`, `STAGE DEATH` / `STAGE GONE`, the objective
   completing (`RANDO-HUB objective ... 2`), and no `STAGE ALIVE`. Leave the planet: `STAGE SUMMARY`.
6. Also try: a checkpoint reload in the encounter, dying in it, and leaving and coming back (planet transitions).
7. Send: rivet.log, probe_out\probe_report.txt, probe_out\probe.json, poc_out\stage_enemies_manifest.json, and what you saw.
8. To undo: `python tools\stage_enemies\stage_enemies.py uninstall --game "<game folder>"` (the .stage, the manifest and
   the rivet.toml entry; your rivet.toml backup stays as rivet.toml.bak-stage-*).

PASS for Phase A = the variable holds the replacement, the replacement spawns from that spawner, takes damage, dies, the
encounter completes, and a reload / transition neither crashes nor duplicates. Anything less is a FAIL with the log as
evidence of exactly where it failed.

## 7. After Phase A (designed, not built)

- **B, several spawners**: `poc` takes several candidates in different encounters of one planet; verify each spawner's
  counts. **C, several planets**: one .stage holding several zones. **D, seeds**: the seed string (the existing format)
  hashed with the zone id and reference offset picks the replacement among that reference's tier-A candidates; the build
  stays byte-identical per seed; the companion can run the build before the game starts so no one extracts or repacks
  by hand. **E**: the companion and the release workflow; the Lua route removed only after B-D pass.
- Questions B-D must answer: references stored without a uid (the runtime route saw zero-uid `Templates` values that
  only hold a handle - they cannot be redirected this way), group variables (actor groups), cross-zone template use,
  and whether adding a template actor / asset reference to a zone (other planets' enemies) loads.

## 8. Limits stated plainly

- No game files and no game were available while building this: the probe, the patch and the .stage have run only on a
  synthetic game folder built to the format documents. The hashes and LZ4 were checked against real data.
- The on-disk layout of Zone Script Vars is NOT decoded; the patch swaps one exact 8-byte value that the probe found in
  that section and that is a known template uid. If the real layout stores references differently, the probe says so and
  `poc` refuses.
- A spawner can only get an enemy whose template actor is in the same zone: the pool on most levels is what the level
  already has, exactly as with the runtime route.

## 9. Stage tool 1.1.0: the Phase A POC failure and the fix

**What failed.** The 1.0.1 POC (Ardolis `ard_firstvisit_gp.zone`, spawner CECB812E81FB7301) loaded - rivet_hook served
the zone from the .stage and the variable held the brawler's uid - but the spawner made shooters, 3 of 3 loads. A
zone-local actor reference in Zone Script Vars is a 32-byte entry `{u16 type 5, u16 aux, u16 Zone Actors index, u16 aux2,
u64 name, u64 uid, u64 0}`. The POC changed the uid (entry +16: 899208BF8F48C554 -> 92C793D47A4657B6) and left the index
(entry +4: 15, the shooter's record; the brawler is record 25). In the game's file all 302 local references agree; the POC
made SV #153 the only one that did not. Factory E6705A36656EB7B9 holds the same uid WITH index 25 and spawns brawlers: the
game follows the index (the actor handle), the randomizer reads the uid.

**The decoded tables** (tools/stage_enemies/zone.py; every rule is checked on every zone, a zone that fails is never
patched):
- actor-asset table (section 78684035, name unknown): n x u64 asset id, then n x u32 path offset. CRC64(path) == id must
  hold for every entry (Ardolis: 67 of 67) - this proves the layout and names every template from the zone itself.
- Zone Actors: 32-byte records `{name index, actor-asset index, scene offset, prius, -, flags, u64 uid}`; duplicate uids are
  reported and never patched to or from.
- Script Plugs: 12-byte records `{u32 plug name crc32, u32 Script Vars index, u32 kind}` **from +0**. (The root-cause
  report read them from +8, one record off: read that way only 37 of Ardolis' 43 factory nodes have one Templates plug; from
  +0 all 43 do.) Script Actions: 40-byte records, plug ranges at +18/+20 and +22/+24; every plug must be owned by exactly one
  action range (Ardolis: 2020 of 2020).
- Type-5 forms: local (uid of a record of this zone, index = that record), external (uid not in the zone, index FFFF), group
  (aux set, uid 0), empty. Anything else - the POC's entry included - is a reference problem.

**What the tool does now.** `poc` changes the index and the uid together, only in a variable whose only plug is the
intended spawner's Templates plug, to a template of the same zone; `compare_zones` then requires that every differing byte
is one of those two fields of that one entry and that every reference of the patched zone is consistent; the .stage is read
back. `verify` repeats all of it against the game's zone and checks the manifest and the game's scripts. The 1.0.1 POC
.stage fails `verify` and `check-zone` with "INCONSISTENT REFERENCE ... SV #153".

**The Lua side (stage Lua 1.1.0, 16 + 18).** 16_rando_spawners.lua reads the uid of the actor behind a variable's handle
(rivet.uid). A disagreement with the variable's uid is a `RANDO-ERROR TEMPLATE REFERENCE MISMATCH`; that template is named
after the handle's uid, never used as a replacement, never marked MIXED and never written to the registry. A spawner the
installed .stage changed never writes the registry or MIXED at all. A manifest without 18_rando_stage_enemies.lua is
`RANDO-ERROR STAGE CHECK MISSING` on screen and in the log (the kit check does not name a missing developer-only script, so
the POC round ran without it silently). 18 logs `STAGE REFERENCE ... AGREE / DISAGREE` for the patched spawner and the
handle's uid on every `STAGE SPAWN`.

**The false `|mixed` entry.** The POC round stored `92C793D47A4657B6 = enm_pirate_robot_melee|...|mixed` in the save's
template registry. 16 now names it in rivet.log and changes nothing. Copy `dev_scripts\dev(reg_repair).lua` into the
scripts folder for one game start to remove only that `|mixed` suffix (any other stored value is left alone), then delete
the file. In .stage mode the entry has no effect either way.

**Tests.** `selftest` (63), `tests/v076dev4/test_stage_zone_fix.py` (structure, bounds, duplicates, ownership, hashes,
and with `--zone <backup>` the real Ardolis zone: the 1.0.1 POC FAILS, the 1.1.0 build PASSES), and
`tests/v076dev4/test_stage_lua_fix.py` (lupa: no false MIXED, R1, missing 18, registry repair).
