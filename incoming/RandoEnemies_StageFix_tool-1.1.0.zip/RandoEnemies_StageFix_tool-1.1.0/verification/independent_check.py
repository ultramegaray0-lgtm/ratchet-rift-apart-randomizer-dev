"""independent_check.py - checks the stage tool 1.1.0 candidate WITHOUT any of the kit's code.

Own zip read, own DAT1 parse, own bit-by-bit CRC64 and CRC32, own table decode, written separately from
tools/stage_enemies (rcra.py / zone.py are not imported). Read-only.

  python -I independent_check.py <original zone backup (header + zone)> <new .stage> [<1.0.1 POC .stage>]
"""
import hashlib
import struct
import sys
import zipfile

ok_all = True


def check(cond, msg):
    global ok_all
    print("%-4s %s" % ("ok" if cond else "FAIL", msg))
    ok_all = ok_all and bool(cond)


def crc64(path):                                  # Overstrike CRC64.Hash, bit by bit (no table)
    s = path.lower().replace("\\", "/")
    while "//" in s:
        s = s.replace("//", "/")
    s = s.strip("/")
    poly = 0xC96C5795D7870F42
    v = poly
    for b in s.encode():
        v ^= b
        for _ in range(8):
            v = (v >> 1) ^ poly if v & 1 else v >> 1
    return (v >> 2) | (1 << 63)


def crc32e(s):                                     # engine hash: reflected, start EDB88320, no final xor
    c = 0xEDB88320
    for b in s.encode():
        c ^= b
        for _ in range(8):
            c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
    return c


def sections(raw):
    magic, typ, size, n = struct.unpack_from("<IIIH", raw, 0)
    assert magic == 0x44415431, "no DAT1"
    return {t: (o, s) for t, o, s in (struct.unpack_from("<III", raw, 16 + 12 * k) for k in range(n))}, size


def cstr(raw, off):
    return raw[off:raw.index(b"\0", off)].decode()


def decode(raw):
    sec, size = sections(raw)
    out = {}
    o, s = sec[0x78684035]
    n = s // 12
    ids = struct.unpack_from("<%dQ" % n, raw, o)
    paths = [cstr(raw, x) for x in struct.unpack_from("<%dI" % n, raw, o + 8 * n)]
    out["assets_ok"] = sum(crc64(p) == i for p, i in zip(paths, ids)), n
    o, s = sec[0x70682CB8]
    acts = [struct.unpack_from("<IIIIIIQ", raw, o + 32 * i) for i in range(s // 32)]
    out["actors"] = acts
    out["rec_of"] = {}
    for i, a in enumerate(acts):
        out["rec_of"].setdefault(a[6], []).append(i)
    out["kind"] = lambda r: paths[acts[r][1]].replace("\\", "/").split("/")[-1]
    o, s = sec[0xD86A7934]
    out["sv_off"] = o
    out["vars"] = [struct.unpack_from("<HHHHQQQ", raw, o + 32 * i) for i in range(s // 32)]
    o, s = sec[0xBEAB52E7]
    plugs = [struct.unpack_from("<III", raw, o + 12 * i) for i in range(s // 12)]
    o, s = sec[0x5E54ACCF]
    owner = {}
    for r in range(s // 40):
        key = struct.unpack_from("<Q", raw, o + 40 * r)[0]
        for fo in (18, 22):
            f, c = struct.unpack_from("<HH", raw, o + 40 * r + fo)
            if f != 0xFFFF:
                for p in range(f, f + c):
                    owner.setdefault(p, []).append(key)
    out["plug_partition"] = len(owner) == len(plugs) and all(len(v) == 1 for v in owner.values())
    out["var_plugs"] = {}
    for p, (nm, vi, kind) in enumerate(plugs):
        out["var_plugs"].setdefault(vi, []).append((nm, owner.get(p, [None])[0], p))
    bad = []
    for i, (t, aux, idx, aux2, name, val, tail) in enumerate(out["vars"]):
        if t != 5:
            continue
        recs = out["rec_of"].get(val, [])
        if val and len(recs) == 1 and aux == aux2 == 0xFFFF and tail == 0:
            if idx != recs[0]:
                bad.append(i)
        elif val and not recs and idx != 0xFFFF:
            bad.append(i)
    out["c1_bad"] = bad
    return out


orig_blob = open(sys.argv[1], "rb").read()
oh, oraw = orig_blob[:36], orig_blob[36:]
print("original zone sha256 %s" % hashlib.sha256(oraw).hexdigest())
check(hashlib.sha256(oraw).hexdigest() == "d40540edad455dee68a274540cd53589b3142ce458bac16bde82a0d6f185e016", "the original is the zone your probe read")
zf = zipfile.ZipFile(sys.argv[2])
check(zf.testzip() is None, "new .stage: zip CRCs intact")
check(sorted(zf.namelist()) == ["0/AE530D22FE113E2B", "info.json"], "new .stage: exactly info.json + 0/AE530D22FE113E2B")
import json  # noqa: E402
check(json.loads(zf.read("info.json"))["game"] == "RCRA", "info.json game RCRA")
check(crc64("levels\\i29\\instance\\ardolis\\ardolis_main\\ard_firstvisit_gp.zone") == 0xAE530D22FE113E2B, "member id = CRC64 of the zone path")
m = zf.read("0/AE530D22FE113E2B")
nh, nraw = m[:36], m[36:]
check(nh == oh, "36-byte asset header identical to the game's")
check(sum(struct.unpack_from("<8I", nh, 4)) == len(nraw) == len(oraw), "header block sizes add up to the zone, size unchanged (%d)" % len(nraw))
diff = [i for i in range(len(oraw)) if oraw[i] != nraw[i]]
print("differing zone offsets:", diff)
check(diff == [413764] + list(range(413776, 413784)), "exactly 9 bytes differ: +413764 and +413776..+413783")
check(oraw[413760:413792].hex() == "0500ffff0f00ffffff1791f3d5e71ba654c5488fbf0892890000000000000000", "entry before: type 5, index 15, uid 899208BF8F48C554")
check(nraw[413760:413792].hex() == "0500ffff1900ffffff1791f3d5e71ba6b657467ad493c7920000000000000000", "entry after:  type 5, index 25, uid 92C793D47A4657B6")
check(crc32e("Templates") == 0xEDD5E282, "crc32 engine 'Templates' = EDD5E282 = 3990217346")
for label, raw in (("original", oraw), ("new", nraw)):
    d = decode(raw)
    check(d["assets_ok"] == (67, 67), "%s: actor-asset table CRC64(path) == id %d/%d" % (label, *d["assets_ok"]))
    check(d["plug_partition"], "%s: every plug owned by exactly one Script Actions range" % label)
    check(not d["c1_bad"], "%s: every type-5 uid/index pair agrees (problems: %s)" % (label, d["c1_bad"]))
    sv153 = (413760 - d["sv_off"]) // 32
    t, aux, idx, aux2, name, val, tail = d["vars"][sv153]
    vp = d["var_plugs"].get(sv153, [])
    check(sv153 == 153 and len(vp) == 1 and vp[0][0] == crc32e("Templates") and vp[0][1] == 0xCECB812E81FB7301,
          "%s: SV #153's only plug is #%d 'Templates' of CECB812E81FB7301" % (label, vp[0][2] if vp else -1))
    check(d["rec_of"][val] == [idx], "%s: SV #153 uid %016X is record %s, index field %d" % (label, val, d["rec_of"][val], idx))
    print("     %s: SV #153 -> record %d -> %s" % (label, idx, d["kind"](idx)))
if len(sys.argv) > 3:
    pm = zipfile.ZipFile(sys.argv[3]).read("0/AE530D22FE113E2B")[36:]
    d = decode(pm)
    check(d["c1_bad"] == [153], "1.0.1 POC .stage: SV #153 is the one inconsistent reference (uid record %s, index %d)" % (
        d["rec_of"][d["vars"][153][5]], d["vars"][153][2]))
print("INDEPENDENT CHECK: %s" % ("PASS" if ok_all else "FAIL"))
sys.exit(0 if ok_all else 1)
