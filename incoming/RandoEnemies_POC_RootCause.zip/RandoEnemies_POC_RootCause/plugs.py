import struct, sys
raw = open(sys.argv[1],'rb').read()[36:]
PL=442400; SV=408864
H={0xEDD5E282:"Templates",0x6D61A2F3:"Template",0x183CCBA8:"LastSpawn",0x31F50D46:"Factories",0xA49F34BB:"Location",0x951BD5B6:"Locations"}
for o in range(3520, 3720, 4):
    v = struct.unpack_from("<I", raw, PL+o)[0]
    lo, hi = v & 0xFFFF, v >> 16
    print("  +%-5d %08X  u16 %5d %5d  %s" % (o, v, lo, hi, H.get(v,"")))
