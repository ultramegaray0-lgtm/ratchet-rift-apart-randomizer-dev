import struct, sys
blob = open(sys.argv[1],'rb').read(); raw = blob[36:]
magic, typ, size, cnt, _ = struct.unpack_from("<IIIHH", raw, 0)
secs = {t:(o,s) for t,o,s in (struct.unpack_from("<III", raw, 16+12*k) for k in range(cnt))}
ZA = secs[0x70682CB8]; AA = secs[0x78684035]; AR = secs[0x30DADA09]; AN = secs[0xDC625B3D]
print("Zone Actors", ZA, " actor-asset table 78684035", AA, " Asset Refs", AR, " Actor Names", AN)
assets = [struct.unpack_from("<Q", raw, AA[0]+8*i)[0] for i in range(AA[1]//8)]
KNOWN = {0xA634A2F2985F6C56:"shooter.actor",0xBE93E997D265010B:"melee.actor",0xA46650C893C800E5:"shielded.actor",0xBF21915BB38F95B3:"bladeball.actor",0xBB17EEA5B92D6EC9:"crab.actor",0x8D385F6A811CAC16:"puffoid.actor",0x997E18029405EC5B:"shingle.actor",0x9EFF5464F1477C69:"thugs_shooter.actor",0x8D2167ACC6F1A561:"thugs_jetpack.actor"}
for i,a in enumerate(assets):
    if a in KNOWN: print("  asset table [%d] %016X %s" % (i, a, KNOWN[a]))
UIDS = {0x8416CF7558A4694D:"8416 shooter?",0x899208BF8F48C554:"8992 shooter? (ORIGINAL)",0x92C793D47A4657B6:"92C7 melee? (REPLACEMENT)",0xAF0189E66C49DA08:"AF01 melee?",0xC1EE87C86B7840DD:"C1EE shielded?",0xD79E5FEE5A2F6ECD:"D79E thugs shooter?"}
print("Zone Actors records (32 bytes) holding the template uids:")
for off in range(0, ZA[1], 8):
    v = struct.unpack_from("<Q", raw, ZA[0]+off)[0]
    if v in UIDS:
        rs = off - off % 32
        rec = raw[ZA[0]+rs:ZA[0]+rs+32]
        f = struct.unpack_from("<8I", rec)
        print("  +%-5d uid at rec+%d  %-28s rec u32s %s" % (rs, off-rs, UIDS[v], " ".join("%08X"%x for x in f)))
