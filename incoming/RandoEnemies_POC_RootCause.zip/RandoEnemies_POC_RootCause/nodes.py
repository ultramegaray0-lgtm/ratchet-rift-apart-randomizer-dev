import struct, sys, collections
raw = open(sys.argv[1],'rb').read()[36:]
PL, PLS = 442400, 24240; SV, SVS = 408864, 33536; SA, SAS = 466640, 37040
H={0xEDD5E282:"Templates",0x6D61A2F3:"Template",0x183CCBA8:"LastSpawn",0x31F50D46:"Factories",0xA49F34BB:"Location",0x951BD5B6:"Locations"}
UID={0x8416CF7558A4694D:"shooter#8416",0x899208BF8F48C554:"shooter#8992",0x92C793D47A4657B6:"melee#92C7",0xAF0189E66C49DA08:"melee#AF01",0xC1EE87C86B7840DD:"shielded#C1EE",0xD79E5FEE5A2F6ECD:"thugs_shooter#D79E",0xF8AE42A8EAC94695:"puffo#F8AE",0xB69D08BA44EE560E:"crab#B69D",0xD7677BCD9AAF5963:"crab#D767",0x8F2D4755EC410DBC:"veh_p#8F2D"}
def plug(i): return struct.unpack_from("<III", raw, PL+8+12*i)
def var(i):
    h = struct.unpack_from("<HHHH", raw, SV+32*i); name, val, pad = struct.unpack_from("<QQQ", raw, SV+32*i+8); return h, name, val
nodes = []
for r in range(SAS//40):
    k1,k2,a,b,c,first = struct.unpack_from("<QQHHHH", raw, SA+40*r)
    n1,n2,cls,x,y = struct.unpack_from("<HHIII", raw, SA+40*r+24)
    nodes.append((r,k1,k2,first,n1,n2,cls,x,y))
cls_count = collections.Counter(n[6] for n in nodes)
print("Script Actions: %d records of 40 bytes; classes: %s" % (len(nodes), ", ".join("%08X x%d"%c for c in cls_count.most_common(8))))
def show(key):
    for (r,k1,k2,first,n1,n2,cls,x,y) in nodes:
        if k1 == key:
            print("node #%d key %016X class %08X plugs %d..%d (n1=%d n2=%d) x=%d y=%d" % (r,k1,cls,first,first+n1-1,n1,n2,x,y))
            for i in range(first, first+n1):
                kind,h,vi = plug(i); vh,name,val = var(vi) if vi < SVS//32 else ((0,0,0,0),0,0)
                print("   plug #%d %-9s kind %08X -> SV #%-4d type %d f %04X %04X %04X  value %016X %s" % (i, H.get(h,"%08X"%h), kind, vi, vh[0], vh[1], vh[2], vh[3], val, UID.get(val,"")))
for k in (0xCECB812E81FB7301, 0xE6705A36656EB7B9, 0xB65A076E8CDFEF91):
    show(k)
