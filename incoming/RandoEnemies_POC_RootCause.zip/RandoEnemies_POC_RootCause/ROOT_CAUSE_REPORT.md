# Root cause: the Phase A .stage POC spawned a shooter instead of a brawler

Inputs: your POC-session rivet.log (DEV4, `.stage` installed), the DEV3 rivet.log, the original zone backup (`AE530D22FE113E2B.zone.orig`), both POC `.stage` builds, `probe.json`, and the kit's Lua. Nothing was built, installed or changed. The POC, its backup and both builds are untouched.

## 1. Verdict

**The POC changed half of a two-part reference.** A zone-local actor variable in Zone Script Vars stores the actor's **uid** (entry +16) **and** its **Zone Actors record index** (u16 at entry +4). The patch replaced the uid (shooter `899208BF…` → brawler `92C793D4…`) but left the index at **15**, the shooter template's record. The brawler is record **25**.

In the original zone the two always agree (325 of 325 actor references). The POC made entry #153 the only reference in the zone where they disagree. The game spawned the actor named by the index: the shooter, in all 3 encounters on Ardolis in that session.

Confidence: high for "the POC reference is malformed and that is why it failed". The byte layout and the 325/325 baseline are certain. That the game *resolves* through the index is inferred: it is the only difference between CECB812E81FB7301 (shooter) and E6705A36656EB7B9 (brawler), whose variables carry the same uid. It is not yet directly observed (section 4c).

## 2. What the POC-session log proves, and what it does not

| Log evidence | Meaning |
|---|---|
| `[loader] mod path mods/RandoEnemies.stage is overstrike stage format.` / `AE530D22FE113E2B resolved to asset id …` / `closing 0/AE530D22FE113E2B` | rivet_hook served the zone from the .stage |
| `SPAWN … factory Templates CECB812E81FB7301 \| original enm_pirate_robot_melee \| … spawned enm_pirate_robot_shooter` (lines 387, 567, 745) | The **live** Templates variable of CECB812E81FB7301 held uid `92C793D4…`. In DEV3 the same field read `original enm_pirate_robot_shooter`. The patched bytes reached memory on every load. The game still spawned a shooter, 3 of 3 times |
| `template 1086772 (92C793D47A4657B6) … MIXED` (and 1110739, 2133426 on later loads) | The randomizer paired the **handle** the game resolved (1086772) with the **uid** it read from the same variable, then saw a shooter come out (section 5) |
| No `RANDO-STAGE` line at all; `loaded 20 of 20 scripts` | `18_rando_stage_enemies.lua` did not run (it logs a line when it loads). 19 kit files + manifest + dev(debug) = 21. The in-game check produced nothing, so the evidence above comes from 16_rando_spawners.lua's ledger |

So, as you said: the loader recognising the file proves only that the zone was served. The variable held the new uid, and the spawn still did not follow it.

## 3. The binary decode (original zone, independent of the kit's code)

**Script Vars** = 1048 entries of 32 bytes: `{u16 type, u16 a, u16 index, u16 b, u64 name, u64 value, u64 0}`.

**Script Plugs** = 12-byte records at +8: `{u32 kind, u32 plug-name crc32, u32 Script Vars entry}`.

**Script Actions** = 926 records of 40 bytes: `{u64 key, u64 key2, …, u16 first plug at +22, u16 plug count at +24, …}`.

| | CECB812E81FB7301 (patched) | E6705A36656EB7B9 | B65A076E8CDFEF91 |
|---|---|---|---|
| Action node | #387, plugs 459-465 | #393, plugs 502-509 | #381, plugs 425-429 |
| `Templates` plug → var | #459 → SV #153 | #505 → SV #799 | #428 → SV #604 |
| var uid (before POC) | `899208BF8F48C554` | `92C793D47A4657B6` | `8416CF7558A4694D` |
| var index field | **15** | 25 | 14 |
| Zone Actors record of that uid | **15** | 25 | 14 |
| record → actor asset | [11] `enm_pirate_robot_shooter.actor` | [16] `enm_pirate_robot_melee.actor` | [11] shooter |

- **Ownership is now proven from the binary, not only from the log.** Exactly one plug in the zone points at SV #153: plug #459, `Templates`, of node CECB812E81FB7301. The tool's attribution was right.
- **Template identity is proven from the binary.** Zone Actors record u32[1] indexes the zone's actor-asset table. Record 25 (`92C793D4…`) is `enm_pirate_robot_melee.actor`, a real brawler template. The tool's name for it was right.
- **Template uids are not shared or reused.** Each uid is one Zone Actors record in this zone, and appears in no other of the 9,009 probed zones.
- **Index field rule (C1):** 302 actor variables reference an actor in this zone, and all 302 store that actor's record index. 23 reference uids that are not actors of this zone, and those store `0xFFFF` (resolved some other way). 0 exceptions.
- **Runtime handles follow record order.** DEV3: 7 of 7 learned templates satisfy `handle = 6343579 + record` (veh_p 2, thugs shooter 10, shielded 12, shooters 14/15, brawlers 25/26).

After the POC: SV #153 = `05 00 FF FF 0F 00 FF FF` + name + `92C793D47A4657B6`. The uid says record 25 (brawler), the index says record 15 (shooter). `ref_consistency_check.py` flags exactly this entry on both builds and passes the original.

## 4. Why the game produced a shooter

**a. The resolution path.** E6705A36656EB7B9 (uid `92C793D4`, index 25) spawned brawlers on every load. CECB812E81FB7301 (uid `92C793D4`, index 15) spawned shooters on every load. Same uid, same node class (`2E910F8C`), same zone and session. The only difference in their references is the index, and each spawned the kind its index names. This matches rivet_hook's description of a ScriptVar ("actorUid resolved into actors on first read"): the engine fills the handle from the zone's own actor table at the stored index, and the uid rides along. The uid is what the randomizer reads; the handle is what the factory uses.

**b. The alternative considered: a factory that latches its template.** DEV3 shows factories ignore variable changes made after they start: 27 of 27 always-ORIGINAL factories had a "late" change, and 22 of 24 always-SUCCESS factories were changed only before starting. That explains DEV3 (CECB812E81FB7301 spawns the moment you land, so it was always changed late). It does not explain the POC: the `.stage` value existed before the zone loaded. It would only apply if the save file restored a factory's template, and nothing in either log shows that.

**c. Not directly observed yet.** Which actor handle 1086772 really is. It sits a fixed 6 above an actor that plays `PILF_ENM_GEN_STARTLED` on every load (1086766 / 1110733 / 2133420). That places it at record 15 (speaker = record 9, asset `9C25953EE0A31B15`) or record 25 (speaker = one of records 17-21, asset `B97F1DED3F1B61C4`), and the logs do not name that speaker. The next in-game run should log the uid **read from the actor behind the handle**, not from the variable (section 7, R1). That one line settles 4a against 4b.

## 5. The MIXED diagnostic

`V.learn` (16_rando_spawners.lua ~3039) takes the spawner's variable, builds the template record with `V.tpl_of(handle, uid)`, and names it from the save's registry **by uid**: `92C793D4` = brawler, learned in DEV3. The bot that came out was a shooter, so the "same template" appeared to spawn two kinds, and it was marked `MIXED, never used`.

The registry assumes uid and handle name the same actor. In an unpatched zone they always do. The POC broke that, so the MIXED mark is a symptom of the malformed reference, not a property of the brawler template.

**Side effect on your save:** `V.reg_put` stores `|mixed` under uid `92C793D47A4657B6` in the save's template registry, and mixed templates are never chosen (`V.usable`, line ~2231). The runtime route will no longer use this genuine brawler template in that save until the entry is cleared. Uninstalling the `.stage` does not clear it.

## 6. Why static verification passed a broken patch

- The tool (`poc`, `verify`) and my independent check both modelled a reference as **one 8-byte uid**. The probe only searched for uids, and `verify` accepted "one known uid replaced by another". Nothing decoded the entry around the uid, so the second half of the reference was invisible to every check.
- The `.stage` writer, the DAT1 parse, the header and the size were all correct. The fault is in what was changed, not in how the file was packed.
- Ownership and template naming were right here, but the naming came from the randomizer's runtime registry, which is only valid in unpatched zones. Both are now derivable from the binary (section 3), and should be.

## 7. Corrected approach (proposal only; nothing built)

**Patch.** Rewrite the whole reference: uid at entry+16 **and** index at entry+4, both taken from the replacement's own Zone Actors record. For this POC that would be SV #153, zone +413764: `0F 00` → `19 00`, plus the uid. Changed bytes: one entry, 8 + 1 (index low byte).

**Static checks that must all pass before a build:**

| # | Check | Would it have caught this POC? |
|---|---|---|
| C1 | Every type-5 entry: index == Zone Actors record of its uid, or `0xFFFF` if the uid is not in the zone. Baseline on the original zone must be 100%, and the patched zone too | **Yes**, it fails on both builds (`ref_consistency_output.txt`) |
| C2 | Ownership from the plug table: exactly one `Templates` plug references the entry, owned by the intended node. Refuse shared variables | No (it was correct) but it removes the dependence on log heuristics |
| C3 | Template identity from Zone Actors → actor-asset table. Refuse when the runtime registry name disagrees with the binary | No (it agreed) |
| C4 | Refuse entries where the other header half (`a`) is set: 251 type-5 entries use that other, undecoded form | Not applicable here |
| C5 | Byte diff limited to {uid, index} of one entry | Would have documented the second field |
| C6 | Compare the two template records' Actor Prius index (record u32[3]: shooter `899208BF` → 6, brawler `92C793D4` → 10). A swap changes per-template overrides; list them | Informational |

**Runtime checks for the next in-game run (no test requested now):**

- **R1:** for the patched spawner, log the uid read **from the actor behind the variable's handle** and treat a disagreement with the variable's uid as an error. This settles 4c.
- **R2:** make `V.learn` refuse to mark MIXED, and to write the registry, when the handle's own uid differs from the variable's uid.
- **R3:** restore `18_rando_stage_enemies.lua` in the game's scripts folder; its absence is why there were no `STAGE` lines.
- **R4:** clear the false `|mixed` registry entry for `92C793D47A4657B6`.

## 8. Files

- `ROOT_CAUSE_REPORT.md`: this report.
- `ref_consistency_check.py` + `ref_consistency_output.txt`: C1 on the original zone (PASS) and both POC builds (FAIL, SV #153).
- `index_check.py`, `nodes.py`, `refs153.py`, `actors.py`, `outcomes.txt`: the decode and log tallies behind sections 3-4, runnable with `python -I script.py <zone.orig>`.
