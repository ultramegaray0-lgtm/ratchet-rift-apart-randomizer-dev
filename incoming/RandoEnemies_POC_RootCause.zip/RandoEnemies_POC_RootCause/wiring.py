import struct, sys
blob = open(sys.argv[1],'rb').read(); raw = blob[36:]
cnt = struct.unpack_from("<H", raw, 12)[0]
secs = {t:(o,s) for t,o,s in (struct.unpack_from("<III", raw, 16+12*k) for k in range(cnt))}
NAMES={0x5E54ACCF:"Script Actions",0xBEAB52E7:"Script Plugs",0xD86A7934:"Script Vars",0xEF8637D5:"Script Strings",0x2300D240:"Script Priuses",0x70682CB8:"Zone Actors"}
def crc32e(s):
    c=0xEDB88320
    for b in s.encode():
        c ^= b
        for _ in range(8): c = (c>>1)^0xEDB88320 if c&1 else c>>1
    return c
for n in ["Templates","Template","LastSpawn","Factories","Location","Locations","SpawnLocations","Spawners"]:
    h = crc32e(n); nd = struct.pack("<I", h); hits=[]; i=raw.find(nd)
    while i>=0:
        sec=[NAMES.get(t,"%08X"%t) for t,(o,s) in secs.items() if o<=i<o+s]
        hits.append("%s+%d"%(sec[0] if sec else "?", i-[o for t,(o,s) in secs.items() if o<=i<o+s][0] if sec else i)); i=raw.find(nd,i+1)
    print("%-15s crc %08X : %d hits %s" % (n, h, len(hits), hits[:6]))
SA,_ = secs[0x5E54ACCF]
print("\nScript Actions records 40 bytes; spawner records near CECB812E:")
for rel in (14600,15240,15480,15640):   # 957C, B65A, CECB, DCA7
    r = raw[SA+rel:SA+rel+40]
    k1,k2,a,b,c,d,e,f,g = struct.unpack_from("<QQHHHHIII", r)
    print("  +%d key %016X / %016X  u16s %d %X %d %X  type %08X  data_off %d data_len %d" % (rel,k1,k2,a,b,c,d,e,f,g))
