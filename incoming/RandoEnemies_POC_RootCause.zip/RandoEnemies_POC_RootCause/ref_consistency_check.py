"""ref_consistency_check.py - static checks the Phase A tool lacked (root-cause report, round 1 of the .stage POC).

For one zone (header + data, as in poc_out/backup/<id>.zone.orig or the 0/<id> member of a .stage):
  C1  every type-5 (actor) Script Vars entry: the u16 at entry+4 (zone-local actor index) is the Zone Actors record
      of the uid at entry+16, or 0xFFFF when that uid is not an actor of this zone
  C2  ownership from the plug table: Script Actions record (40 bytes) -> first plug (u16 at +22), plug count (u16 at
      +24) -> 12-byte plug records {u32 kind, u32 plug hash, u32 Script Vars index} at Script Plugs +8
  C3  template identity from the zone itself: Zone Actors record u32[1] -> actor-asset table (section 78684035)
usage: python -I ref_consistency_check.py <zone blob> [<zone blob> ...]
"""
import struct
import sys

TEMPLATES = 0xEDD5E282          # crc32 "Templates" (rivet / 16_rando_spawners.lua V.PLUG_TEMPLATES 3990217346)
ASSET_NAMES = {0xA634A2F2985F6C56: "enm_pirate_robot_shooter.actor", 0xBE93E997D265010B: "enm_pirate_robot_melee.actor"}


def load(path):
    b = open(path, "rb").read()
    if b[:2] == b"PK":                                   # a .stage: take its one zone member
        import zipfile
        z = zipfile.ZipFile(path)
        b = z.read([n for n in z.namelist() if n != "info.json"][0])
    raw = b[36:]
    cnt = struct.unpack_from("<H", raw, 12)[0]
    secs = {t: (o, s) for t, o, s in (struct.unpack_from("<III", raw, 16 + 12 * k) for k in range(cnt))}
    return raw, secs


def check(path):
    raw, secs = load(path)
    ZA, ZAS = secs[0x70682CB8]
    SV, SVS = secs[0xD86A7934]
    PL, PLS = secs[0xBEAB52E7]
    SA, SAS = secs[0x5E54ACCF]
    AA, AAS = secs[0x78684035]
    assets = [struct.unpack_from("<Q", raw, AA + 8 * i)[0] for i in range(AAS // 8)]
    rec_of, asset_of = {}, {}
    for i in range(ZAS // 32):
        f = struct.unpack_from("<IIIIIIQ", raw, ZA + 32 * i)
        rec_of[f[6]] = i
        asset_of[f[6]] = assets[f[1]] if f[1] < len(assets) else None
    bad, n5 = [], 0
    for v in range(SVS // 32):
        typ, f1, idx, f3, name, uid, pad = struct.unpack_from("<HHHHQQQ", raw, SV + 32 * v)
        if typ != 5 or uid == 0:
            continue
        n5 += 1
        want = rec_of.get(uid, 0xFFFF)
        if idx != want:
            bad.append((v, uid, idx, want))
    owners = {}
    for r in range(SAS // 40):
        key = struct.unpack_from("<Q", raw, SA + 40 * r)[0]
        first, n = struct.unpack_from("<HH", raw, SA + 40 * r + 22)
        for p in range(first, first + n):
            kind, h, vi = struct.unpack_from("<III", raw, PL + 8 + 12 * p)
            owners.setdefault(vi, []).append((key, h))
    print("== %s" % path)
    print("  C1 actor references: %d checked, %d with an index that is not their uid's actor" % (n5, len(bad)))
    for v, uid, idx, want in bad:
        def who(i):
            for u, rr in rec_of.items():
                if rr == i:
                    return "%016X %s" % (u, ASSET_NAMES.get(asset_of[u], "%016X" % (asset_of[u] or 0)))
            return "none"
        print("     SV #%d (zone +%d): uid %016X -> record %s = %s | index field %d = %s" % (
            v, SV + 32 * v, uid, want, who(want), idx, who(idx)))
        for key, h in owners.get(v, []):
            print("     owned by node %016X via plug %s" % (key, "Templates" if h == TEMPLATES else "%08X" % h))
    print("  C1 %s" % ("PASS" if not bad else "FAIL"))
    return not bad


ok = [check(p) for p in sys.argv[1:]]
sys.exit(0 if all(ok) else 1)
