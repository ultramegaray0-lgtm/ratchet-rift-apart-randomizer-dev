import struct, sys, collections
blob = open(sys.argv[1],'rb').read(); raw = blob[36:]
cnt = struct.unpack_from("<H", raw, 12)[0]
secs = {t:(o,s) for t,o,s in (struct.unpack_from("<III", raw, 16+12*k) for k in range(cnt))}
ZA, ZAS = secs[0x70682CB8]; SV, SVS = secs[0xD86A7934]; AA, AAS = secs[0x78684035]
assets = [struct.unpack_from("<Q", raw, AA+8*i)[0] for i in range(AAS//8)]
nrec = ZAS // 32
uid_at = {}; recs = []
for i in range(nrec):
    f = struct.unpack_from("<IIIIIIQ", raw, ZA + 32*i)
    uid_at[f[6]] = i; recs.append(f)
print("Zone Actors: %d records of 32 bytes (uid at +24)" % nrec)
stats = collections.Counter(); bad = []
for v in range(SVS // 32):
    typ, f1, f2, f3, name, val, pad = struct.unpack_from("<HHHHQQQ", raw, SV + 32*v)
    if typ != 5: continue
    if val == 0: stats["type5 value 0"] += 1; continue
    if val in uid_at:
        ok = (f2 == uid_at[val]); stats["uid in this zone, index field %s" % ("== its record" if ok else "!= its record")] += 1
        if not ok: bad.append((v, val, f2, uid_at[val]))
    else:
        stats["uid not in this zone's Zone Actors, f2=%s" % ("FFFF" if f2 == 0xFFFF else "set")] += 1
for k, n in stats.most_common(): print("  %-58s %d" % (k, n))
for b in bad[:10]: print("  MISMATCH SV #%d uid %016X f2 %d record %d" % b)
KN = {0xA634A2F2985F6C56:"enm_pirate_robot_shooter",0xBE93E997D265010B:"enm_pirate_robot_melee",0xA46650C893C800E5:"shielded",0xBF21915BB38F95B3:"bladeball",0xBB17EEA5B92D6EC9:"crab",0x8D385F6A811CAC16:"puffoid",0x997E18029405EC5B:"shingle",0x9EFF5464F1477C69:"thugs_shooter",0x8D2167ACC6F1A561:"thugs_jetpack"}
print("records 9..27 (record index: asset):")
for i in range(9, 28):
    f = recs[i]; a = assets[f[1]] if f[1] < len(assets) else None
    print("  #%-3d uid %016X asset[%d] %s" % (i, f[6], f[1], KN.get(a, "%016X" % a if a else "?")))
