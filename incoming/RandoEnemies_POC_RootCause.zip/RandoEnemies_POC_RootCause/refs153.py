import struct, sys
raw = open(sys.argv[1],'rb').read()[36:]
PL, PLS = 442400, 24240; SV = 408864; SA = 466640
H={0xEDD5E282:"Templates",0x6D61A2F3:"Template",0x183CCBA8:"LastSpawn",0x31F50D46:"Factories",0xA49F34BB:"Location",0x951BD5B6:"Locations"}
def var(i):
    t = struct.unpack_from("<HHHHQQQ", raw, SV + 32*i); return t
# plug records: find all 12-byte records (kind, hash, idx) by scanning for known kinds
kinds = {}
for o in range(0, PLS-12, 4):
    k, h, i = struct.unpack_from("<III", raw, PL+o)
    if k in (0x93BF4450, 0x6A84A393): kinds.setdefault(o % 12, 0); kinds[o%12]+=1
print("plug-record phase counts (offset mod 12):", kinds)
recs = []
for o in range(0, PLS-12, 4):
    k, h, i = struct.unpack_from("<III", raw, PL+o)
    if k in (0x93BF4450, 0x6A84A393) and i < 1048: recs.append((o, k, h, i))
print("records:", len(recs))
for o,k,h,i in recs:
    if i == 153: print("  plug record at Plugs+%d kind %08X plug %s -> Script Vars #%d" % (o, k, H.get(h, "%08X"%h), i))
# all Templates plugs -> var index -> var value
print("\nevery 'Templates' plug and the variable it points at:")
for o,k,h,i in recs:
    if h == 0xEDD5E282:
        t = var(i); print("  Plugs+%-6d -> SV #%-4d (+%-6d) type %d f %04X %04X %04X  value %016X" % (o, i, 32*i, t[0], t[1], t[2], t[3], t[6]))
