#!/usr/bin/env python3
"""stage_multi.py 1.2.0 - build a MULTI-spawner .stage for the Rift Apart Randomizer from one verified original zone.

Standard library only. Reads ONE original zone blob (36-byte toc header + zone, as stage_enemies.py 1.1.0 keeps it in
backup/<id>.zone.orig) and never touches a game folder.

Each change rewrites ONE Zone Script Vars entry, both halves of the actor reference (stage tool 1.1.0's fix):
    u16 Zone Actors index at entry+4   and   u64 uid at entry+16

NEW in 1.2.0 - the SPAWN POINT rule (root cause of the v0.76-DEV4 / tool 1.1.0 in-game result):
    A SunsetSpawnerFactory (class 2E910F8C) places what it spawns at the actors in its `Locations` plug. On Ardolis
    many of those are ANIM CLUES (animclue_pirate_shooter_*, animclue_pirate_melee_*, animclue_toxic_crab_*): poses
    authored for one enemy kind. In the original zone every one of the 28 factory anim-clue spawn points holds a
    template of the clue's own kind (0 mismatches). CECB812E81FB7301 (shooter clue) given the brawler template spawned
    NOTHING on 3 of 3 loads, while the same spawner with a shooter template spawned on 3 of 3 loads (1.0.1 POC session).
    So a factory is changed only when every spawn point is
        - a local actor that is not an anim clue (StaticVolume ...)                       -> tier "volume"
        - an actor of another zone (index FFFF; its type cannot be read from this zone)   -> tier "external" (flagged)
        - an anim clue of the REPLACEMENT's own kind                                       -> allowed
    and refused when any spawn point is an anim clue of another kind, or a group variable (undecoded).

Every other 1.1.0 rule stays: single-owner Templates variable, local reference, uid on exactly one Zone Actors record,
index == record (all type-5 local references of the zone, before and after), only {index, uid} bytes of the changed
entries differ, same size, same section table.

usage:
  python -I stage_multi.py build --orig AE530D22FE113E2B.zone.orig --out NEW_DIR [--change KEY=UID ...]
  python -I stage_multi.py check --orig AE530D22FE113E2B.zone.orig --stage RandoEnemies.stage
  python -I stage_multi.py list  --orig AE530D22FE113E2B.zone.orig            (every factory, its kind and spawn points)
"""
import argparse
import hashlib
import io
import json
import os
import struct
import sys
import zipfile

VERSION = "1.2.0"
STAGE_LUA = "1.1.0"            # 16_rando_spawners.lua / 18_rando_stage_enemies.lua of v0.76-DEV4 (tool 1.1.0)
KIT = "v0.76-DEV4"
STAGE_MOD_PATH = "mods/RandoEnemies.stage"
MANIFEST_LUA = "18_rando_stage_manifest.lua"
HEADER = 36

SEC_ZONE_ACTORS, SEC_SCRIPT_VARS, SEC_SCRIPT_PLUGS = 0x70682CB8, 0xD86A7934, 0xBEAB52E7
SEC_SCRIPT_ACTIONS, SEC_ACTOR_ASSETS = 0x5E54ACCF, 0x78684035
FACTORY_CLASS = 0x2E910F8C
VAR_SIZE, PLUG_SIZE, ACTION_SIZE, ACTOR_SIZE = 32, 12, 40, 32


def crc32_ins(s):
    """Insomniac's plug-name CRC32 (init 0xEDB88320, no final xor). Checked below against two known names."""
    c = 0xEDB88320
    for b in s.encode():
        c ^= b
        for _ in range(8):
            c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
    return c


PLUG_TEMPLATES, PLUG_LOCATIONS = crc32_ins("Templates"), crc32_ins("Locations")
assert PLUG_TEMPLATES == 0xEDD5E282 and PLUG_LOCATIONS == 0x951BD5B6   # V.PLUG_TEMPLATES 3990217346 in 16_rando_spawners.lua
assert PLUG_TEMPLATES == 3990217346

# movement family of each kind (rivet.log ASSET lines: GameBotShooter = ground, GameBotMeleeSwarmer = swarmer)
FAMILY = {"enm_pirate_robot_shooter": "ground", "enm_pirate_robot_melee": "swarmer", "enm_pirate_robot_shielded": "swarmer",
          "enm_pirate_bladeball": "swarmer", "enm_indigenous_crab": "swarmer", "enm_indigenous_puffoid": "swarmer"}
FACTION = {"enm_pirate_robot_shooter": "pirate", "enm_pirate_robot_melee": "pirate", "enm_pirate_robot_shielded": "pirate",
           "enm_pirate_bladeball": "pirate", "enm_indigenous_crab": "indigenous", "enm_indigenous_puffoid": "indigenous"}
# the anim-clue name token of each kind (animclue_<token>_...)
CLUE_TOKEN = {"enm_pirate_robot_shooter": "pirate_shooter", "enm_pirate_robot_melee": "pirate_melee",
              "enm_pirate_robot_shielded": "pirate_shielded", "enm_indigenous_crab": "toxic_crab"}
# pair evidence: V.COMPAT_BUILTIN of 16_rando_spawners.lua (tier A) and the DEV3 runtime outcomes on Ardolis
# (ROOT_CAUSE outcomes.txt: SUCCESS = the replacement spawned from that factory)
PAIRS = {
    ("enm_pirate_robot_shooter", "enm_pirate_robot_melee"): ("A", "V.COMPAT_BUILTIN: round37 20 of 20 spawns, A1 completed twice; round40 its brawlers died"),
    ("enm_pirate_robot_shooter", "enm_pirate_bladeball"): ("A", "V.COMPAT_BUILTIN: round38-40 spawned in A1, A1 completed; round40 its bladeballs died"),
    ("enm_pirate_bladeball", "enm_pirate_robot_melee"): ("A", "V.COMPAT_BUILTIN: round38-40 spawned in A1, A1 completed; round40 its brawlers died"),
    ("enm_indigenous_puffoid", "enm_indigenous_crab"): ("B", "DEV3 Ardolis runtime: F4A34D9C, F607A5D7, FA5FB32C SUCCESS (crabs spawned)"),
    ("enm_pirate_robot_melee", "enm_pirate_robot_shielded"): ("B", "DEV3 Ardolis runtime: FE80D89C SUCCESS (shielded spawned)"),
}
BAD_PAIRS = {("enm_pirate_bladeball", "enm_pirate_robot_shooter"), ("enm_pirate_robot_melee", "enm_pirate_robot_shooter")}

# THE CHANGE SET of this build (ard_firstvisit_gp.zone, Ardolis first visit). Every one: single-owner Templates
# variable, no anim clue among its spawn points. See PHASE_B_REPORT.md for why each was chosen.
DEFAULT_CHANGES = [
    ("FF06CCC2A9AC1EA2", "92C793D47A4657B6"),   # shooter -> brawler   | StaticVolume | DEV3: same spawner, same pair SUCCESS
    ("9C3139C7FFED7137", "C37DB04A5A1F0972"),   # shooter -> bladeball | StaticVolume | tier A pair
    ("FA5FB32C7AAB4C4A", "B69D08BA44EE560E"),   # puffoid -> crab      | external     | DEV3: same spawner, same pair SUCCESS
    ("F93E9AE445CCEF41", "92C793D47A4657B6"),   # shooter x5 -> brawler| external     | tier A pair
    ("DAFCA25C58FD387F", "D7677BCD9AAF5963"),   # puffoid x4 -> crab   | external     | pair seen working at 3 spawners
]


class Refused(Exception):
    pass


def short(path):
    return path.replace("\\", "/").split("/")[-1].replace(".actor", "")


class Zone:
    def __init__(self, blob):
        if len(blob) < HEADER + 16:
            raise Refused("not a zone blob")
        self.header, self.raw = blob[:HEADER], blob[HEADER:]
        raw = self.raw
        magic, typ, size, cnt = struct.unpack_from("<IIIH", raw, 0)
        if magic != 0x44415431:                                  # "1TAD" on disk = DAT1
            raise Refused("no DAT1 magic")
        self.secs = {}
        for k in range(cnt):
            t, o, s = struct.unpack_from("<III", raw, 16 + 12 * k)
            if t in self.secs:
                raise Refused("section %08X twice" % t)
            if o + s > len(raw):
                raise Refused("section %08X out of bounds" % t)
            self.secs[t] = (o, s)
        self.section_table = raw[16:16 + 12 * cnt]
        for t, rs in ((SEC_ZONE_ACTORS, ACTOR_SIZE), (SEC_SCRIPT_VARS, VAR_SIZE), (SEC_SCRIPT_PLUGS, PLUG_SIZE),
                      (SEC_SCRIPT_ACTIONS, ACTION_SIZE)):
            if t not in self.secs or self.secs[t][1] % rs:
                raise Refused("section %08X missing or not a multiple of %d" % (t, rs))
        ao, asz = self.secs[SEC_ACTOR_ASSETS]
        if asz % 12:
            raise Refused("actor-asset table size %d not n*12" % asz)
        n = asz // 12
        self.asset_ids = [struct.unpack_from("<Q", raw, ao + 8 * i)[0] for i in range(n)]
        self.asset_paths = []
        for i in range(n):
            off = struct.unpack_from("<I", raw, ao + 8 * n + 4 * i)[0]
            self.asset_paths.append(raw[off:raw.index(b"\0", off)].decode("latin1"))
        zo, zs = self.secs[SEC_ZONE_ACTORS]
        self.actors = [struct.unpack_from("<IIIIIIQ", raw, zo + ACTOR_SIZE * i) for i in range(zs // ACTOR_SIZE)]
        self.rec_of, self.dup_uids = {}, {}
        for i, a in enumerate(self.actors):
            if a[1] >= n:
                raise Refused("Zone Actors #%d: asset index %d out of range" % (i, a[1]))
            if a[6] in self.rec_of:
                self.dup_uids.setdefault(a[6], [self.rec_of[a[6]]]).append(i)
            else:
                self.rec_of[a[6]] = i
        vo, vs = self.secs[SEC_SCRIPT_VARS]
        self.var_base = vo
        self.vars = [struct.unpack_from("<HHHHQQQ", raw, vo + VAR_SIZE * v) for v in range(vs // VAR_SIZE)]
        po, ps = self.secs[SEC_SCRIPT_PLUGS]
        self.plugs = [struct.unpack_from("<III", raw, po + PLUG_SIZE * p) for p in range(ps // PLUG_SIZE)]   # name crc, var, kind
        so, ss = self.secs[SEC_SCRIPT_ACTIONS]
        self.nodes, seen = [], [0] * len(self.plugs)
        for r in range(ss // ACTION_SIZE):
            o = so + ACTION_SIZE * r
            key = struct.unpack_from("<Q", raw, o)[0]
            a0, a1, b0, b1 = struct.unpack_from("<HHHH", raw, o + 18)
            cls = struct.unpack_from("<I", raw, o + 28)[0]
            plugs = []
            for f, c in ((a0, a1), (b0, b1)):
                if f == 0xFFFF:
                    continue
                for p in range(f, f + c):
                    if p >= len(self.plugs):
                        raise Refused("Script Actions #%d: plug %d out of range" % (r, p))
                    seen[p] += 1
                    plugs.append(p)
            self.nodes.append({"r": r, "key": key, "cls": cls, "plugs": plugs})
        if any(x != 1 for x in seen):
            raise Refused("Script Actions plug ranges do not partition Script Plugs exactly once")
        self.owners = {}
        for nd in self.nodes:
            for p in nd["plugs"]:
                name, vi, kind = self.plugs[p]
                if vi >= len(self.vars):
                    raise Refused("plug %d -> Script Vars %d out of range" % (p, vi))
                self.owners.setdefault(vi, []).append((nd, p, name))

    def kind_of_rec(self, rec):
        return short(self.asset_paths[self.actors[rec][1]])

    def node(self, key):
        hits = [n for n in self.nodes if n["key"] == key]
        if len(hits) != 1:
            raise Refused("node %016X: %d records" % (key, len(hits)))
        return hits[0]

    def var_form(self, vi):
        typ, aux, idx, aux2, name, uid, pad = self.vars[vi]
        if typ != 5:
            return "not-actor"
        if uid == 0:
            return "group" if aux != 0xFFFF else "empty"
        if idx == 0xFFFF:
            return "external"
        return "local"

    def c1(self):
        """every local type-5 reference: index == the Zone Actors record of its uid; external ones: uid not in zone"""
        bad = []
        n = 0
        for vi, v in enumerate(self.vars):
            f = self.var_form(vi)
            if f == "local":
                n += 1
                if self.rec_of.get(v[5]) != v[2] or v[5] in self.dup_uids:
                    bad.append(vi)
            elif f == "external" and v[5] in self.rec_of:
                bad.append(vi)
        return n, bad

    def factory(self, key):
        nd = self.node(key)
        if nd["cls"] != FACTORY_CLASS:
            raise Refused("%016X is class %08X, not SunsetSpawnerFactory %08X" % (key, nd["cls"], FACTORY_CLASS))
        tpl = [(p, self.plugs[p][1]) for p in nd["plugs"] if self.plugs[p][0] == PLUG_TEMPLATES]
        if len(tpl) != 1:
            raise Refused("%016X has %d Templates plugs" % (key, len(tpl)))
        locs = []
        for p in nd["plugs"]:
            if self.plugs[p][0] != PLUG_LOCATIONS:
                continue
            vi = self.plugs[p][1]
            f = self.var_form(vi)
            v = self.vars[vi]
            if f == "local":
                locs.append(("local", vi, v[5], self.kind_of_rec(v[2])))
            elif f == "external":
                locs.append(("external", vi, v[5], None))
            else:
                locs.append((f, vi, v[5], None))
        return nd, tpl[0], locs

    def template_users(self):
        """uid -> factory keys whose Templates variable references it (a template the game really spawns from)"""
        out = {}
        for nd in self.nodes:
            if nd["cls"] != FACTORY_CLASS:
                continue
            for p in nd["plugs"]:
                if self.plugs[p][0] == PLUG_TEMPLATES and self.var_form(self.plugs[p][1]) == "local":
                    out.setdefault(self.vars[self.plugs[p][1]][5], []).append("%016X" % nd["key"])
        return out


def spawn_point_verdict(locs, replacement):
    """(ok, tier, text) of the spawn point rule"""
    if not locs:
        return False, None, "no Locations plug: spawn point unknown"
    tiers, parts = set(), []
    for form, vi, uid, kind in locs:
        if form == "local" and kind.startswith("animclue_"):
            tok = CLUE_TOKEN.get(replacement)
            if tok and kind.startswith("animclue_" + tok + "_"):
                tiers.add("volume")
                parts.append("%s (anim clue of the replacement's own kind)" % kind)
                continue
            return False, None, "spawn point %s is an anim clue of another kind (SV #%d): the replacement cannot use it" % (kind, vi)
        if form == "local":
            tiers.add("volume")
            parts.append(kind)
        elif form == "external":
            tiers.add("external")
            parts.append("external actor %016X (another zone)" % uid)
        else:
            return False, None, "spawn point SV #%d is a %s variable (undecoded)" % (vi, form)
    tier = "external" if "external" in tiers else "volume"
    return True, tier, ", ".join(parts)


def plan(z, key_hex, rep_uid_hex, allow_unproven=False):
    key, rep = int(key_hex, 16), int(rep_uid_hex, 16)
    nd, (tplug, vi), locs = z.factory(key)
    own = z.owners.get(vi, [])
    if len(own) != 1:
        raise Refused("%s: its Templates variable SV #%d has %d owners %s - a change would reach them all" % (
            key_hex, vi, len(own), ["%016X/%08X" % (o[0]["key"], o[2]) for o in own]))
    if z.var_form(vi) != "local":
        raise Refused("%s: SV #%d is a %s reference" % (key_hex, vi, z.var_form(vi)))
    typ, aux, idx, aux2, name, uid, pad = z.vars[vi]
    if z.rec_of.get(uid) != idx:
        raise Refused("%s: SV #%d is inconsistent already (index %d, uid record %s)" % (key_hex, vi, idx, z.rec_of.get(uid)))
    if rep in z.dup_uids:
        raise Refused("replacement %s is on several Zone Actors records" % rep_uid_hex)
    rrec = z.rec_of.get(rep)
    if rrec is None:
        raise Refused("replacement %s is not an actor of this zone" % rep_uid_hex)
    if rrec > 0xFFFE:
        raise Refused("replacement record %d does not fit 16 bits" % rrec)
    if rep == uid:
        raise Refused("the replacement is the original")
    users = z.template_users().get(rep, [])
    if not users:
        raise Refused("replacement %s is not the template of any factory in this zone (not a proven template actor)" % rep_uid_hex)
    o_kind, r_kind = z.kind_of_rec(idx), z.kind_of_rec(rrec)
    if o_kind not in FAMILY or r_kind not in FAMILY:
        raise Refused("%s: %s -> %s: a kind this build does not handle" % (key_hex, o_kind, r_kind))
    if FACTION[o_kind] != FACTION[r_kind]:
        raise Refused("%s: %s -> %s crosses factions" % (key_hex, o_kind, r_kind))
    if (o_kind, r_kind) in BAD_PAIRS:
        raise Refused("%s: %s -> %s is a pair proven BAD in game" % (key_hex, o_kind, r_kind))
    ev = PAIRS.get((o_kind, r_kind))
    if not ev and not allow_unproven:
        raise Refused("%s: %s -> %s has no in-game evidence" % (key_hex, o_kind, r_kind))
    ok, sp_tier, sp_text = spawn_point_verdict(locs, r_kind)
    if not ok:
        raise Refused("%s: %s" % (key_hex, sp_text))
    count = None
    for p in nd["plugs"]:
        if z.plugs[p][0] == 0x90D607B0:                       # the factory's float spawn count (1.0 / 2.0 / ...)
            v = z.vars[z.plugs[p][1]]
            if v[0] == 2:
                count = struct.unpack("<f", struct.pack("<I", v[5] & 0xFFFFFFFF))[0]
    entry = z.var_base + VAR_SIZE * vi
    return {
        "key": key_hex.upper(), "action": nd["r"], "plug": tplug, "var_index": vi, "entry_abs": entry,
        "entry_rel": entry - z.secs[SEC_SCRIPT_VARS][0],
        "original_uid": "%016X" % uid, "original_index": idx, "original": o_kind, "original_family": FAMILY[o_kind],
        "replacement_uid": "%016X" % rep, "replacement_index": rrec, "replacement": r_kind, "replacement_family": FAMILY[r_kind],
        "replacement_template_of": users, "pair_tier": ev[0] if ev else "unproven", "pair_evidence": ev[1] if ev else "-",
        "spawn_point_tier": sp_tier, "spawn_points": sp_text, "count": count,
        "pair": "factory|%s/%s>%s/%s" % (o_kind[:19], FAMILY[o_kind], r_kind[:19], FAMILY[r_kind]),
    }


def apply(raw, changes):
    out = bytearray(raw)
    for c in changes:
        a = c["entry_abs"]
        out[a + 4:a + 6] = struct.pack("<H", c["replacement_index"])
        out[a + 16:a + 24] = struct.pack("<Q", int(c["replacement_uid"], 16))
    return bytes(out)


def compare(z0, z1, changes):
    """the only allowed differences: {index, uid} of the planned entries; everything else identical"""
    problems = []
    if len(z0.raw) != len(z1.raw):
        problems.append("size differs")
    if z0.header != z1.header:
        problems.append("toc header differs")
    if z0.section_table != z1.section_table:
        problems.append("section table differs")
    allowed = set()
    for c in changes:
        a = c["entry_abs"]
        allowed |= set(range(a + 4, a + 6)) | set(range(a + 16, a + 24))
    diff = [i for i in range(min(len(z0.raw), len(z1.raw))) if z0.raw[i] != z1.raw[i]]
    stray = [i for i in diff if i not in allowed]
    if stray:
        problems.append("%d byte(s) outside the planned fields, first at %d" % (len(stray), stray[0]))
    n, bad = z1.c1()
    if bad:
        problems.append("C1: %d inconsistent actor reference(s): SV %s" % (len(bad), bad[:10]))
    for c in changes:
        v = z1.vars[c["var_index"]]
        if "%016X" % v[5] != c["replacement_uid"] or v[2] != c["replacement_index"]:
            problems.append("SV #%d does not hold the replacement" % c["var_index"])
        if v[0] != 5 or v[1] != 0xFFFF or v[3] != 0xFFFF or v[6] != 0:
            problems.append("SV #%d: type/aux/padding changed" % c["var_index"])
        if v[4] != z0.vars[c["var_index"]][4]:
            problems.append("SV #%d: name hash changed" % c["var_index"])
    return problems, diff, n


def write_stage(path, member, data, description):
    info = json.dumps({"author": "Rift Apart Randomizer", "description": description, "game": "RCRA",
                       "name": "Rift Apart Randomizer - Enemy .stage (%s, stage_multi %s)" % (KIT, VERSION)}, indent=2)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, payload in (("info.json", info.encode()), (member, data)):
            zi = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.create_system = 3
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, payload)
    with open(path, "wb") as f:
        f.write(buf.getvalue())


def read_stage_member(path):
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist() if n != "info.json"]
        if len(names) != 1:
            raise Refused("%s holds %d zone members" % (path, len(names)))
        info = json.loads(zf.read("info.json"))
        return names[0], zf.read(names[0]), info


def lua_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def manifest_lua(m):
    L = ["-- generated by stage_multi.py %s (%s, stage tool 1.1.0 format). DATA, not a script to edit." % (VERSION, KIT),
         "-- It tells 18_rando_stage_enemies.lua which spawners the installed %s changed on disk." % STAGE_MOD_PATH,
         "-- Remove it together with mods/RandoEnemies.stage to turn the .stage Enemy Randomizer off.",
         "RANDO_STAGE_ENEMIES = {",
         "  format = 1, tool = %s, kit = %s, label = %s, stage_lua = %s," % (lua_str(VERSION), lua_str(KIT), lua_str(m["label"]), lua_str(STAGE_LUA)),
         "  stage_file = %s, stage_sha256 = %s," % (lua_str(STAGE_MOD_PATH), lua_str(m["stage_sha256"])),
         "  changes = {"]
    for c in m["changes"]:
        L.append("    { zone = %s, zone_id = %s, section = %s, offset = %d, var_index = %d," % (
            lua_str(c["zone"]), lua_str(c["zone_id"]), lua_str("Zone Script Vars"), c["entry_rel"], c["var_index"]))
        L.append("      original_uid = %s, original_index = %d, original = %s, original_family = %s," % (
            lua_str(c["original_uid"]), c["original_index"], lua_str(c["original"]), lua_str(c["original_family"])))
        L.append("      replacement_uid = %s, replacement_index = %d, replacement = %s, replacement_family = %s," % (
            lua_str(c["replacement_uid"]), c["replacement_index"], lua_str(c["replacement"]), lua_str(c["replacement_family"])))
        L.append("      original_refs = %d, replacement_refs = %d," % (c["original_refs"], c["replacement_refs"]))
        L.append("      pair = %s, spawner_keys = { %s } }," % (lua_str(c["pair"]), lua_str(c["key"])))
    L += ["  },", "}", ""]
    return "\n".join(L)


ZONE_PATH = "levels\\i29\\instance\\ardolis\\ardolis_main\\ard_firstvisit_gp.zone"
ZONE_ID = "AE530D22FE113E2B"
ZONE_SHA256 = "d40540edad455dee68a274540cd53589b3142ce458bac16bde82a0d6f185e016"   # the zone the probe read from the game


def cmd_build(a):
    if os.path.exists(a.out) and os.listdir(a.out):
        raise Refused("%s exists and is not empty: never overwrite a build" % a.out)
    blob = open(a.orig, "rb").read()
    z0 = Zone(blob)
    zsha = hashlib.sha256(z0.raw).hexdigest()
    if zsha != ZONE_SHA256:
        raise Refused("original zone sha256 %s is not the verified %s" % (zsha, ZONE_SHA256))
    n0, bad0 = z0.c1()
    if bad0:
        raise Refused("the ORIGINAL zone fails C1 (%s)" % bad0[:5])
    pairs = [tuple(x.split("=")) for x in a.change] if a.change else DEFAULT_CHANGES
    changes, refused = [], []
    for k, r in pairs:
        try:
            c = plan(z0, k, r, a.allow_unproven)
        except Refused as e:
            refused.append((k, r, str(e)))
            continue
        if any(x["var_index"] == c["var_index"] for x in changes):
            refused.append((k, r, "SV #%d already changed" % c["var_index"]))
            continue
        changes.append(c)
    if not changes:
        raise Refused("nothing to build")
    # every replacement must stay the template of at least one UNCHANGED native factory (the game keeps spawning it
    # there, so it is a live, working template actor in this zone after the patch too)
    changed = {c["key"] for c in changes}
    for c in list(changes):
        if not [k for k in c["replacement_template_of"] if k not in changed]:
            refused.append((c["key"], c["replacement_uid"], "its replacement would no longer be the template of any unchanged factory"))
            changes.remove(c)
    for k, r, why in refused:
        print("REFUSED %s -> %s: %s" % (k, r, why))
    if a.change and refused:
        raise Refused("%d requested change(s) refused" % len(refused))
    if not changes:
        raise Refused("nothing to build")
    new = apply(z0.raw, changes)
    z1 = Zone(z0.header + new)
    problems, diff, n1 = compare(z0, z1, changes)
    if problems:
        raise Refused("; ".join(problems))
    # reference counts, as 18_rando_stage_enemies.lua prints them ("zone file N, N+1 expected" / "N-1 expected"): with
    # several changes sharing a kind, the per-change +1/-1 is wrong, so the fields are set so that 18's "expected" value
    # is the real count in the PATCHED zone (the true original-zone counts are kept in *_original_zone, JSON only)
    def refs(zz, uid):
        return sum(1 for v in zz.vars if v[0] == 5 and "%016X" % v[5] == uid)
    for c in changes:
        c.update(zone=ZONE_PATH, zone_id=ZONE_ID)
        c["original_refs"] = refs(z1, c["original_uid"]) + 1           # 18 prints original_refs - 1 as "expected"
        c["original_refs_original_zone"] = refs(z0, c["original_uid"])
        c["replacement_refs"] = refs(z1, c["replacement_uid"]) - 1
        c["replacement_refs_original_zone"] = refs(z0, c["replacement_uid"])
        c["changed_bytes"] = [i for i in diff if c["entry_abs"] <= i < c["entry_abs"] + VAR_SIZE]
    os.makedirs(a.out, exist_ok=True)
    os.makedirs(os.path.join(a.out, "backup"), exist_ok=True)
    stage = os.path.join(a.out, "RandoEnemies.stage")
    member = "0/" + ZONE_ID
    desc = "Phase B: ard_firstvisit_gp.zone, %d spawners (uid + Zone Actors index; spawn-point rule): %s" % (
        len(changes), ", ".join("%s %s->%s" % (c["key"][:8], c["original"].replace("enm_", ""), c["replacement"].replace("enm_", "")) for c in changes))
    write_stage(stage, member, z0.header + new, desc)
    ssha = hashlib.sha256(open(stage, "rb").read()).hexdigest()
    m_name, m_data, info = read_stage_member(stage)
    reread = m_name == member and m_data == z0.header + new and info.get("game") == "RCRA"
    if not reread:
        raise Refused("the .stage does not read back as written")
    with open(os.path.join(a.out, "backup", ZONE_ID + ".zone.orig"), "wb") as f:
        f.write(blob)
    m = {"format": 1, "tool": VERSION, "kit": KIT, "stage_lua": STAGE_LUA,
         "label": "Phase B multi spawner (uid + index, spawn-point rule)", "stage_sha256": ssha,
         "zone_sha256_original": zsha, "zone_sha256_patched": hashlib.sha256(new).hexdigest(),
         "changes": changes, "refused": [{"key": k, "replacement": r, "why": w} for k, r, w in refused]}
    json.dump(m, open(os.path.join(a.out, "stage_enemies_manifest.json"), "w"), indent=1)
    open(os.path.join(a.out, MANIFEST_LUA), "w", encoding="utf-8").write(manifest_lua(m))
    rep = report(z0, z1, changes, refused, diff, n0, n1, stage, ssha, member)
    open(os.path.join(a.out, "STATIC_VERIFICATION.txt"), "w").write(rep)
    print(rep)


def report(z0, z1, changes, refused, diff, n0, n1, stage, ssha, member):
    L = ["STATIC VERIFICATION - RandoEnemies.stage (stage_multi %s, %s)" % (VERSION, KIT),
         "RESULT: PASS (static only: a correct, minimal, self-consistent file; NOT proof of in-game behaviour)", "",
         "zone   %s (%s), %d bytes, 36-byte toc header kept" % (ZONE_PATH, ZONE_ID, len(z0.raw)),
         "sha256 original zone %s" % hashlib.sha256(z0.raw).hexdigest(),
         "       patched zone  %s" % hashlib.sha256(z1.raw).hexdigest(),
         "       .stage        %s (member %s)" % (ssha, member), "",
         "C1 actor references: original %d local, all consistent | patched %d local, all consistent" % (n0, n1),
         "Section table, size, header: identical. Bytes changed: %d, all inside {index, uid} of the %d entries below." % (len(diff), len(changes)), ""]
    for i, c in enumerate(changes, 1):
        L.append("CHANGE %d  spawner %s (Script Actions #%d, SunsetSpawnerFactory) -> plug #%d Templates -> Script Vars #%d (zone +%d)" % (
            i, c["key"], c["action"], c["plug"], c["var_index"], c["entry_abs"]))
        L.append("          %s uid %s #%d  ->  %s uid %s #%d   (count %s)" % (
            c["original"], c["original_uid"], c["original_index"], c["replacement"], c["replacement_uid"], c["replacement_index"], c["count"]))
        L.append("          pair tier %s: %s" % (c["pair_tier"], c["pair_evidence"]))
        L.append("          spawn points [%s]: %s" % (c["spawn_point_tier"], c["spawn_points"]))
        L.append("          replacement is the template of native factory %s" % ", ".join(c["replacement_template_of"]))
        a = c["entry_abs"]
        L.append("          entry before %s" % z0.raw[a:a + VAR_SIZE].hex(" "))
        L.append("          entry after  %s" % z1.raw[a:a + VAR_SIZE].hex(" "))
        L.append("          bytes %s" % ", ".join("+%d %02X->%02X" % (p, z0.raw[p], z1.raw[p]) for p in c["changed_bytes"]))
        L.append("")
    if refused:
        L.append("REFUSED (not in this build)")
        for k, r, w in refused:
            L.append("  %s -> %s: %s" % (k, r, w))
    return "\n".join(L) + "\n"


def cmd_check(a):
    z0 = Zone(open(a.orig, "rb").read())
    name, data, info = read_stage_member(a.stage)
    z1 = Zone(data)
    diff = [i for i in range(len(z0.raw)) if z0.raw[i] != z1.raw[i]]
    entries = sorted({(i - z0.var_base) // VAR_SIZE for i in diff if z0.var_base <= i < z0.var_base + VAR_SIZE * len(z0.vars)})
    print("%s: member %s, %d byte(s) differ in %d Script Vars entr(y/ies) %s" % (a.stage, name, len(diff), len(entries), entries))
    n, bad = z1.c1()
    print("C1: %d local actor references, %d inconsistent %s" % (n, len(bad), bad[:10]))
    ok = not bad
    for vi in entries:
        own = z0.owners.get(vi, [])
        nd = own[0][0] if own else None
        v0, v1 = z0.vars[vi], z1.vars[vi]
        line = "  SV #%d owners %d %s: %s #%d -> %s #%d" % (vi, len(own), ("%016X" % nd["key"]) if nd else "-",
                                                         z0.kind_of_rec(v0[2]), v0[2], z1.kind_of_rec(v1[2]) if v1[2] != 0xFFFF else "?", v1[2])
        if nd and nd["cls"] == FACTORY_CLASS:
            _, _, locs = z0.factory(nd["key"])
            sp_ok, tier, text = spawn_point_verdict(locs, z1.kind_of_rec(v1[2]))
            line += " | spawn points %s: %s" % ("OK " + tier if sp_ok else "REFUSED", text)
            ok = ok and sp_ok
        ok = ok and len(own) == 1
        print(line)
    print("CHECK", "PASS" if ok else "FAIL")
    return 0 if ok else 1


def cmd_list(a):
    z = Zone(open(a.orig, "rb").read())
    users = z.template_users()
    for nd in sorted((n for n in z.nodes if n["cls"] == FACTORY_CLASS), key=lambda n: n["key"]):
        try:
            _, (p, vi), locs = z.factory(nd["key"])
        except Refused as e:
            print("%016X %s" % (nd["key"], e))
            continue
        f = z.var_form(vi)
        kind = z.kind_of_rec(z.vars[vi][2]) if f == "local" else f
        sp = "; ".join(l[3] if l[0] == "local" else l[0] for l in locs)
        print("%016X SV#%-4d owners %d %-28s | %s" % (nd["key"], vi, len(z.owners.get(vi, [])), kind, sp))
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build"); b.add_argument("--orig", required=True); b.add_argument("--out", required=True)
    b.add_argument("--change", action="append", help="KEY=REPLACEMENT_UID (repeatable); default: the built-in change set")
    b.add_argument("--allow-unproven", action="store_true")
    c = sub.add_parser("check"); c.add_argument("--orig", required=True); c.add_argument("--stage", required=True)
    l = sub.add_parser("list"); l.add_argument("--orig", required=True)
    a = ap.parse_args()
    try:
        return {"build": cmd_build, "check": cmd_check, "list": cmd_list}[a.cmd](a) or 0
    except Refused as e:
        print("REFUSED:", e)
        return 2


if __name__ == "__main__":
    sys.exit(main())
