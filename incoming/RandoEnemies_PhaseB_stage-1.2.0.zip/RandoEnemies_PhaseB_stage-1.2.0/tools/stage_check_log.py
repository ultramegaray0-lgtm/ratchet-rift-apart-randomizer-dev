#!/usr/bin/env python3
"""stage_check_log.py 1.2.0 - read a rivet.log and say, per .stage change, what the game really did.

Only rivet.log is needed: the changed spawners come from the log's own "STAGE CHANGE n: ... | spawners KEY" lines
(18_rando_stage_enemies.lua prints them from the installed manifest).

Per changed spawner, per level visit:
  LISTED      "STAGE VARIABLE factory KEY: holds <uid> ... IS loaded" - the patched zone is in memory and the spawner exists
  SPAWNS      every "RANDO-ENEMIES SPAWN <handle> ... factory Templates KEY ... spawned <kind>" line (one per actor the
              factory created; SpawnerSpawnEvent carries the factory's own actor handle, see V.on_spawn_seen)
  ACTIVE      DialogStartedEvent lines whose SenderHandle is one of those actors (combat barks: ENGAGED, MELEEATTACK, ...)
  DEATH/GONE  "STAGE DEATH <h>" / "STAGE GONE <h>"
Verdicts:
  WORKED            the replacement kind spawned from the changed spawner
  ORIGINAL SPAWNED  the changed spawner still made the original kind
  NO SPAWN          listed (zone loaded, spawner present) but it never spawned while the level was loaded
  NOT REACHED       the spawner was never listed (its area or encounter was not played)
It also names spawners that 18's summary counts only because their variable natively holds a replacement uid.

usage: python -I stage_check_log.py rivet.log
"""
import re
import sys
from collections import OrderedDict, defaultdict


def short(n):
    return n.replace("enm_", "")


def main(path):
    lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    changes = OrderedDict()                     # key -> (n, original, replacement)
    re_change = re.compile(r"STAGE CHANGE (\d+): .*?\(([^)]+)\) -> [0-9A-F]{16}(?: #\d+)? \(([^)]+)\) \| .*\| spawners (.*)$")
    for l in lines:
        m = re_change.search(l)
        if m:
            for k in m.group(4).split(","):
                k = k.strip().upper()
                if re.fullmatch(r"[0-9A-F]{16}", k):
                    changes[k] = (int(m.group(1)), m.group(2), m.group(3))
    if not changes:
        print("no 'STAGE CHANGE' line: 18_rando_stage_enemies.lua did not run or no .stage manifest is installed")
        return 1
    rep_kinds = {v[2] for v in changes.values()}
    visit = 0
    vis = defaultdict(lambda: defaultdict(lambda: {"listed": None, "spawns": [], "dead": set(), "gone": set()}))
    native = defaultdict(lambda: defaultdict(int))
    bark = defaultdict(list)
    where = {}
    re_spawn = re.compile(r"RANDO-ENEMIES\tSPAWN (\d+) \| (\S+) \| (.*?) \| factory Templates ([0-9A-F]{16}) \| original (\S+) \| selected \S+ \| spawned (\S+)")
    re_var = re.compile(r"STAGE VARIABLE factory ([0-9A-F]{16}): holds ([0-9A-F]{16})")
    re_dlg = re.compile(r"SenderHandle=(\d+) SoundEventId=\d+ SoundEventName=(\S+)")
    re_sd = re.compile(r"STAGE (DEATH|GONE) (\d+)")
    for l in lines:
        if "RANDO-DISCOVER\tPlanetChangedEvent" in l or "CheckpointTriggeredEvent" in l and "Loaded=true" in l:
            visit += 1
            where[visit] = l.split("\t")[-1].strip()
            continue
        m = re_var.search(l)
        if m and m.group(1) in changes:
            vis[m.group(1)][visit]["listed"] = m.group(2)
            continue
        m = re_spawn.search(l)
        if m:
            h, key, kind = int(m.group(1)), m.group(4), m.group(6)
            if key in changes:
                vis[key][visit]["spawns"].append((h, kind, m.group(3)))
            elif any(kind.startswith(r[:19]) for r in rep_kinds) and "STAGE" not in l:
                native[key][kind] += 1
            continue
        m = re_dlg.search(l)
        if m:
            bark[int(m.group(1))].append(m.group(2))
            continue
        m = re_sd.search(l)
        if m:
            for key in vis:
                for v in vis[key].values():
                    if any(s[0] == int(m.group(2)) for s in v["spawns"]):
                        v["dead" if m.group(1) == "DEATH" else "gone"].add(int(m.group(2)))
    print("rivet.log: %s | %d changed spawner(s)" % (path, len(changes)))
    worst = 0
    for key, (n, orig, rep) in changes.items():
        print("\nCHANGE %d  %s  %s -> %s" % (n, key, orig, rep))
        if key not in vis:
            print("  NOT REACHED: the spawner was never listed on any visit (play the area that holds it)")
            continue
        total = {"WORKED": 0, "ORIGINAL SPAWNED": 0, "NO SPAWN": 0}
        for v_i, v in sorted(vis[key].items()):
            sp = v["spawns"]
            kinds = defaultdict(int)
            for h, kind, enc in sp:
                kinds[kind] += 1
            if not sp:
                verdict = "NO SPAWN" if v["listed"] else "listed earlier, no spawn on this visit"
            elif any(k.startswith(rep[:19]) for k in kinds):
                verdict = "WORKED"
            elif any(k.startswith(orig[:19]) for k in kinds):
                verdict = "ORIGINAL SPAWNED"
            else:
                verdict = "something else spawned"
            if verdict in total:
                total[verdict] += 1
            print("  visit %d (%s): %s | listed %s | spawns %d %s" % (
                v_i, where.get(v_i, "start"), verdict, v["listed"] or "-", len(sp),
                dict(kinds) if kinds else ""))
            for h, kind, enc in sp:
                b = bark.get(h, [])
                fate = "died" if h in v["dead"] else "gone" if h in v["gone"] else "no death seen"
                print("      actor %d %s @ %s | %s | barks %d%s" % (h, short(kind), enc, fate, len(b),
                                                                 (": " + ", ".join(b[:4])) if b else ""))
        verdict = "WORKED" if total["WORKED"] else "ORIGINAL SPAWNED" if total["ORIGINAL SPAWNED"] else "NO SPAWN" if total["NO SPAWN"] else "NOT REACHED"
        worst = max(worst, {"WORKED": 0, "NOT REACHED": 1, "ORIGINAL SPAWNED": 2, "NO SPAWN": 2}[verdict])
        print("  => %s" % verdict)
    if native:
        print("\nNot changed by the .stage (their own zone data already uses a replacement kind; 18's STAGE SUMMARY may count them):")
        for key, kinds in sorted(native.items()):
            print("  %s %s" % (key, dict(kinds)))
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
