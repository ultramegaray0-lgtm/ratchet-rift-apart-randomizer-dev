#!/usr/bin/env python3
"""tests for stage_multi.py 1.2.0 and stage_check_log.py against the REAL Ardolis zone and the REAL DEV4 rivet.log.
usage: python -I test_stage_multi.py <AE530D22FE113E2B.zone.orig> <tool-1.1.0 RandoEnemies.stage> <rivet.log of that run>"""
import hashlib
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import stage_multi as S  # noqa: E402

ORIG, OLD_STAGE, LOG = sys.argv[1:4]
fails = 0


def check(cond, what):
    global fails
    print(("PASS " if cond else "FAIL ") + what)
    if not cond:
        fails += 1


def run(*args):
    r = subprocess.run([sys.executable, "-I"] + list(args), capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


blob = open(ORIG, "rb").read()
z = S.Zone(blob)
check(hashlib.sha256(z.raw).hexdigest() == S.ZONE_SHA256, "original zone is the verified game zone (sha256 d40540ed...)")
n, bad = z.c1()
check(n == 302 and not bad, "C1 on the original zone: 302 local actor references, all index == record")

# 1. the writer reproduces stage tool 1.1.0's bytes exactly (same reference layout)
_, (p, vi), locs = z.factory(0xCECB812E81FB7301)
new = S.apply(z.raw, [{"entry_abs": z.var_base + 32 * vi, "replacement_index": 25, "replacement_uid": "92C793D47A4657B6"}])
name, data, info = S.read_stage_member(OLD_STAGE)
check(data == z.header + new, "uid+index writer == tool 1.1.0's patched zone byte for byte (sha256 %s)" % hashlib.sha256(new).hexdigest()[:12])

# 2. the spawn-point rule
clues = mism = 0
for nd in z.nodes:
    if nd["cls"] != S.FACTORY_CLASS:
        continue
    try:
        _, (pp, v), ls = z.factory(nd["key"])
    except S.Refused:
        continue
    if z.var_form(v) != "local":
        continue
    kind = z.kind_of_rec(z.vars[v][2])
    for form, _, _, k in ls:
        if form == "local" and k.startswith("animclue_"):
            clues += 1
            tok = S.CLUE_TOKEN.get(kind)
            if not tok or not k.startswith("animclue_" + tok + "_"):
                mism += 1
check(clues == 28 and mism == 0, "original zone: 28 factory anim-clue spawn points, 0 hold another kind's template (%d/%d)" % (clues, mism))
ok, _, why = S.spawn_point_verdict(locs, "enm_pirate_robot_melee")
check(not ok and "animclue_pirate_shooter" in why, "CECB812E81FB7301 -> brawler refused: its spawn point is a shooter anim clue")
ok, _, _ = S.spawn_point_verdict(locs, "enm_pirate_robot_shooter")
check(ok, "the same spawn point accepts its own kind (the rule is about the kind, not the spawner)")
rc, out = run(os.path.join(HERE, "stage_multi.py"), "check", "--orig", ORIG, "--stage", OLD_STAGE)
check(rc == 1 and "CHECK FAIL" in out and "anim clue of another kind" in out, "check: the installed tool 1.1.0 .stage FAILS the new rule")


def refused(key, rep, word, allow=False):
    try:
        S.plan(z, key, rep, allow)
        return False
    except S.Refused as e:
        return word in str(e)


check(refused("CECB812E81FB7301", "92C793D47A4657B6", "anim clue"), "plan refuses CECB812E -> brawler (anim clue)")
check(refused("F3D033F9CBFADB82", "92C793D47A4657B6", "owners"), "plan refuses a shared Templates variable (F3D033F9, 2 owners)")
check(refused("B2CF597110438D36", "C1EE87C86B7840DD", "group", True), "plan refuses a group spawn point (B2CF5971)")
check(refused("FF06CCC2A9AC1EA2", "B69D08BA44EE560E", "factions"), "plan refuses a cross-faction pair")
check(refused("FF06CCC2A9AC1EA2", "C1EE87C86B7840DD", "no in-game evidence"), "plan refuses a pair without in-game evidence")
check(refused("FF06CCC2A9AC1EA2", "1111111111111111", "not an actor"), "plan refuses a uid that is not in the zone")
check(refused("FF06CCC2A9AC1EA2", "8416CF7558A4694D", "is the original"), "plan refuses replacement == original")
check(refused("E6705A36656EB7B9", "AF0189E66C49DA08", "owners"), "plan refuses E6705A36 (its variable is shared with EB58695242E0D633)")

# 3. the default build
with tempfile.TemporaryDirectory() as t:
    o1, o2 = os.path.join(t, "a"), os.path.join(t, "b")
    rc, out = run(os.path.join(HERE, "stage_multi.py"), "build", "--orig", ORIG, "--out", o1)
    check(rc == 0 and "RESULT: PASS" in out, "default build: PASS")
    rc2, _ = run(os.path.join(HERE, "stage_multi.py"), "build", "--orig", ORIG, "--out", o2)
    s1 = open(os.path.join(o1, "RandoEnemies.stage"), "rb").read()
    s2 = open(os.path.join(o2, "RandoEnemies.stage"), "rb").read()
    check(rc2 == 0 and s1 == s2, "two builds are byte-identical (sha256 %s)" % hashlib.sha256(s1).hexdigest()[:12])
    rc3, out3 = run(os.path.join(HERE, "stage_multi.py"), "build", "--orig", ORIG, "--out", o1)
    check(rc3 == 2 and "never overwrite" in out3, "build refuses an existing output folder")
    rc, out = run(os.path.join(HERE, "stage_multi.py"), "check", "--orig", ORIG, "--stage", os.path.join(o1, "RandoEnemies.stage"))
    check(rc == 0 and "CHECK PASS" in out and "5 Script Vars entr" in out and "45 byte(s)" in out,
          "check: the new .stage changes 45 bytes in 5 entries, every one single-owner with a usable spawn point")
    zz = S.Zone(S.read_stage_member(os.path.join(o1, "RandoEnemies.stage"))[1])
    check(zz.header == z.header and len(zz.raw) == len(z.raw) and zz.section_table == z.section_table, "header, size, section table kept")
    for key in ("CECB812E81FB7301", "E6705A36656EB7B9"):
        _, (pp, v), _ = z.factory(int(key, 16))
        check(zz.raw[zz.var_base + 32 * v: zz.var_base + 32 * v + 32] == z.raw[z.var_base + 32 * v: z.var_base + 32 * v + 32],
              "%s is left exactly as the game ships it" % key)
    rc, out = run(os.path.join(HERE, "stage_multi.py"), "build", "--orig", ORIG, "--out", os.path.join(t, "c"),
                  "--change", "9C3139C7FFED7137=C37DB04A5A1F0972", "--change", "86685D806D648CAA=AF0189E66C49DA08")
    check(rc == 2 and "no longer be the template" in out, "refuses to take a replacement's last native user away (bladeball)")
    # the manifest, read by Lua 5.4 the way 18_rando_stage_enemies.lua's ST.index() reads it
    try:
        from lupa import LuaRuntime
        L = LuaRuntime()
        L.execute(open(os.path.join(o1, S.MANIFEST_LUA), encoding="utf-8").read())
        m = L.globals().RANDO_STAGE_ENEMIES
        keys = []
        for i in range(1, len(m.changes) + 1):
            c = m.changes[i]
            keys += [c.spawner_keys[j] for j in range(1, len(c.spawner_keys) + 1)]
            assert c.original_uid and c.replacement_uid and c.replacement_index is not None
        check(m.tool == "1.2.0" and not (m.tool < "1.1.0") and m.stage_lua == "1.1.0" and m.stage_sha256 == hashlib.sha256(s1).hexdigest(),
              "manifest: tool 1.2.0 (18 warns only below 1.1.0), stage_lua 1.1.0, sha256 of this .stage")
        check(sorted(keys) == sorted(["FF06CCC2A9AC1EA2", "9C3139C7FFED7137", "FA5FB32C7AAB4C4A", "F93E9AE445CCEF41", "DAFCA25C58FD387F"]),
              "manifest names the 5 changed spawners, one key per change")
    except ImportError:
        print("SKIP manifest Lua parse (pip install lupa)")

# 4. the log checker on the real DEV4 log
rc, out = run(os.path.join(HERE, "stage_check_log.py"), LOG)
check(rc == 0 and "CECB812E81FB7301" in out and "=> NO SPAWN" in out and "spawns 0" in out,
      "real DEV4 log: CECB812E81FB7301 was listed (zone loaded) on every Ardolis load and never spawned")
check("E6705A36656EB7B9 {'enm_pirate_robot_melee': 5}" in out, "real DEV4 log: the 'replacement' spawns were E6705A36656EB7B9's own brawlers")
syn = os.path.join(tempfile.mkdtemp(), "syn.log")
P = "[script] [rando]\t"
open(syn, "w").write("\n".join([
    P + "RANDO-STAGE\tSTAGE CHANGE 1: z Zone Script Vars +1 (entry 10): 8416CF7558A4694D #14 (enm_pirate_robot_shooter) -> 92C793D47A4657B6 #25 (enm_pirate_robot_melee) | p | spawners FF06CCC2A9AC1EA2",
    P + "RANDO-STAGE\tSTAGE CHANGE 2: z Zone Script Vars +2 (entry 998): 8416CF7558A4694D #14 (enm_pirate_robot_shooter) -> C37DB04A5A1F0972 #28 (enm_pirate_bladeball) | p | spawners 9C3139C7FFED7137",
    P + "RANDO-STAGE\tSTAGE CHANGE 3: z Zone Script Vars +3 (entry 228): 8416CF7558A4694D #14 (enm_pirate_robot_shooter) -> 92C793D47A4657B6 #25 (enm_pirate_robot_melee) | p | spawners F93E9AE445CCEF41",
    P + "RANDO-DISCOVER\tPlanetChangedEvent\tNewPlanetName=Ardolis",
    P + "RANDO-STAGE\tSTAGE VARIABLE factory FF06CCC2A9AC1EA2: holds 92C793D47A4657B6 (enm_pirate_robot_melee) = the .stage value - the patched zone z IS loaded",
    P + "RANDO-STAGE\tSTAGE VARIABLE factory 9C3139C7FFED7137: holds C37DB04A5A1F0972 (enm_pirate_bladeball) = the .stage value - the patched zone z IS loaded",
    P + "RANDO-ENEMIES\tSPAWN 500 | ardolis | M @ C | factory Templates FF06CCC2A9AC1EA2 | original enm_pirate_robot_melee | selected - | spawned enm_pirate_robot_melee (swarmer) | NOT CHANGED: .stage mode",
    P + "RANDO-SHOP\tVENDOR-EVIDENCE\tDialogStartedEvent ComponentId=1 SenderHandle=500 SoundEventId=1 SoundEventName=PIR2_ENM_GEN_MELEEATTACK_006 X=1",
    P + "RANDO-STAGE\tSTAGE DEATH 500: enm_pirate_robot_melee (spawner FF06CCC2A9AC1EA2) died 12 s after it spawned",
    P + "RANDO-ENEMIES\tSPAWN 501 | ardolis | M @ C | factory Templates 9C3139C7FFED7137 | original enm_pirate_bladeball | selected - | spawned enm_pirate_robot_shooter (ground) | NOT CHANGED: .stage mode",
    ""]))
rc, out = run(os.path.join(HERE, "stage_check_log.py"), syn)
blocks = out.split("\nCHANGE ")
check("=> WORKED" in blocks[1] and "died" in blocks[1] and "MELEEATTACK" in blocks[1], "log checker: replacement spawned, attacked and died = WORKED")
check("=> ORIGINAL SPAWNED" in blocks[2], "log checker: the original kind from a changed spawner = ORIGINAL SPAWNED")
check("NOT REACHED" in blocks[3], "log checker: a changed spawner never listed = NOT REACHED")

print("FAILURES", fails)
sys.exit(1 if fails else 0)
