# .stage Enemy Randomizer: why the Ardolis brawler never appeared, and a 5-spawner build that avoids the cause

Inputs: your `rivet.log` (v0.76-DEV4, stage tool 1.1.0 installed), the installed `RandoEnemies.stage`, the original zone
`AE530D22FE113E2B.zone.orig` (sha256 `d40540ed…e016`, the zone your game ships), the root-cause pack, and the
`16`/`18` Lua code of v0.76-DEV4. Nothing was installed, and the game folder and saves were not touched.

## 1. Root cause

**The patched spawner `CECB812E81FB7301` never spawned anything.** It was listed and held the brawler on every Ardolis
load, but the game produced no actor from it. Every "REPLACEMENT SPAWNED" line in the log came from a different
spawner, `E6705A36656EB7B9`. That spawner places brawlers there in the unmodified game, and `18_rando_stage_enemies.lua`
counted it only because its variable holds the same uid.

**Why the patched spawner does nothing:** a `SunsetSpawnerFactory` places each enemy at the actors in its `Locations`
plug. `CECB812E81FB7301` has one spawn point, and that point is an **anim clue made for shooters**:
`animclue_pirate_shooter_group_stand_conversation_idle_02.actor`. A brawler template on a shooter clue gave no spawn on
3 of 3 loads. The same spawner and clue with a shooter template spawned on 3 of 3 loads in the tool 1.0.1 session.

| | Status |
|---|---|
| No spawn from `CECB812E81FB7301` with the brawler template | **observed** (0 of 3 loads) |
| Spawns with the shooter template | **observed** (3 of 3 loads in the 1.0.1 session) |
| The only byte difference between those two zones | Script Vars #153 index 15 → 25, which selects the template |
| The anim clue is why the game refuses | **inferred**: the game writes no log line when it refuses. Sections 2c-2d give the evidence |

## 2. Evidence

**a. The log: the patched spawner was loaded but never spawned**

| Log line(s) | What it shows |
|---|---|
| 85 | `STAGE CHANGE 1 … spawners CECB812E81FB7301`: the only key in the manifest |
| 461-463, 626-628, 812-814, 827-829 | `STAGE REFERENCE/VARIABLE factory CECB812E81FB7301: holds 92C793D47A4657B6 … IS loaded`, uid and index AGREE, on every load |
| (whole log) | **0** `SPAWN … factory Templates CECB812E81FB7301` lines. A factory spawn always carries the factory's own handle (`V.on_spawn_seen`) |
| 450, 471, 592, 618, 832 | Every `STAGE SPAWN` says `factory E6705A36656EB7B9` and **lacks** `(the patched spawner)` |
| 577, 749, 865 | `STAGE SPAWNER E6705A36656EB7B9 … a spawner whose variable holds the replacement uid`. This is the fallback branch, not `the spawner the .stage changed` |

The fallback is in 18: `local c = (key and idx.keys[key]) or (uid and idx.rep[uid] and idx.rep[uid][1])`. Any spawner
whose variable holds a replacement uid is counted, including spawners the patch did not touch.

**b. The zone: where each spawner puts its enemies** (`verification/ardolis_factories_and_spawn_points.txt`)

| | CECB812E81FB7301 (patched) | E6705A36656EB7B9 (unmodified) |
|---|---|---|
| Template | shooter #15 → brawler #25 | brawler #25 |
| Count plug `90D607B0` | 1.0 | **2.0** |
| Locations | `animclue_pirate_shooter_group_stand_conversation_idle_02` | `animclue_pirate_melee_group_stand_conversation_idle_01`, `…melee_group_hipstand_conversation_idle_01` |
| Combat / idle / defensive volumes | `DAFFFA74…` / `B930D7C2…` / `D47E724D…` | the same three: **same encounter** |

The sibling in the same encounter spawned on time on every load, so the encounter did start. Only the patched spawner
stayed silent.

**c. The original zone: anim clues always match their template's kind.** All 28 factory spawn points that are anim
clues hold a template of the clue's own kind: shooter→`animclue_pirate_shooter_*`, melee→`…pirate_melee_*`,
shielded→`…pirate_shielded_*`, crab→`…toxic_crab_*`. There are 0 exceptions, and the game itself never puts one kind on
another kind's clue.

**d. DEV3's runtime swaps on Ardolis show the same split** (`outcomes.txt`):

| Spawn point type | Swaps that spawned the replacement | Spawners |
|---|---|---|
| StaticVolume or external | **6 of 6** | F3D033F9, FF06CCC2, FE80D89C, F4A34D9C, F607A5D7, FA5FB32C |
| Anim clue | **0 of 6** | CECB812E, B65A076E, 957CF01B, 95B4E80A, C3BEFB4C, E4F90C0D: all spawned the original |

The root-cause report blamed the DEV3 anim-clue failures on late writes. This split, plus the `.stage` result with no
timing involved, points to the spawn point.

## 3. Your ten questions

1. **Was a melee actor created by the patched spawner?** No. No actor from `CECB812E81FB7301` appears on any load. The
   "spawn callbacks" are real actors, but from `E6705A36656EB7B9`.
2-6. **Init, activation, transform, placement, despawn?** These don't apply: the patched spawner created nothing. The
   log cannot tell a silent refusal from an actor destroyed before `SpawnerSpawnEvent`. The fix is the same either way.
   This is the one point the evidence leaves open.
7. **Does the melee template need extra data?** No. The template works: record 25 spawns brawlers from E6705A36 on every
   load. Its prius differs from the shooter's (10 vs 6), but that is not the problem. The spawn point is.
8. **Why two spawn events?** E6705A36 is set to spawn 2 (count plug = 2.0). That gives 2 + 2 spawns on the first two
   loads, and 1 at `CHK_ARD_START`. These are normal game spawns, not duplicates and not checkpoint artefacts.
9. **"still there 2" vs "reported alive 0"?** These don't conflict.
   - "still there" = watched actors with no death or gone event.
   - "alive" is reported only after 45 s **and** 6 other bot deaths. The level reported `deaths seen 0` (lines 539,
     744, 859), so it can never trigger.
   - The two watched actors were E6705A36's brawlers, and they were active: barks `PIR2_ENM_GEN_MELEEATTACK_006` (line
     497) and `PIR2_ENM_GEN_ENGAGED_001` (line 736).
10. **Is the actor invisible or inactive?** There is no actor to be invisible.

## 4. The fix (smallest reliable change)

**Rule added: a spawner may only be swapped when every spawn point can host the replacement kind.**

| Spawn point | Decision |
|---|---|
| Local, not an anim clue (StaticVolume) | allowed |
| Actor of another zone | allowed, flagged "external" (its type can't be read from this zone) |
| Anim clue of the replacement's own kind | allowed |
| Anim clue of another kind | refused |
| Group variable | refused |

Every 1.1.0 rule is kept: uid + index together, single-owner Templates variable, C1 consistency, only reference bytes
change. Two more rules were added: the replacement must be a template some factory in the zone really uses, and it must
still be used by at least one unchanged factory afterwards.

`CECB812E81FB7301` goes back to the game's own shooter. **The UID was not wrong; the spawner was the wrong one to swap.**

**The new .stage: 5 spawners, all in `ard_firstvisit_gp.zone`:**

| # | Spawner | Change | Count | Spawn point | Pair evidence |
|---|---|---|---|---|---|
| 1 | FF06CCC2A9AC1EA2 | shooter → brawler | 1 | StaticVolume | tier A; DEV3 SUCCESS on this exact spawner |
| 2 | 9C3139C7FFED7137 | shooter → bladeball | 1 | StaticVolume | tier A |
| 3 | FA5FB32C7AAB4C4A | puffoid → crab | 3 | external | DEV3 SUCCESS on this exact spawner |
| 4 | F93E9AE445CCEF41 | shooter → brawler | 5 | external | tier A |
| 5 | DAFCA25C58FD387F | puffoid → crab | 4 | external | worked at 3 other Ardolis spawners |

- **Expected to work:** #1-#2 (volume) are the high-confidence set. #3 has worked before on this exact spawner.
- **Tests the external rule:** #4-#5.

**Left out, with the reason:**

| Spawners | Reason |
|---|---|
| All 28 anim-clue factories | wrong-kind clue |
| F3D033F9, FE80D89C, F4A34D9C, F607A5D7, 88259456, B0683892 | StaticVolume, but their Templates variable is shared with a second script node. Tool 1.1.0 refuses that, and this build keeps the refusal |
| 86685D80 | its bladeball template would lose its last unchanged user |

The shared-variable spawners are the obvious next batch: DEV3 changed them at runtime and they spawned. But that changes
a rule, so it was not done here.

## 5. Files

| File | What it is |
|---|---|
| `game/mods/RandoEnemies.stage` | **replaces** your current one. sha256 `3c4d501c…9565`. One zone, 45 bytes changed in 5 Script Vars entries |
| `game/scripts/18_rando_stage_manifest.lua` | **replaces** your current one. Names the 5 spawners. Same format as tool 1.1.0 (tool "1.2.0", stage_lua "1.1.0"), so your installed 16 and 18 need no change |
| `tools/stage_multi.py` | builder (`build` / `check` / `list`). Its uid+index writer reproduces tool 1.1.0's patched zone **byte for byte**. New: spawn-point rule, multi-change, live-template rule |
| `tools/stage_check_log.py` | reads a rivet.log and gives a verdict per changed spawner: WORKED / ORIGINAL SPAWNED / NO SPAWN / NOT REACHED, with each actor's barks and death. It ignores 18's uid fallback |
| `tools/test_stage_multi.py` | 30 checks against the real zone, the real 1.1.0 .stage and your real log |
| `verification/` | STATIC_VERIFICATION.txt (byte diff per entry), check outputs, test output, factory list, JSON manifest |

**Install** (two copies, no rivet.toml change: `mods/RandoEnemies.stage` is already listed): copy `game/mods/RandoEnemies.stage`
over `<game>\mods\RandoEnemies.stage`, and `game/scripts/18_rando_stage_manifest.lua` over
`<game>\scripts\18_rando_stage_manifest.lua`. Do not run tool 1.1.0's `install`/`verify` on this build: they expect a
single change. Use `python -I tools/stage_multi.py check --orig <backup>\AE530D22FE113E2B.zone.orig --stage <game>\mods\RandoEnemies.stage`.

**Uninstall:** put back your previous two files, or delete both.

## 6. Verification

**Static (done here):** 30/30 tests pass (`verification/test_output.txt`).

- The original zone is the game's (sha256); C1 302/302 holds before and after.
- The writer equals tool 1.1.0's bytes.
- The old 1.1.0 .stage **fails** the new check for exactly the anim-clue reason.
- Every refusal case is covered: anim clue, shared variable, group, cross-faction, unproven pair, foreign uid,
  last-template.
- The build is deterministic and never overwrites.
- `CECB812E81FB7301` and `E6705A36656EB7B9` are byte-identical to the game.
- The manifest parses in Lua 5.4 with the 5 keys.
- The log checker turns your DEV4 log into `CECB812E81FB7301 … NO SPAWN` on every load and names E6705A36 as the source
  of the "replacement" spawns.

**In game: nothing verified.** This build has not run.

## 7. What one play-through will show

Play Ardolis' first visit **past the landing**. Your DEV4 log stopped at the landing encounter, and none of these 5
spawners is there. FF06CCC2, 9C3139C7 and FA5FB32C all spawned on Ardolis in DEV3, in this same zone, after the landing.

Then run `python -I tools/stage_check_log.py rivet.log`. Each change gets one verdict:

| Verdict | Meaning |
|---|---|
| WORKED | works |
| NO SPAWN | the spawn-point rule missed a case |
| NOT REACHED | not played yet |

One run tests the volume rule (#1-#2) and the external rule (#3-#5) together.
