#!/usr/bin/env python3
"""stage_enemies.py - the .stage Enemy Randomizer companion (Rift Apart Randomizer v0.76-DEV4, Phase A).

Reads the game's own files (toc, dag, archives) - never writes to them - and builds a .stage that rivet_hook (or
Overstrike) loads in place of one level zone. Phase A changes ONE template reference of ONE spawner, and only when
your game files show the evidence for it.

  python stage_enemies.py selftest
  python stage_enemies.py levels   --game "C:/.../Ratchet & Clank - Rift Apart" --filter zurkon
  python stage_enemies.py probe    --game GAME --planet zurkon --log rivet.log [--log more.log] [--out probe_out]
  python stage_enemies.py poc      --game GAME --probe probe_out/probe.json [--pick N] [--out poc_out]
  python stage_enemies.py verify   --game GAME --stage poc_out/RandoEnemies.stage
  python stage_enemies.py install  --game GAME --build poc_out
  python stage_enemies.py uninstall --game GAME

Every command prints what it did and why; anything it cannot prove from the files it refuses (exit code 2).
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import re
import shutil
import struct
import sys
from math import gcd
from typing import Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import knowledge as K  # noqa: E402
import rcra  # noqa: E402

TOOL_VERSION = "1.0.1"   # 1.0.1: spawner_keys = only the spawners logged holding the original uid (was: every same-kind spawner)
KIT_RELEASE = "v0.76-DEV4"
STAGE_NAME = "RandoEnemies.stage"
MANIFEST_LUA = "18_rando_stage_manifest.lua"
STAGE_MOD_PATH = "mods/" + STAGE_NAME
EXIT_REFUSED = 2

ZONE_SCRIPT_VARS = rcra.SEC["Zone Script Vars"]
ZONE_ACTORS = rcra.SEC["Zone Actors"]
ZONE_ASSET_REFS = rcra.SEC["Zone Asset References"]


def die(msg: str) -> None:
    print("REFUSED: " + msg)
    sys.exit(EXIT_REFUSED)


def default_scripts_dir() -> str:
    return os.path.normpath(os.path.join(HERE, "..", "..", "scripts"))


def load_knowledge(scripts_dir: str, logs: List[str]) -> K.Knowledge:
    k = K.Knowledge()
    K.load_scripts(k, scripts_dir)
    for p in logs or []:
        K.load_log(k, p)
    return k


def open_game(game: str) -> Tuple[rcra.Toc, Optional[rcra.Dag]]:
    if not os.path.isfile(os.path.join(game, "toc")):
        die("no 'toc' file in %s (pass the folder that holds RiftApart.exe and toc)" % game)
    toc = rcra.Toc(game)
    dag = rcra.Dag(game) if os.path.isfile(os.path.join(game, "dag")) else None
    return toc, dag


def read_zone(toc: rcra.Toc, zone_id: int):
    e = toc.find(zone_id, 0)
    if e is None:
        e = toc.find(zone_id)
    if e is None:
        return None, None, None
    return e, toc.header(e), toc.read(e)


def section_at(dat: rcra.Dat1, abs_off: int) -> Tuple[Optional[int], int]:
    for tag in dat.order:
        s = dat.sections[tag]
        a = dat.base + s.offset
        if a <= abs_off < a + s.size:
            return tag, abs_off - a
    return None, abs_off - dat.base


def scan_aligned(raw: bytes, needles: Dict[bytes, tuple], step: int = 4) -> List[Tuple[int, bytes]]:
    """Every 8-byte value at a `step`-aligned offset that is a needle."""
    want = {struct.unpack("<Q", b)[0]: b for b in needles}
    hits = []
    n = len(raw) - 8
    for phase in range(0, 8, step):
        if phase > n:
            break
        cnt = (n - phase) // 8 + 1
        vals = struct.unpack_from("<%dQ" % cnt, raw, phase)
        hits += [(phase + 8 * k, want[v]) for k, v in enumerate(vals) if v in want]
    hits.sort()
    return hits


def find_all(raw: bytes, needle: bytes) -> List[int]:
    out, i = [], raw.find(needle)
    while i >= 0:
        out.append(i)
        i = raw.find(needle, i + 1)
    return out


def diff_positions(a: bytes, b: bytes) -> List[int]:
    """Offsets where two equal-length buffers differ (block compare first: zones are megabytes)."""
    out = []
    n = min(len(a), len(b))
    step = 4096
    for s in range(0, n, step):
        if a[s:s + step] != b[s:s + step]:
            out += [i for i in range(s, min(n, s + step)) if a[i] != b[i]]
    out += list(range(n, max(len(a), len(b))))
    return out


def hexdump(b: bytes) -> str:
    return " ".join("%02X" % x for x in b)


# ======================================================================================================================
# levels
# ======================================================================================================================
def cmd_levels(a) -> None:
    toc, dag = open_game(a.game)
    if dag is None:
        die("no 'dag' file: the zone list comes from it")
    f = (a.filter or "").lower()
    rows = [(dag.names[i], dag.type_name(i)) for i in range(dag.count)
            if dag.type_name(i) in ("level", "zone") and f in dag.names[i].lower()]
    for n, t in sorted(rows):
        e = toc.find(rcra.crc64_path(n), 0)
        print("%-5s %-90s %s" % (t, n, ("%s %d bytes" % (rcra.hex64(e.asset_id), e.size)) if e else "not in toc span 0"))
    print("%d level/zone assets match '%s'" % (len(rows), f))


# ======================================================================================================================
# probe (read-only)
# ======================================================================================================================
def cmd_probe(a) -> None:
    k = load_knowledge(a.scripts or default_scripts_dir(), a.log)
    for n in k.notes:
        print("knowledge: " + n)
    toc, dag = open_game(a.game)
    if dag is None:
        die("no 'dag' file: the zone list comes from it")
    filters = [p.lower() for p in a.planet]
    zones = sorted({dag.names[i] for i in range(dag.count)
                    if dag.type_name(i) == "zone" and any(f in dag.names[i].lower() for f in filters)})
    if a.limit:
        zones = zones[:a.limit]
    if not zones:
        die("no zone asset name contains %s - run 'levels' to see the names" % ", ".join(filters))
    print("probing %d zone(s) for %s ..." % (len(zones), ", ".join(filters)))

    needles: Dict[bytes, tuple] = {}
    for uid, t in k.templates.items():
        needles[rcra.uid_bytes(uid)] = ("template", uid, t.name)
    for key, s in k.spawners.items():
        needles.setdefault(rcra.uid_bytes(key), ("spawner", key, s.adapter))
    for name, p in k.actor_paths.items():
        needles.setdefault(struct.pack("<Q", rcra.crc64_path(p)), ("actor_asset", rcra.hex64(rcra.crc64_path(p)), name))

    out_dir = a.out
    os.makedirs(out_dir, exist_ok=True)
    report = {"tool": TOOL_VERSION, "kit": KIT_RELEASE, "game": os.path.abspath(a.game), "filters": filters,
              "logs": [os.path.abspath(p) for p in a.log], "scripts": os.path.abspath(a.scripts or default_scripts_dir()),
              "knowledge": k.notes, "zones": [], "errors": []}
    totals: Dict[str, Dict[str, int]] = {}
    lines = []
    for zi, zname in enumerate(zones):
        zid = rcra.crc64_path(zname)
        try:
            e, header, raw = read_zone(toc, zid)
        except rcra.FormatError as ex:
            report["errors"].append({"zone": zname, "error": str(ex)})
            print("  [%d/%d] %s: %s" % (zi + 1, len(zones), zname, ex))
            continue
        if e is None:
            report["errors"].append({"zone": zname, "error": "not in toc"})
            continue
        z = {"zone": zname, "zone_id": rcra.hex64(zid), "span": e.span, "size": len(raw), "sha256": rcra.sha256(raw),
             "header": header.hex() if header else None, "dat1_at": rcra.find_dat1(raw), "sections": [], "hits": []}
        if header:
            schema, sizes = rcra.header_block_sizes(header)
            z["header_schema"] = "%08X" % schema
            z["header_sizes"] = sizes
            z["rivet_hook_ok"] = sum(sizes) == len(raw)
        dat = None
        if z["dat1_at"] >= 0:
            try:
                dat = rcra.Dat1.parse(raw, z["dat1_at"])
                z["dat1_type"] = "%08X" % dat.type_id
                z["sections"] = [{"tag": "%08X" % t, "name": rcra.section_name(t), "offset": dat.sections[t].offset,
                                  "size": dat.sections[t].size} for t in dat.order]
            except rcra.FormatError as ex:
                z["dat1_error"] = str(ex)
        for off, b in scan_aligned(raw, needles):
            kind, ident, label = needles[b]
            tag, rel = section_at(dat, off) if dat else (None, off)
            sname = rcra.section_name(tag) if tag is not None else "(outside DAT1 sections)"
            lo = max(0, off - 0x20)
            z["hits"].append({"kind": kind, "id": ident, "label": label, "section": sname, "rel": rel, "abs": off,
                              "context_at": lo, "context": hexdump(raw[lo:off + 0x40])})
            totals.setdefault(kind, {}).setdefault(sname, 0)
            totals[kind][sname] += 1
        # stride evidence for the template references in Script Vars
        rels = sorted({h["rel"] for h in z["hits"] if h["kind"] == "template" and h["section"] == "Zone Script Vars"})
        g = 0
        for x, y in zip(rels, rels[1:]):
            g = gcd(g, y - x)
        z["script_vars_template_refs"] = len(rels)
        z["script_vars_stride_gcd"] = g
        report["zones"].append(z)
        nh = len(z["hits"])
        print("  [%d/%d] %-70s %8d bytes, %3d known value(s)%s" % (zi + 1, len(zones), zname, len(raw), nh,
              "" if z.get("rivet_hook_ok", True) else "  (header sizes != data: rivet_hook could not load a patched copy)"))
    toc.close()
    report["totals"] = totals
    with open(os.path.join(out_dir, "probe.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1)

    # human report
    lines.append("STAGE ENEMY PROBE (%s, tool %s) - %s" % (KIT_RELEASE, TOOL_VERSION, ", ".join(filters)))
    lines.append("zones probed: %d, errors: %d" % (len(report["zones"]), len(report["errors"])))
    lines.append("")
    lines.append("WHERE THE KNOWN VALUES ARE (4-byte aligned 64-bit matches)")
    for kind in ("template", "spawner", "actor_asset"):
        row = totals.get(kind, {})
        lines.append("  %-12s %s" % (kind, ", ".join("%s: %d" % (s, n) for s, n in sorted(row.items(), key=lambda x: -x[1])) or "none"))
    lines.append("")
    for z in report["zones"]:
        if not z["hits"]:
            continue
        lines.append("ZONE %s (%s, %d bytes, DAT1 at %d, sections %d, rivet_hook-loadable: %s)" % (
            z["zone"], z["zone_id"], z["size"], z["dat1_at"], len(z["sections"]), z.get("rivet_hook_ok")))
        if z["script_vars_template_refs"]:
            lines.append("  Script Vars: %d template reference(s), offsets gcd %d" % (z["script_vars_template_refs"], z["script_vars_stride_gcd"]))
        for h in z["hits"][:60]:
            lines.append("  %-11s %-18s %-34s %-24s +%-7d" % (h["kind"], h["id"], K.short(h["label"]), h["section"], h["rel"]))
        if len(z["hits"]) > 60:
            lines.append("  ... %d more in probe.json" % (len(z["hits"]) - 60))
    verdict = verdict_text(report)
    lines.append("")
    lines += verdict
    with open(os.path.join(out_dir, "probe_report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(verdict))
    print("written: %s, %s" % (os.path.join(out_dir, "probe.json"), os.path.join(out_dir, "probe_report.txt")))


def verdict_text(report) -> List[str]:
    t = report.get("totals", {}).get("template", {})
    sv = t.get("Zone Script Vars", 0)
    za = t.get("Zone Actors", 0)
    out = ["VERDICT"]
    if sv and za:
        out.append("  Template uids appear in Zone Script Vars (%d) and Zone Actors (%d): spawner variables reference their" % (sv, za))
        out.append("  template actor by uid ON DISK. A single-spawner .stage patch is possible: run 'poc'.")
    elif sv:
        out.append("  Template uids appear in Zone Script Vars (%d) but not in Zone Actors: the variable references are on disk," % sv)
        out.append("  but where the template actors are placed is not proven. 'poc' will only accept a replacement found in the same zone.")
    elif t:
        out.append("  Template uids appear only in %s - not in Zone Script Vars. Send probe_report.txt and probe.json:" % ", ".join(t))
        out.append("  the spawner variable format differs from the runtime one and must be decoded before any patch.")
    else:
        out.append("  No known template uid appears in these zones (4-byte aligned). Either the planet filter matched the wrong")
        out.append("  zones, or uids are not stored as plain 64-bit values on disk. Send probe_report.txt; nothing can be patched yet.")
    return out


# ======================================================================================================================
# poc: choose one spawner reference and build the .stage
# ======================================================================================================================
def candidates(report, k: K.Knowledge, allow_same_faction: bool, prefer: List[str]) -> List[dict]:
    enemy = k.enemy_templates()
    out = []
    for z in report["zones"]:
        hits = z["hits"]
        by_uid: Dict[str, List[dict]] = {}
        for h in hits:
            if h["kind"] == "template":
                by_uid.setdefault(h["id"], []).append(h)
        # a spawner key sits twice in its Script Actions record (probe: +N and +N+8): one entry per key, probe order
        keys_here = list(dict.fromkeys(h["id"] for h in hits if h["kind"] == "spawner"))
        assets_here = {h["label"] for h in hits if h["kind"] == "actor_asset" and h["section"] == "Zone Asset References"}
        for uid_a, ha in by_uid.items():
            ta = enemy.get(uid_a)
            if not ta:
                continue
            vars_a = [h for h in ha if h["section"] == "Zone Script Vars"]
            if not vars_a:
                continue
            fa = ta.family or k.family_of(ta.name)
            for uid_b, hb in by_uid.items():
                tb = enemy.get(uid_b)
                if not tb or uid_b == uid_a or K.short(tb.name) == K.short(ta.name):
                    continue
                fb = tb.family or k.family_of(tb.name)
                if K.FAMILY_GROUP.get(fa) != K.FAMILY_GROUP.get(fb):
                    continue
                placed = [h for h in hb if h["section"] != "Zone Script Vars"]
                if not placed:
                    continue  # the replacement's template actor is not shown to be in this zone
                st = k.pair_status(ta, tb)
                if st and st[0] == "bad":
                    continue
                tier = "A" if (st and st[0] == "ok") else "B"
                if tier == "B" and not (allow_same_faction and K.faction(ta.name) == K.faction(tb.name)):
                    continue
                known_keys = [key for key in keys_here if key in k.spawners and
                              any(K.short(o) == K.short(ta.name) for o in k.spawners[key].originals)]
                # tool 1.0.1: the spawners whose variable your logs SAW holding A's uid. Only these are "the spawner the
                # .stage changed" for 18_rando_stage_enemies.lua; the other same-kind spawners of the zone may use
                # another template actor of the same kind (unchanged) and stay out of spawner_keys.
                held_keys = [key for key in keys_here if key in k.spawners and uid_a in k.spawners[key].uids]
                enc_keys = held_keys or known_keys
                for hv in vars_a:
                    score = (10 if tier == "A" else 0)
                    score += 3 if any(h["section"] == "Zone Actors" for h in placed) else 0
                    score += 2 if known_keys else 0
                    score += 2 if len(vars_a) == 1 else 0
                    score += 1 if tb.name in assets_here else 0
                    score += 1 if z.get("rivet_hook_ok") else -100
                    score += 1 if any(p in z["zone"].lower() for p in prefer) else 0
                    out.append({
                        "score": score, "tier": tier, "zone": z["zone"], "zone_id": z["zone_id"], "zone_sha256": z["sha256"],
                        "abs": hv["abs"], "rel": hv["rel"], "section": hv["section"],
                        "original_uid": uid_a, "original": ta.name, "original_family": fa,
                        "replacement_uid": uid_b, "replacement": tb.name, "replacement_family": fb,
                        "pair": K.pair_key("factory", ta.name, fa, tb.name, fb),
                        "evidence": st[1] if st else "same faction (%s), not combat-verified" % K.faction(ta.name),
                        "replacement_placed_in": sorted({h["section"] for h in placed}),
                        "original_refs_in_script_vars": len(vars_a),
                        "replacement_refs_in_script_vars": len([h for h in hb if h["section"] == "Zone Script Vars"]),
                        "spawner_keys": held_keys,
                        "spawner_keys_evidence": ("rivet.log: the variable of each held the original uid %s (SPAWN line "
                                                  "followed by its 'learned template ... (spawn)' line)" % uid_a) if held_keys
                                                 else "none: no logged spawn of this zone shows the original uid in its variable",
                        "same_kind_spawner_keys": known_keys,
                        "encounters": sorted({e for key in enc_keys for e in k.spawners[key].encounters}),
                        "encounters_of": "the spawner(s) in spawner_keys" if held_keys else
                                         ("every logged spawner of this zone that spawned %s (the changed one is not "
                                          "identified)" % K.short(ta.name)) if known_keys else "none",
                        "rivet_hook_ok": z.get("rivet_hook_ok"),
                    })
    out.sort(key=lambda c: (-c["score"], c["zone"], c["abs"], c["replacement_uid"]))
    return out


def lua_str(s) -> str:
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def manifest_lua(m: dict) -> str:
    L = ["-- generated by tools/stage_enemies/stage_enemies.py %s (%s). DATA, not a script to edit." % (TOOL_VERSION, KIT_RELEASE),
         "-- It tells 18_rando_stage_enemies.lua which spawners the installed %s changed on disk." % STAGE_MOD_PATH,
         "-- Remove both with: python tools/stage_enemies/stage_enemies.py uninstall --game <game folder>",
         "RANDO_STAGE_ENEMIES = {",
         "  format = 1, tool = %s, kit = %s, label = %s," % (lua_str(TOOL_VERSION), lua_str(KIT_RELEASE), lua_str(m["label"])),
         "  stage_file = %s, stage_sha256 = %s," % (lua_str(STAGE_MOD_PATH), lua_str(m["stage_sha256"])),
         "  changes = {"]
    for c in m["changes"]:
        L.append("    { zone = %s, zone_id = %s, section = %s, offset = %d," % (
            lua_str(c["zone"]), lua_str(c["zone_id"]), lua_str(c["section"]), c["rel"]))
        L.append("      original_uid = %s, original = %s, original_family = %s," % (
            lua_str(c["original_uid"]), lua_str(c["original"]), lua_str(c["original_family"])))
        L.append("      replacement_uid = %s, replacement = %s, replacement_family = %s," % (
            lua_str(c["replacement_uid"]), lua_str(c["replacement"]), lua_str(c["replacement_family"])))
        L.append("      original_refs = %d, replacement_refs = %d," % (
            c["original_refs_in_script_vars"], c["replacement_refs_in_script_vars"]))
        L.append("      pair = %s, spawner_keys = { %s } }," % (
            lua_str(c["pair"]), ", ".join(lua_str(x) for x in c["spawner_keys"])))
    L += ["  },", "}", ""]
    return "\n".join(L)


def cmd_poc(a) -> None:
    with open(a.probe, "r", encoding="utf-8") as f:
        report = json.load(f)
    logs = a.log or [p for p in report.get("logs", []) if os.path.isfile(p)]
    k = load_knowledge(a.scripts or report.get("scripts") or default_scripts_dir(), logs)
    cands = candidates(report, k, a.allow_same_faction, [p.lower() for p in (a.prefer or [])])
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "poc_candidates.json"), "w", encoding="utf-8") as f:
        json.dump(cands[:200], f, indent=1)
    if not cands:
        die("no spawner reference in the probed zones satisfies the Phase A rules (combat-verified pair, same movement "
            "group, replacement template placed in the same zone, rivet_hook-loadable zone). See probe_report.txt; "
            "--allow-same-faction widens to unverified same-faction pairs.")
    print("Phase A candidates (best first):")
    for i, c in enumerate(cands[:15]):
        print("  [%d] score %2d tier %s  %s +%d  %s -> %s  (%s)%s%s" % (
            i, c["score"], c["tier"], K.short(c["zone"]), c["rel"], K.short(c["original"]), K.short(c["replacement"]),
            c["evidence"][:60], ("  spawner " + ",".join(c["spawner_keys"])) if c["spawner_keys"] else "",
            ("  (%d same-kind spawner(s) in the zone)" % len(c["same_kind_spawner_keys"])) if c["same_kind_spawner_keys"] else ""))
    if a.pick >= len(cands):
        die("--pick %d: only %d candidate(s)" % (a.pick, len(cands)))
    c = cands[a.pick]
    if c["score"] < 0:
        die("the chosen candidate's zone cannot be loaded by rivet_hook as a patched copy (header sizes != data)")

    toc, _ = open_game(a.game)
    zid = int(c["zone_id"], 16)
    e, header, raw = read_zone(toc, zid)
    toc.close()
    if e is None or header is None:
        die("zone %s is not in the toc (or has no asset header)" % c["zone"])
    if rcra.sha256(raw) != c["zone_sha256"]:
        die("zone %s changed since the probe (game update?) - probe again" % c["zone"])
    ob, nb = rcra.uid_bytes(c["original_uid"]), rcra.uid_bytes(c["replacement_uid"])
    if raw[c["abs"]:c["abs"] + 8] != ob:
        die("the bytes at %d are not %s" % (c["abs"], c["original_uid"]))
    if not find_all(raw, nb):
        die("replacement uid %s is not in the zone" % c["replacement_uid"])
    schema, sizes = rcra.header_block_sizes(header)
    if sum(sizes) != len(raw):
        die("asset header block sizes %s add up to %d, the zone has %d bytes: rivet_hook would refuse it" % (sizes, sum(sizes), len(raw)))
    dat0 = rcra.Dat1.parse(raw, rcra.find_dat1(raw))
    new = bytearray(raw)
    new[c["abs"]:c["abs"] + 8] = nb
    new = bytes(new)
    dat1 = rcra.Dat1.parse(new, dat0.base)
    if [(s.tag, s.offset, s.size) for s in dat0.sections.values()] != [(s.tag, s.offset, s.size) for s in dat1.sections.values()]:
        die("internal: the section table changed")
    diff = diff_positions(raw, new)
    if not diff or diff[0] < c["abs"] or diff[-1] >= c["abs"] + 8 or len(new) != len(raw):
        die("internal: the patch touched more than the 8 bytes of one reference")

    # backup of the original (as the .stage would hold it) + the build
    bdir = os.path.join(a.out, "backup")
    os.makedirs(bdir, exist_ok=True)
    orig_blob = header + raw
    bpath = os.path.join(bdir, "%s.zone.orig" % c["zone_id"])
    with open(bpath, "wb") as f:
        f.write(orig_blob)
    with open(bpath + ".sha256", "w") as f:
        f.write("%s  %s\n" % (rcra.sha256(orig_blob), os.path.basename(bpath)))
    stage_path = os.path.join(a.out, STAGE_NAME)
    desc = "Phase A proof of concept: %s +%d (%s) %s -> %s" % (c["zone"], c["rel"], c["section"], K.short(c["original"]), K.short(c["replacement"]))
    rcra.write_stage(stage_path, "Rift Apart Randomizer - Enemy .stage (%s)" % KIT_RELEASE, "Rift Apart Randomizer", desc,
                     [rcra.StageEntry(0, zid, header, new, c["zone"])])
    with open(stage_path, "rb") as f:
        stage_sha = rcra.sha256(f.read())
    m = {"format": 1, "tool": TOOL_VERSION, "kit": KIT_RELEASE, "label": "Phase A single spawner", "stage_sha256": stage_sha,
         "changes": [dict(c, changed_bytes=len(diff), zone_sha256_original=c["zone_sha256"], zone_sha256_patched=rcra.sha256(new))]}
    with open(os.path.join(a.out, "stage_enemies_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=1)
    with open(os.path.join(a.out, MANIFEST_LUA), "w", encoding="utf-8") as f:
        f.write(manifest_lua(m))
    print("")
    print("BUILT %s (sha256 %s)" % (stage_path, stage_sha))
    print("  zone        %s (%s), %d bytes, header kept" % (c["zone"], c["zone_id"], len(raw)))
    print("  change      %s +%d: %s (%s) -> %s (%s), %d byte(s) differ" % (
        c["section"], c["rel"], c["original_uid"], K.short(c["original"]), c["replacement_uid"], K.short(c["replacement"]), len(diff)))
    print("  pair        %s [%s] %s" % (c["pair"], c["tier"], c["evidence"]))
    print("  spawner     %s" % ((", ".join(c["spawner_keys"]) + " - " + c["spawner_keys_evidence"]) if c["spawner_keys"]
                                 else "not identified in your logs (%s)" % c["spawner_keys_evidence"]))
    print("  test where  %s%s" % ("; ".join(c["encounters"]) or "the encounters of this zone (no spawner key of it in your logs)",
                                  (" [%s]" % c["encounters_of"]) if c["encounters"] else ""))
    print("  backup      %s" % bpath)
    # verify knows a template uid only from V.REG_BUILTIN and the --log files it is given: pass the same logs as poc used
    # (uids learned in your game, like this change's, are in no built-in table)
    print("next: python stage_enemies.py verify --game GAME --stage %s%s ; then install --build %s" % (
        stage_path, "".join(' --log "%s"' % p for p in logs), a.out))
    if logs:
        print("      keep a copy of %s: the game rewrites rivet.log on its next start, and verify needs these uids" % (
            ", ".join(logs)))


# ======================================================================================================================
# verify: the .stage against the game's originals and the other installed mods
# ======================================================================================================================
def toml_asset_paths(toml_text: str) -> Optional[List[str]]:
    m = re.search(r"^\[assets\][^\[]*?^\s*paths\s*=\s*\[(.*?)\]", toml_text, re.S | re.M)
    if not m:
        return None
    return re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1))


def mod_asset_ids(game: str, rel: str) -> Dict[int, str]:
    """Asset ids (span 0..255 dirs, hex names or hashed paths) a listed mod path provides."""
    p = os.path.join(game, rel)
    out: Dict[int, str] = {}

    def add(path_in_mod: str):
        parts = re.split(r"[\\/]", path_in_mod)
        for i, s in enumerate(parts):
            if s.isdigit() and int(s) <= 255:
                rest = "/".join(parts[i + 1:])
                if not rest:
                    return
                name = parts[-1]
                aid = int(name, 16) if re.fullmatch(r"[0-9A-Fa-f]{16}", name) else rcra.crc64_path(rest)
                out[aid] = path_in_mod
                return
    if os.path.isfile(p) and p.lower().endswith(".stage"):
        import zipfile
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n != "info.json" and not n.endswith("/"):
                    add(n)
    elif os.path.isdir(p):
        for root, _, files in os.walk(p):
            for fn in files:
                add(os.path.relpath(os.path.join(root, fn), p))
    return out


def cmd_verify(a) -> int:
    info, files = rcra.read_stage(a.stage)
    problems, notes = [], []
    if info.get("game") != rcra.STAGE_GAME_ID:
        problems.append("info.json game is %r, not RCRA" % info.get("game"))
    toc, dag = open_game(a.game)
    names = {}
    if dag:
        names = {dag.ids[i]: dag.names[i] for i in range(dag.count)}
    k = load_knowledge(a.scripts or default_scripts_dir(), a.log)
    uidname = {rcra.uid_bytes(u): t.name for u, t in k.templates.items()}
    ids = []
    for n, blob in sorted(files.items()):
        m = re.fullmatch(r"(\d+)/([0-9A-Fa-f]{16})", n)
        if not m:
            problems.append("%s: not 'span/16-hex-id'" % n)
            continue
        span, aid = int(m.group(1)), int(m.group(2), 16)
        ids.append(aid)
        e = toc.find(aid, span)
        if e is None:
            problems.append("%s: no such asset in the game's toc" % n)
            continue
        oh, oraw = toc.header(e), toc.read(e)
        h, raw = blob[:rcra.ASSET_HEADER_SIZE], blob[rcra.ASSET_HEADER_SIZE:]
        label = names.get(aid, rcra.hex64(aid))
        if h != oh:
            problems.append("%s: asset header differs from the game's" % label)
        if len(raw) != len(oraw):
            problems.append("%s: %d bytes, the game's has %d" % (label, len(raw), len(oraw)))
            continue
        _, sizes = rcra.header_block_sizes(h)
        if sum(sizes) != len(raw):
            problems.append("%s: header block sizes add to %d, data %d (rivet_hook rejects it)" % (label, sum(sizes), len(raw)))
        try:
            d0 = rcra.Dat1.parse(oraw, rcra.find_dat1(oraw))
            d1 = rcra.Dat1.parse(raw, d0.base)
            if [(s.tag, s.offset, s.size) for s in d0.sections.values()] != [(s.tag, s.offset, s.size) for s in d1.sections.values()]:
                problems.append("%s: DAT1 section table differs" % label)
        except rcra.FormatError as ex:
            problems.append("%s: DAT1: %s" % (label, ex))
            continue
        diff = diff_positions(oraw, raw)
        runs = []
        for i in diff:
            if runs and i <= runs[-1][1] + 8:
                runs[-1][1] = i
            else:
                runs.append([i, i])
        notes.append("%s: %d byte(s) differ in %d place(s)" % (label, len(diff), len(runs)))
        for s, e_ in runs:
            # the 8-byte reference that holds the whole change: one known template uid replaced by another
            best = None
            for start in range(max(0, e_ - 7), s + 1):
                ob, nb = oraw[start:start + 8], raw[start:start + 8]
                if ob in uidname and nb in uidname:
                    best = (start, ob, nb)
            tag, rel = section_at(d0, s)
            if best:
                st, ob, nb = best
                notes.append("    %s +%d: %s (%s) -> %s (%s)" % (rcra.section_name(tag), rel, rcra.hex64(struct.unpack("<Q", ob)[0]),
                             K.short(uidname[ob]), rcra.hex64(struct.unpack("<Q", nb)[0]), K.short(uidname[nb])))
            else:
                problems.append("%s: a change at %s +%d is not one known template uid replaced by another" % (label, rcra.section_name(tag), rel))
    toc.close()
    # rivet.toml
    tpath = os.path.join(a.game, "rivet.toml")
    if os.path.isfile(tpath):
        with open(tpath, "r", encoding="utf-8", errors="replace") as f:
            paths = toml_asset_paths(f.read())
        if paths is None:
            notes.append("rivet.toml: no [assets] paths list found")
        else:
            mine = [p for p in paths if p.replace("\\", "/").lower().endswith(STAGE_NAME.lower())]
            notes.append("rivet.toml [assets] paths: %s" % paths)
            if mine and paths.index(mine[0]) != len(paths) - 1:
                problems.append("%s is not the LAST [assets] path: a later mod would win over it" % mine[0])
            for p in paths:
                if p in mine:
                    continue
                other = mod_asset_ids(a.game, p)
                clash = [rcra.hex64(i) for i in ids if i in other]
                if clash:
                    problems.append("%s also replaces %s - the two mods cannot both change this zone" % (p, ", ".join(clash)))
    for n in notes:
        print(n)
    for p in problems:
        print("PROBLEM: " + p)
    print("VERIFY %s: %s" % (os.path.basename(a.stage), "OK" if not problems else "%d problem(s)" % len(problems)))
    return 0 if not problems else EXIT_REFUSED


# ======================================================================================================================
# install / uninstall
# ======================================================================================================================
def edit_toml_paths(game: str, add: bool) -> str:
    tpath = os.path.join(game, "rivet.toml")
    if not os.path.isfile(tpath):
        return "rivet.toml not found: add \"%s\" as the LAST entry of [assets] paths yourself" % STAGE_MOD_PATH
    with open(tpath, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    m = re.search(r"(^\[assets\][^\[]*?^\s*paths\s*=\s*\[)(.*?)(\])", text, re.S | re.M)
    if not m:
        return "rivet.toml has no [assets] paths list: add paths = [\"%s\"] under [assets] yourself" % STAGE_MOD_PATH
    items = re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(2))
    items = [p for p in items if p.replace("\\", "/").lower() != STAGE_MOD_PATH.lower()]
    if add:
        items.append(STAGE_MOD_PATH)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    n = 1
    while os.path.exists(tpath + ".bak-stage-" + stamp):        # never overwrite an earlier backup
        n += 1
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S") + "-%d" % n
    shutil.copy2(tpath, tpath + ".bak-stage-" + stamp)
    new = text[:m.start(2)] + ", ".join('"%s"' % p for p in items) + text[m.end(2):]
    with open(tpath, "w", encoding="utf-8") as f:
        f.write(new)
    return "rivet.toml [assets] paths = %s (backup rivet.toml.bak-stage-%s)" % (items, stamp)


def cmd_install(a) -> None:
    src_stage = os.path.join(a.build, STAGE_NAME)
    src_lua = os.path.join(a.build, MANIFEST_LUA)
    for p in (src_stage, src_lua):
        if not os.path.isfile(p):
            die("missing %s (run 'poc' first)" % p)
    sd = os.path.join(a.game, "scripts")
    if not os.path.isfile(os.path.join(sd, "18_rando_stage_enemies.lua")):
        die("%s has no 18_rando_stage_enemies.lua: install the v0.76-DEV4 scripts first (the Lua side must switch its "
            "runtime spawner writes off while the .stage is installed)" % sd)
    os.makedirs(os.path.join(a.game, "mods"), exist_ok=True)
    shutil.copy2(src_stage, os.path.join(a.game, "mods", STAGE_NAME))
    shutil.copy2(src_lua, os.path.join(sd, MANIFEST_LUA))
    print("copied %s -> mods/%s" % (src_stage, STAGE_NAME))
    print("copied %s -> scripts/%s" % (src_lua, MANIFEST_LUA))
    print(edit_toml_paths(a.game, True))
    print("installed. rivet.log must now show: [loader] mod path %s is overstrike stage format." % STAGE_MOD_PATH)


def cmd_uninstall(a) -> None:
    for p in (os.path.join(a.game, "mods", STAGE_NAME), os.path.join(a.game, "scripts", MANIFEST_LUA)):
        if os.path.isfile(p):
            os.remove(p)
            print("removed " + p)
    print(edit_toml_paths(a.game, False))


# ======================================================================================================================
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("selftest")
    s = sub.add_parser("levels"); s.add_argument("--game", required=True); s.add_argument("--filter", default="")
    s = sub.add_parser("probe"); s.add_argument("--game", required=True); s.add_argument("--planet", action="append", required=True)
    s.add_argument("--log", action="append", default=[]); s.add_argument("--scripts"); s.add_argument("--out", default="probe_out")
    s.add_argument("--limit", type=int, default=0)
    s = sub.add_parser("poc"); s.add_argument("--game", required=True); s.add_argument("--probe", required=True)
    s.add_argument("--log", action="append", default=[]); s.add_argument("--scripts"); s.add_argument("--out", default="poc_out")
    s.add_argument("--pick", type=int, default=0); s.add_argument("--allow-same-faction", action="store_true")
    s.add_argument("--prefer", action="append", default=[])
    s = sub.add_parser("verify"); s.add_argument("--game", required=True); s.add_argument("--stage", required=True)
    s.add_argument("--log", action="append", default=[]); s.add_argument("--scripts")
    s = sub.add_parser("install"); s.add_argument("--game", required=True); s.add_argument("--build", required=True)
    s = sub.add_parser("uninstall"); s.add_argument("--game", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "selftest":
        import selftest
        return selftest.run()
    return {"levels": cmd_levels, "probe": cmd_probe, "poc": cmd_poc, "verify": cmd_verify,
            "install": cmd_install, "uninstall": cmd_uninstall}[a.cmd](a) or 0


if __name__ == "__main__":
    sys.exit(main())
