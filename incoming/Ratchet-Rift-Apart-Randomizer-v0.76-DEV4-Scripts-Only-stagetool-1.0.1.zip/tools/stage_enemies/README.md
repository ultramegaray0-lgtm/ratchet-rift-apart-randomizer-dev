# tools/stage_enemies - the .stage Enemy Randomizer companion (v0.76-DEV4, tool 1.0.1)

Python 3.9+, standard library only. Full description, evidence and the Phase A test: `docs/STAGE_ENEMY_RANDOMIZER.md`.

```
python stage_enemies.py selftest
python stage_enemies.py levels    --game GAME --filter zurkon
python stage_enemies.py probe     --game GAME --planet zurkon --log rivet.log [--log older.log ...]
python stage_enemies.py poc       --game GAME --probe probe_out/probe.json [--pick N] [--allow-same-faction]
python stage_enemies.py verify    --game GAME --stage poc_out/RandoEnemies.stage --log rivet.log [--log ...]   (the logs probe used)
python stage_enemies.py install   --game GAME --build poc_out
python stage_enemies.py uninstall --game GAME
```

GAME = the folder holding RiftApart.exe, `toc` and `dag`. Only `install` / `uninstall` write there.
Exit code 2 = refused (the reason is printed); nothing was written to the game folder.

| File | |
|---|---|
| stage_enemies.py | the commands |
| rcra.py | toc / DSAR (LZ4) / dag / DAT1 / asset header readers, CRC32 / CRC64, .stage writer - each structure cites its source |
| knowledge.py | template uids, combat pairs, spawner keys and actor paths read from 16_rando_spawners.lua and rivet.logs |
| selftest.py, fakegame.py | the self-test and its synthetic game folder (format-consistency only, not real game data) |
