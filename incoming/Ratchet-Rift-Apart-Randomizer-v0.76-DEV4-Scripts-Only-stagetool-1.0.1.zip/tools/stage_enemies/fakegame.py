"""fakegame.py - a tiny SYNTHETIC game folder (toc, dag, one DSAR archive) written to the documented formats.

Used only by the self-test to run probe -> poc -> verify -> install -> uninstall end to end without the real game.
It proves the tool is consistent with the format documents (Overstrike / rivet / Ripped Apart); it does NOT prove the
real game's zones look like this - only the probe on your game files can show that.
"""
from __future__ import annotations

import os
import struct
from typing import Dict, List, Tuple

import rcra


def dat1(type_id: int, sections: List[Tuple[int, bytes]], strings: bytes = b"") -> bytes:
    n = len(sections)
    head = 16 + 12 * n
    pos = head + len(strings)
    table, body, offs = [], bytearray(), []
    for tag, data in sections:
        pos += (-pos) % 16
        offs.append(pos)
        pos += len(data)
    out = bytearray(struct.pack("<IIIHH", rcra.DAT1_MAGIC, type_id, pos, n, 0))
    for (tag, data), o in zip(sections, offs):
        out += struct.pack("<III", tag, o, len(data))
    out += strings
    for (tag, data), o in zip(sections, offs):
        out += bytes(o - len(out))
        out += data
    return bytes(out)


def lz4_literals(data: bytes) -> bytes:
    """A valid LZ4 block holding only literals (the format allows it)."""
    n = len(data)
    if n < 15:
        return bytes([n << 4]) + data
    out = bytearray([0xF0])
    r = n - 15
    while r >= 255:
        out.append(255)
        r -= 255
    out.append(r)
    return bytes(out) + data


def dsar(payload: bytes, chunk: int = 1000) -> bytes:
    chunks = [payload[i:i + chunk] for i in range(0, len(payload), chunk)]
    comp = [lz4_literals(c) for c in chunks]
    first = 32 + 32 * len(chunks)
    out = bytearray(struct.pack("<IHHIIQQ", rcra.DSAR_MAGIC, 3, 1, len(chunks), first, len(payload), 0))
    pos, real = first, 0
    for c, cc in zip(chunks, comp):
        out += struct.pack("<QQIIB7s", real, pos, len(c), len(cc), 3, b"\x55" * 7)
        pos += len(cc)
        real += len(c)
    for cc in comp:
        out += cc
    return bytes(out)


def build(root: str, zones: Dict[str, bytes]) -> Dict[str, int]:
    """zones: path -> raw zone bytes (DAT1 at 0). Writes root/toc, root/dag, root/d/fake.archive. Returns ids."""
    os.makedirs(os.path.join(root, "d"), exist_ok=True)
    items = sorted((rcra.crc64_path(p), p, raw) for p, raw in zones.items())
    payload, sizes, headers = bytearray(), bytearray(), bytearray()
    for k, (aid, p, raw) in enumerate(items):
        off = len(payload)
        payload += raw
        sizes += struct.pack("<IIIi", len(raw), 0, off, len(headers))
        headers += struct.pack("<I8I", 0x5A0E5A0E, len(raw), 0, 0, 0, 0, 0, 0, 0)
    with open(os.path.join(root, "d", "fake.archive"), "wb") as f:
        f.write(dsar(bytes(payload)))
    spans = [(0, len(items))] + [(len(items), 0)] * 255
    archives = b"d\\fake.archive".ljust(40, b"\0") + struct.pack("<QQIHI", 0, 0, 0, 0, 0)
    toc_dat = dat1(0x51B8E006, [
        (rcra.TOC_ASSET_IDS, struct.pack("<%dQ" % len(items), *[i[0] for i in items])),
        (rcra.TOC_SPANS, b"".join(struct.pack("<II", a, b) for a, b in spans)),
        (rcra.TOC_SIZES, bytes(sizes)),
        (rcra.TOC_ARCHIVES, archives),
        (rcra.TOC_HEADERS, bytes(headers)),
    ])
    with open(os.path.join(root, "toc"), "wb") as f:
        f.write(struct.pack("<II", rcra.TOC_MAGIC, len(toc_dat) + 8) + toc_dat)
    # dag: names as cstrings after the section table
    names = [i[1] for i in items]
    n = len(names)
    strings = bytearray()
    head = 16 + 12 * 5
    offs = []
    for nm in names:
        offs.append(head + len(strings))
        strings += nm.encode() + b"\0"
    dag_dat = dat1(0x2A077A51, [
        (rcra.DAG_ASSET_IDS, bytes(8 * n)),
        (rcra.DAG_NAMES, struct.pack("<%dI" % n, *offs)),
        (rcra.DAG_TYPES, bytes([1] * n)),
        (rcra.DAG_LINKS, struct.pack("<i", -1)),
        (rcra.DAG_HEADS, struct.pack("<%di" % n, *([0] * n))),
    ], bytes(strings))
    with open(os.path.join(root, "dag"), "wb") as f:
        f.write(struct.pack("<III", 0xB8EF3955, len(dag_dat) + 12, 0) + dag_dat)
    return {p: aid for aid, p, _ in items}
