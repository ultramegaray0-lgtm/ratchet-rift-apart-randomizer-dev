"""selftest.py - checks the companion against facts it did not produce itself, then runs it end to end on a synthetic
game folder. `python stage_enemies.py selftest` (exit 0 = every check passed).

  1. asset ids: crc64_path against ids the GAME's create_asset_id produced (rivet.log, "[loader] ... resolved to")
  2. plug / section ids: crc32_engine against the game's plug hashes (16_rando_spawners.lua, from rivet_hook) and
     Ripped Apart's lump table
  3. LZ4: blocks made by the reference lz4 compressor (python-lz4 4.x, embedded below)
  4. end to end on fakegame.py's synthetic toc/dag/DSAR: probe -> poc -> verify -> rebuild identical -> install ->
     uninstall; and the refusals (bad pair, changed zone, foreign change)
  5. (tool 1.0.1) spawner_keys: only spawners whose variable rivet.log saw holding the original uid; nothing guessed
"""
import contextlib
import hashlib
import io
import json
import os
import shutil
import struct
import sys
import tempfile

import fakegame
import rcra
import stage_enemies as SE

GAME_IDS = {  # rivet.log of v0.76-DEV3 (rivet_hook 2.0.0 asking the game's own create_asset_id)
    "ui/loaded/exported/hud/mm_0.json": 0x9E1FEBBD584DCEA0, "ui/loaded/exported/hud/mm_1.json": 0x867EDEEA84C95751,
    "ui/loaded/exported/hud/mm_2.json": 0xAEDD8112E144FD43, "ui/loaded/exported/hud/mm_3.json": 0xB6BCB4453DC064B2,
    "ui/loaded/exported/hud/mm_4.json": 0x9B2D1528C19C2EC7, "ui/loaded/exported/hud/mm_5.json": 0x834C207F1D18B736,
    "ui/loaded/exported/hud/mm_6.json": 0xABEF7F8778951D24, "ui/loaded/exported/hud/mm_7.json": 0xB38E4AD0A41184D5,
}
PLUG_IDS = {"Template": 1835115251, "Templates": 3990217346, "LastSpawn": 406637480, "Factories": 838143302,
            "Location": 2761897147, "Locations": 2501629366}
LZ4_VECTORS = [
('ff0152696674204170617274207a6f6e65201000ffff5ff0f1000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeeff0f1f2f3f4f5f6f7f8f9fafbfcfdfeff', 896, '4887c1a624d5925f368b1248bff031a633788e635c094a2ca921dc203b94c4c3'),
('1f000100ff19ff5644415431000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f404142434445464748494a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606100aa505c5d5e5f60', 595, '12c88e0f9f684b2f8f2b1387f995801c6c9e628268d5faacbf772c831428842a'),
('ffec00070e151c232a31383f464d545b626970777e858c939aa1a8afb6bdc4cbd2d9e0e7eef501080f161d242b323940474e555c636a71787f868d949ba2a9b0b7bec5ccd3dae1e8eff6020910171e252c333a41484f565d646b727980878e959ca3aab1b8bfc6cdd4dbe2e9f0f7030a11181f262d343b424950575e656c737a81888f969da4abb2b9c0c7ced5dce3eaf1f8040b121920272e353c434a51585f666d747b828990979ea5acb3bac1c8cfd6dde4ebf2f9050c131a21282f363d444b525960676e757c838a91989fa6adb4bbc2c9d0d7dee5ecf3fa060d141b222930373e454c535a61686f767d848b9299a0a7aeb5bcc3cad1d8dfe6edf4fb00ffffffffffffffffffffffffffffffffffff87504c535a6168', 5000, '08026c57be31084b60ded63e3101c86365be4d84b87b43bad97b3feb8152e20f'),
]

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("  %-4s %s%s" % ("ok" if ok else "FAIL", name, ("  - " + detail) if detail and not ok else ""))


def zone_bytes(var_uids, actor_uids, refs=()):
    """A synthetic zone: Script Vars records of 0x40 bytes {uid, ..., type 5 at +0x34}, Zone Actors of 0x20 bytes."""
    sv = bytearray()
    for u in var_uids:
        rec = bytearray(0x40)
        rec[0:8] = rcra.uid_bytes(u)
        rec[0x34:0x36] = struct.pack("<H", 5)
        sv += rec
    za = bytearray()
    for u in actor_uids:
        rec = bytearray(0x20)
        rec[0:8] = rcra.uid_bytes(u)
        za += rec
    ar = b"".join(struct.pack("<Q", rcra.crc64_path(p)) for p in refs)
    return fakegame.dat1(0x5A0E0001, [(rcra.SEC["Zone Actors"], bytes(za)), (rcra.SEC["Zone Script Vars"], bytes(sv)),
                                       (rcra.SEC["Zone Asset References"], ar)])


def run_quiet(argv):
    buf = io.StringIO()
    code = None
    with contextlib.redirect_stdout(buf):
        try:
            code = SE.main(argv)
        except SystemExit as e:
            code = e.code
    return code, buf.getvalue()


def run():
    print("1. asset ids against the game's own")
    for p, v in GAME_IDS.items():
        check("crc64 " + p, rcra.crc64_path(p) == v, "%016X != %016X" % (rcra.crc64_path(p), v))
    check("crc64 normalizes case and separators", rcra.crc64_path("UI\\Loaded//Exported/HUD/MM_0.JSON") == GAME_IDS["ui/loaded/exported/hud/mm_0.json"])
    print("2. plug and section ids")
    for n, v in PLUG_IDS.items():
        check("crc32 plug " + n, rcra.crc32_engine(n) == v)
    bad = [n for t, n in rcra.SECTION_NAMES.items() if rcra.crc32_engine(n) != t]
    check("crc32 of %d section names" % len(rcra.SECTION_NAMES), not bad, ", ".join(bad))
    print("3. LZ4 against the reference compressor")
    for i, (h, n, sha) in enumerate(LZ4_VECTORS):
        out = rcra.lz4_block_decompress(bytes.fromhex(h), n)
        check("lz4 vector %d (%d bytes)" % (i, n), hashlib.sha256(out).hexdigest() == sha)
    try:
        rcra.lz4_block_decompress(b"\x1f\x00\x05\x00", 40)
        check("lz4 rejects a bad offset", False)
    except rcra.FormatError:
        check("lz4 rejects a bad offset", True)

    print("4. end to end on a synthetic game folder")
    tmp = tempfile.mkdtemp(prefix="stage_selftest_")
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        scripts = os.path.normpath(os.path.join(here, "..", "..", "scripts"))
        SHOOT, MELEE, BLADE = "ECE0F432299E09D3", "92B2CE851D2D2468", "E045F83C7223AF50"   # V.REG_BUILTIN (Zurkon)
        NEF_M = "8DBDBB2D4107EB6C"
        shooter_actor = "characters/enemy/enm_pirate_robot_q4b/actors/enm_pirate_robot_shooter.actor"
        melee_actor = "characters/enemy/enm_pirate_robot_q4b/actors/enm_pirate_robot_melee.actor"
        game = os.path.join(tmp, "game")
        zones = {
            "levels/fake_zurkon/arena_gameplay.zone": zone_bytes([SHOOT, "1111111111111111"], [SHOOT, MELEE, BLADE], [shooter_actor, melee_actor]),
            "levels/fake_zurkon/no_replacement.zone": zone_bytes([SHOOT], [SHOOT]),
            "levels/other/elsewhere.zone": zone_bytes([NEF_M], [NEF_M]),
        }
        fakegame.build(game, zones)
        os.makedirs(os.path.join(game, "scripts"))
        os.makedirs(os.path.join(game, "mods"))
        with open(os.path.join(game, "rivet.toml"), "w") as f:
            f.write('[overlay]\nenabled = true\n\n[assets]\nenabled = true\npaths = ["mods/default", "mods/ARSENAL_RESTORED.stage"]\n\n[log]\npaths = false\n')
        log = os.path.join(tmp, "rivet.log")
        with open(log, "w") as f:
            f.write("[script] [rando]\tRANDO-ENEMIES\tASSET enm_pirate_robot_shooter (ground, GameBotShooter): characters\\enemy\\enm_pirate_robot_q4b\\actors\\enm_pirate_robot_shooter.actor\n")
            f.write("[script] [rando]\tRANDO-ENEMIES\tASSET enm_pirate_robot_melee (swarmer, GameBotMeleeSwarmer): characters\\enemy\\enm_pirate_robot_q4b\\actors\\enm_pirate_robot_melee.actor\n")
            f.write("[script] [rando]\tRANDO-ENEMIES\tSPAWN 1 | zurkon | MIS_X @ CHK_A1 | factory Templates ABCDEF0123456789 | original enm_pirate_robot_shooter | selected - | spawned enm_pirate_robot_shooter (ground) | NOT CHANGED: x\n")
        # the toc/dag readers
        toc, dag = rcra.Toc(game), rcra.Dag(game)
        zid = rcra.crc64_path("levels/fake_zurkon/arena_gameplay.zone")
        e = toc.find(zid, 0)
        check("toc finds the zone in span 0", e is not None)
        check("DSAR read returns the zone", e is not None and toc.read(e) == zones["levels/fake_zurkon/arena_gameplay.zone"])
        check("dag lists 3 zones by name", sorted(dag.names) == sorted(zones) and all(dag.type_name(i) == "zone" for i in range(dag.count)))
        toc.close()

        probe_out = os.path.join(tmp, "probe")
        code, out = run_quiet(["probe", "--game", game, "--planet", "fake_zurkon", "--log", log, "--scripts", scripts, "--out", probe_out])
        check("probe runs", code == 0, out[-400:])
        rep = json.load(open(os.path.join(probe_out, "probe.json")))
        check("probe reads 2 zones (filter)", len(rep["zones"]) == 2)
        t = rep["totals"].get("template", {})
        check("probe: template uids in Script Vars and Zone Actors", t.get("Zone Script Vars") == 2 and t.get("Zone Actors") == 4, str(t))
        check("probe: enemy .actor ids in Zone Asset References", rep["totals"].get("actor_asset", {}).get("Zone Asset References") == 2)
        arena = [z for z in rep["zones"] if "arena" in z["zone"]][0]
        check("probe: Script Vars stride 0x40 seen as gcd", arena["script_vars_template_refs"] == 1 or arena["script_vars_stride_gcd"] in (0, 0x40))

        poc_out = os.path.join(tmp, "poc")
        code, out = run_quiet(["poc", "--game", game, "--probe", os.path.join(probe_out, "probe.json"), "--out", poc_out])
        check("poc builds", code == 0, out[-600:])
        man = json.load(open(os.path.join(poc_out, "stage_enemies_manifest.json")))
        c = man["changes"][0]
        check("poc picks the combat-verified pair shooter -> brawler in the zone that holds both",
              c["original_uid"] == SHOOT and c["replacement_uid"] == MELEE and "arena" in c["zone"] and c["tier"] == "A", json.dumps(c)[:300])
        check("poc changes exactly 8 bytes or fewer", 0 < c["changed_bytes"] <= 8)
        info, files = rcra.read_stage(os.path.join(poc_out, SE.STAGE_NAME))
        check(".stage info.json says RCRA", info.get("game") == "RCRA")
        check(".stage holds one span-0 entry named by id", list(files) == ["0/%016X" % zid])
        blob = files["0/%016X" % zid]
        orig = zones["levels/fake_zurkon/arena_gameplay.zone"]
        check(".stage entry = 36-byte header + zone of the same size", len(blob) == 36 + len(orig))
        check("the backup equals header + original zone", open(os.path.join(poc_out, "backup", "%016X.zone.orig" % zid), "rb").read()[36:] == orig)
        lua = open(os.path.join(poc_out, SE.MANIFEST_LUA)).read()
        check("Lua manifest names the change", "RANDO_STAGE_ENEMIES" in lua and SHOOT in lua and MELEE in lua)
        try:
            from lupa import lua54  # optional: only for this check
            L = lua54.LuaRuntime()
            L.execute(lua)
            g = L.globals().RANDO_STAGE_ENEMIES
            check("Lua manifest parses (lupa)", g is not None and g.changes[1].replacement_uid == MELEE)
        except ImportError:
            print("  skip Lua manifest parse (lupa not installed)")
        h1 = hashlib.sha256(open(os.path.join(poc_out, SE.STAGE_NAME), "rb").read()).hexdigest()
        code, _ = run_quiet(["poc", "--game", game, "--probe", os.path.join(probe_out, "probe.json"), "--out", poc_out + "2"])
        h2 = hashlib.sha256(open(os.path.join(poc_out + "2", SE.STAGE_NAME), "rb").read()).hexdigest()
        check("rebuilding gives a byte-identical .stage", code == 0 and h1 == h2)

        code, out = run_quiet(["verify", "--game", game, "--stage", os.path.join(poc_out, SE.STAGE_NAME), "--scripts", scripts])
        check("verify: OK, one known uid replaced", code == 0 and "enm_pirate_robot_shooter) -> " in out, out[-500:])

        # refusals
        bad = os.path.join(tmp, "bad.stage")
        nb = bytearray(blob)
        nb[36 + 100] ^= 0xFF
        rcra.write_stage(bad, "x", "x", "x", [rcra.StageEntry(0, zid, bytes(nb[:36]), bytes(nb[36:]))])
        code, out = run_quiet(["verify", "--game", game, "--stage", bad, "--scripts", scripts])
        check("verify refuses a change that is not a uid swap", code == SE.EXIT_REFUSED)
        code, out = run_quiet(["install", "--game", game, "--build", poc_out])
        check("install refuses without the DEV4 Lua side", code == SE.EXIT_REFUSED)
        open(os.path.join(game, "scripts", "18_rando_stage_enemies.lua"), "w").write("-- stub\n")
        code, out = run_quiet(["install", "--game", game, "--build", poc_out])
        toml = open(os.path.join(game, "rivet.toml")).read()
        check("install copies and lists the .stage LAST", code == 0 and os.path.isfile(os.path.join(game, "mods", SE.STAGE_NAME))
              and 'paths = ["mods/default", "mods/ARSENAL_RESTORED.stage", "mods/RandoEnemies.stage"]' in toml, toml)
        check("install keeps the rest of rivet.toml", "[log]\npaths = false" in toml and "[overlay]" in toml)
        code, out = run_quiet(["verify", "--game", game, "--stage", os.path.join(game, "mods", SE.STAGE_NAME), "--scripts", scripts])
        check("verify after install: OK", code == 0, out[-300:])
        # a second mod that replaces the same zone is reported
        clash = os.path.join(game, "mods", "other.stage")
        rcra.write_stage(clash, "o", "o", "o", [rcra.StageEntry(0, zid, blob[:36], blob[36:])])
        t2 = toml.replace('"mods/default", ', '"mods/default", "mods/other.stage", ')
        open(os.path.join(game, "rivet.toml"), "w").write(t2)
        code, out = run_quiet(["verify", "--game", game, "--stage", os.path.join(game, "mods", SE.STAGE_NAME), "--scripts", scripts])
        check("verify reports another mod replacing the same zone", code == SE.EXIT_REFUSED and "cannot both change" in out)
        code, out = run_quiet(["uninstall", "--game", game])
        toml = open(os.path.join(game, "rivet.toml")).read()
        check("uninstall removes the files and the path", code == 0 and not os.path.exists(os.path.join(game, "mods", SE.STAGE_NAME))
              and not os.path.exists(os.path.join(game, "scripts", SE.MANIFEST_LUA)) and "RandoEnemies" not in toml)
        # a zone changed after the probe is refused
        zones["levels/fake_zurkon/arena_gameplay.zone"] = zone_bytes([SHOOT, "2222222222222222"], [SHOOT, MELEE, BLADE])
        fakegame.build(game, zones)
        code, out = run_quiet(["poc", "--game", game, "--probe", os.path.join(probe_out, "probe.json"), "--out", poc_out + "3"])
        check("poc refuses a zone that changed since the probe", code == SE.EXIT_REFUSED and "changed since the probe" in out, out[-300:])
        # no evidence -> no build
        code, out = run_quiet(["probe", "--game", game, "--planet", "levels/other", "--log", log, "--scripts", scripts, "--out", probe_out + "x"])
        code, out = run_quiet(["poc", "--game", game, "--probe", os.path.join(probe_out + "x", "probe.json"), "--out", poc_out + "4"])
        check("poc refuses when no pair is proven in one zone", code == SE.EXIT_REFUSED)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    spawner_attribution()
    failed = [r for r in RESULTS if not r[1]]
    print("SELFTEST %s: %d checks, %d failed" % ("PASSED" if not failed else "FAILED", len(RESULTS), len(failed)))
    return 0 if not failed else 1


def spawner_attribution():
    """Tool 1.0.1: a manifest's spawner_keys are only the spawners whose variable the log SAW holding the original uid."""
    import knowledge as K
    print("5. which spawner holds the changed reference (rivet.log evidence)")
    here = os.path.dirname(os.path.abspath(__file__))
    scripts = os.path.normpath(os.path.join(here, "..", "..", "scripts"))
    P = "[script] [rando]\tRANDO-ENEMIES\t"
    SH, ME = "enm_pirate_robot_shooter", "enm_pirate_robot_melee"
    first = "NOT CHANGED: kind not known yet (learned from its first spawn)"

    def spawn(n, key, kind, fam, why=first):
        return P + "SPAWN %d | ardolis | MIS_T @ CHK_%s | factory Templates %s | original %s | selected - | spawned %s (%s) | %s\n" % (
            n, key[:1], key, kind, kind, fam, why)

    def learned(n, uid, kind, fam, cls, src="spawn"):
        return P + "learned template %d (uid %s): %s = %s/%s, role enemy (%s)\n" % (n, uid, kind, fam, cls, src)
    A, B, C, D, E, F = ("%s" % (ch * 16) for ch in "ABCDEF")
    lines = [
        spawn(1, A, SH, "ground"), learned(1, "1111111111111111", SH, "ground", "GameBotShooter"),           # A holds 1111
        spawn(2, B, SH, "ground"), learned(2, "2222222222222222", SH, "ground", "GameBotShooter"),           # B holds 2222
        spawn(3, C, SH, "ground"), P + "scan 1 on ardolis: 3 spawner variable(s)\n",
        learned(3, "3333333333333333", SH, "ground", "GameBotShooter"),                                      # not adjacent
        spawn(4, D, ME, "swarmer"), learned(4, "4444444444444444", SH, "ground", "GameBotShooter"),          # other kind
        spawn(5, E, SH, "ground", "NOT CHANGED: spawned before the randomizer read its spawner"),
        learned(5, "5555555555555555", SH, "ground", "GameBotShooter"),                                      # not a first spawn
        spawn(6, F, SH, "ground"), learned(6, "6666666666666666", SH, "ground", "GameBotShooter", "template actor"),
        P + "scan 2 on ardolis\n", learned(7, "7777777777777777", ME, "swarmer", "GameBotMeleeSwarmer"),
    ]
    tmp = tempfile.mkdtemp(prefix="stage_selftest5_")
    try:
        log = os.path.join(tmp, "rivet.log")
        with open(log, "w", newline="\r\n") as f:      # rivet.log on Windows ends lines with CRLF
            f.writelines(lines)
        k = K.Knowledge()
        K.load_scripts(k, scripts)
        K.load_log(k, log)
        got = {key: sorted(k.spawners[key].uids) for key in (A, B, C, D, E, F)}
        check("SPAWN + its own 'learned ... (spawn)' line ties the uid to that spawner",
              got[A] == ["1111111111111111"] and got[B] == ["2222222222222222"], str(got))
        check("no tie across another line, another kind, a non-first spawn or a template-actor learn",
              not got[C] and not got[D] and not got[E] and not got[F], str(got))

        def hit(kind, ident, label, section, rel):
            return {"kind": kind, "id": ident, "label": label, "section": section, "rel": rel, "abs": 1000 + rel}
        hits = [hit("template", "1111111111111111", SH, "Zone Script Vars", 16),
                hit("template", "3333333333333333", SH, "Zone Script Vars", 48),
                hit("template", "1111111111111111", SH, "Zone Actors", 8),
                hit("template", "3333333333333333", SH, "Zone Actors", 40),
                hit("template", "7777777777777777", ME, "Zone Actors", 72)]
        for key in (A, B, C):                                 # every key sits twice in its Script Actions record
            hits += [hit("spawner", key, "factory", "Zone Script Actions", 200), hit("spawner", key, "factory", "Zone Script Actions", 208)]
        report = {"zones": [{"zone": "levels/t/t.zone", "zone_id": "8000000000000001", "sha256": "0" * 64,
                             "rivet_hook_ok": True, "hits": hits}]}
        cands = SE.candidates(report, k, False, [])
        c1 = [c for c in cands if c["original_uid"] == "1111111111111111" and c["replacement_uid"] == "7777777777777777"]
        c3 = [c for c in cands if c["original_uid"] == "3333333333333333" and c["replacement_uid"] == "7777777777777777"]
        check("candidate: spawner_keys = only the spawner seen holding the original uid, no duplicates",
              bool(c1) and c1[0]["spawner_keys"] == [A] and c1[0]["same_kind_spawner_keys"] == [A, B, C]
              and c1[0]["encounters"] == ["MIS_T @ CHK_A"], json.dumps(c1[:1])[:400])
        check("candidate: no spawner seen holding the uid -> spawner_keys empty, encounters marked as same-kind",
              bool(c3) and c3[0]["spawner_keys"] == [] and "not identified" in c3[0]["encounters_of"]
              and len(c3[0]["encounters"]) == 3, json.dumps(c3[:1])[:400])
        check("ranking unchanged by the attribution (score needs a same-kind spawner, as in 1.0.0)",
              bool(c1 and c3) and c1[0]["score"] == c3[0]["score"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(run())
