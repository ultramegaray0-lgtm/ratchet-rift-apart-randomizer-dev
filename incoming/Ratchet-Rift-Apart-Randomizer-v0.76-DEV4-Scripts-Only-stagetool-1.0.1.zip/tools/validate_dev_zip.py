#!/usr/bin/env python3
"""validate_dev_zip.py - checks a v0.76-DEV4 development ZIP before it is installed (or delivered).

  python tools/validate_dev_zip.py Ratchet-Rift-Apart-Randomizer-v0.76-DEV4-Scripts-Only.zip

Checks: the archive is intact; it holds EXACTLY the files of this kit (nothing missing, nothing extra, no caches);
VERSION.txt, the release banner and every script's kit stamp say v0.76-DEV4 / 10.0.43; then, from a fresh extraction,
the companion's selftest and (with lupa) the Lua tests of tests/v076dev4 and tests/v076dev2/test_enemy_dev2.py run.
Exit 0 = every check passed.
"""
import os, re, subprocess, sys, tempfile, zipfile, hashlib

RELEASE, KIT = "v0.76-DEV4", "10.0.43"
EXPECTED = ['INSTALL.txt', 'VERSION.txt', 'dev_scripts/dev(debug).lua', 'dev_scripts/dev(item_ids).lua', 'dev_scripts/dev(keys).lua', 'dev_scripts/dev(omega_inventory_probe).lua', 'dev_scripts/dev(probe).lua', 'dev_scripts/dev(spawnprobe).lua', 'dev_scripts/dev(spawnproof).lua', 'dev_scripts/dev(testmode).lua', 'dev_scripts/dev(testtravel).lua', 'dev_scripts/dev(vtables).lua', 'docs/ARMOR.md', 'docs/ARSENAL_RESTORED.md', 'docs/BATCH_10.0.txt', 'docs/BATCH_10.11.txt', 'docs/CAMPAIGN.md', 'docs/CHANGELOG.md', 'docs/CHAOS.md', 'docs/COMPATIBILITY.md', 'docs/CONFIGURATION.md', 'docs/DESIGN.md', 'docs/DEVELOPMENT_LOG.md', 'docs/ENEMIES_AND_BOSSES.md', 'docs/ENEMY_RANDOMIZER_COVERAGE.md', 'docs/FEATURES_AND_LIMITATIONS.md', 'docs/HUB.md', 'docs/KNOWN_ISSUES.md', 'docs/LEVELS.md', 'docs/MIGRATION.md', 'docs/NEW_GAME.md', 'docs/OMEGA.md', 'docs/PLAYING.md', 'docs/RECOVERY.md', 'docs/RESEARCH.md', 'docs/RESEARCH_8.0.md', 'docs/SHOP.md', 'docs/STAGE_ENEMY_RANDOMIZER.md', 'docs/TESTING.md', 'docs/TEST_REPORT_10.12.md', 'docs/TEST_REPORT_10.13.md', 'docs/TEST_REPORT_10.15.md', 'docs/TEST_RESULTS.txt', 'docs/TEST_TRAVEL.md', 'docs/VERIFICATION_REPORT.md', 'docs/VERIFIED_IN_GAME.md', 'docs/WEAPONS.md', 'docs/examples/spoiler_example-balanced.txt', 'docs/examples/spoiler_example-campaign.txt', 'docs/examples/spoiler_example-chaos.txt', 'docs/examples/spoiler_example-everything.txt', 'docs/shop_harness.py', 'rivet.toml', 'scripts/01_rando_data.lua', 'scripts/02_rando_generator.lua', 'scripts/03_rando_campaign.lua', 'scripts/04_rando_settings.lua', 'scripts/05_rando_bindings.lua', 'scripts/06_rando_capabilities.lua', 'scripts/09_rando_real.lua', 'scripts/10_rando_runtime.lua', 'scripts/11_rando_campaign.lua', 'scripts/12_rando_shop.lua', 'scripts/13_rando_armor.lua', 'scripts/14_rando_travel.lua', 'scripts/15_rando_hub.lua', 'scripts/16_rando_spawners.lua', 'scripts/17_rando_omega.lua', 'scripts/18_rando_stage_enemies.lua', 'scripts/boss.lua', 'scripts/chaos.lua', 'scripts/enemy.lua', 'tests/dev8/README.txt', 'tests/dev8/test_armor_dev8.py', 'tests/dev8/test_enemy_dev8.py', 'tests/dev8/test_gen_dev8.py', 'tests/dev8/test_shop_dev8.py', 'tests/dev8/test_xp_dev8.py', 'tests/dev9/README.txt', 'tests/dev9/test_owned_dev9.py', 'tests/v076/README.txt', 'tests/v076/test_killable_v076.py', 'tests/v076dev2/README.txt', 'tests/v076dev2/test_enemy_dev2.py', 'tests/v076dev2/test_genbudget_dev2.py', 'tests/v076dev2/test_newgame_dev2.py', 'tests/v076dev2/test_quota_dev2.py', 'tests/v076dev2/test_shop_dev2.py', 'tests/v076dev2/test_xpgain_dev2.py', 'tests/v076dev4/README.txt', 'tests/v076dev4/test_stage_dev4.py', 'tools/stage_enemies/README.md', 'tools/stage_enemies/fakegame.py', 'tools/stage_enemies/knowledge.py', 'tools/stage_enemies/rcra.py', 'tools/stage_enemies/selftest.py', 'tools/stage_enemies/stage_enemies.py', 'tools/validate_dev_zip.py']


def main(path):
    fails = []
    def check(ok, msg):
        print(("ok   " if ok else "FAIL ") + msg)
        if not ok: fails.append(msg)
    z = zipfile.ZipFile(path)
    check(z.testzip() is None, "archive CRCs intact")
    names = [n for n in z.namelist() if not n.endswith("/")]
    root = os.path.commonprefix(names).split("/")[0] + "/" if all("/" in n for n in names) and len({n.split("/")[0] for n in names}) == 1 else ""
    rel = sorted(n[len(root):] for n in names)
    check(all(not (n.startswith("/") or ".." in n.split("/")) for n in names), "no absolute or parent paths")
    check(not [n for n in rel if "__pycache__" in n or n.endswith(".pyc")], "no Python caches")
    missing = sorted(set(EXPECTED) - set(rel)); extra = sorted(set(rel) - set(EXPECTED))
    check(not missing, "no file missing (%d expected)%s" % (len(EXPECTED), (": " + ", ".join(missing)) if missing else ""))
    check(not extra, "no extra file%s" % ((": " + ", ".join(extra)) if extra else ""))
    rd = lambda n: z.read(root + n).decode("utf-8", "replace")
    check(RELEASE in rd("VERSION.txt").splitlines()[0] and ("Kit version: " + KIT) in rd("VERSION.txt"), "VERSION.txt: %s, kit %s" % (RELEASE, KIT))
    rt = rd("scripts/10_rando_runtime.lua")
    check('R.RELEASE = "%s"' % RELEASE in rt and 'R.KIT_VERSION = "%s"' % KIT in rt, "10_rando_runtime.lua banner %s / %s" % (RELEASE, KIT))
    m = re.search(r"^R\.OPTIONAL_FILES = \{[^}]*\}", rt, re.M)
    check(bool(m) and '"18_rando_stage_enemies"' in m.group(0), "18_rando_stage_enemies is an optional kit file")
    bad = []
    for n in rel:
        if n.endswith(".lua"):
            for m in re.finditer(r'RANDO_FILES\["([^"]+)"\] = "([0-9.]+)"', rd(n)):
                if m.group(2) != KIT: bad.append("%s %s" % (n, m.group(2)))
    check(not bad, "every script and developer script is stamped %s%s" % (KIT, (": " + ", ".join(bad)) if bad else ""))
    with tempfile.TemporaryDirectory() as t:
        z.extractall(t)
        kit = os.path.join(t, root) if root else t
        r = subprocess.run([sys.executable, "-I", os.path.join(kit, "tools", "stage_enemies", "stage_enemies.py"), "selftest"],
                           capture_output=True, text=True)
        check(r.returncode == 0 and "SELFTEST PASSED" in r.stdout, "companion selftest from the extracted ZIP: " + (r.stdout.strip().splitlines() or ["?"])[-1])
        try:
            import lupa  # noqa: F401
            for test in ("tests/v076dev4/test_stage_dev4.py", "tests/v076dev2/test_enemy_dev2.py", "tests/v076dev2/test_newgame_dev2.py"):
                r = subprocess.run([sys.executable, os.path.join(kit, test), kit], capture_output=True, text=True, cwd=kit)
                check(r.returncode == 0 and "FAILURES 0" in r.stdout, "%s from the extracted ZIP: %s" % (test, (r.stdout.strip().splitlines() or ["?"])[-1]))
        except ImportError:
            print("skip Lua tests (pip install lupa)")
    print("sha256 %s  %s" % (hashlib.sha256(open(path, "rb").read()).hexdigest(), os.path.basename(path)))
    print("VALIDATION %s: %d check(s) failed" % ("PASSED" if not fails else "FAILED", len(fails)))
    return 0 if not fails else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
