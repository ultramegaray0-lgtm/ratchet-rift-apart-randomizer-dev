v0.76-DEV4 offline tests (Python 3 + lupa: pip install lupa). Run from the kit folder:
  python tests/v076dev4/test_stage_dev4.py .                    the Lua side of the .stage Enemy Randomizer: every script
                                                               compiles; no manifest = the runtime route unchanged; a manifest
                                                               = no runtime spawner write (variable route, V.arm, Chaos slots),
                                                               earlier changes put back; STAGE VARIABLE / SPAWN / DEATH / SUMMARY
                                                               tell a loaded .stage from one that did not load; enemy_source
  python tools/stage_enemies/stage_enemies.py selftest          the companion: asset ids against the game's own, LZ4 against the
                                                               reference compressor, probe -> poc -> verify -> install ->
                                                               uninstall on a synthetic game folder, every refusal
The tests in tests/v076dev2, tests/v076 and tests/dev8 still apply (dev8 test_gen and dev9 test_owned need older kit folders).
