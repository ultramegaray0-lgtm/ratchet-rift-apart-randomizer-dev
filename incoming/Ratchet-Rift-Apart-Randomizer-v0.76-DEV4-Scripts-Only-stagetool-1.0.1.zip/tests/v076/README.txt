v0.76-DEV1 offline tests (Python 3 + lupa: pip install lupa). Run from the kit folder:
  python tests/v076/test_killable_v076.py . [round-63 rivet.log]
The log argument is optional: with it, every pair round 63 used is checked against the new rules
(pairs that died stay allowed, pairs never killed are not used).
