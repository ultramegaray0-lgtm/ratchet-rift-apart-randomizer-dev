# v0.76-DEV1: enemy_compat = "killable" (the default) - only enemies proven killable where they spawn.
# Replays round 63 (v0.75 rivet.log): which pairs the old rules ("all") and the new ones ("killable") pick, the reload
# strike, the rejection reversal, "gone" proof, the save migration and the flyer watch time.
# Run from the kit folder:  python tests/v076/test_killable_v076.py . [path to the round-63 rivet.log]
import sys, os, re
from lupa import LuaRuntime
KIT = sys.argv[1]
LOGFILE = sys.argv[2] if len(sys.argv) > 2 else None
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1

def make(mode='killable', cross='false', state='{ enemy_combat = {} }'):
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals(); LOG = []; SAID = []
    g.py_log = lambda *a: LOG.append('\t'.join(str(x) for x in a))
    g.py_say = lambda t, *a: SAID.append(str(t))
    lua.execute('rivet = setmetatable({ log = function(...) py_log(...) end }, { __index = function() return function() return nil end end })')
    for f in ('01_rando_data.lua', '02_rando_generator.lua'):
        lua.execute(open(os.path.join(KIT, 'scripts', f), encoding='utf-8').read())
    lua.execute('RANDO = { config = { enemy_compat = "%s", enemy_cross_faction = %s, enemy_mix_movement = false }, state = %s, '
                'mark_changed = function() end, say = function(t) py_say(t) end, subscribe = function() end }' % (mode, cross, state))
    lua.execute(open(os.path.join(KIT, 'scripts', '16_rando_spawners.lua'), encoding='utf-8').read())
    return lua, LOG, SAID

# Zordoom (Viceron) in round 63: the kinds loaded there (names as the game gives them, families as logged)
ZORDOOM = [
    ('enm_neo_nefarious_shooter', 'ground'), ('enm_neo_nefarious_melee', 'swarmer'), ('enm_neo_nefarious_swarmer', 'swarmer'),
    ('enm_neo_nefarious_heavy', 'swarmer'), ('enm_neo_nefarious_sniper', 'flyer'), ('enm_neo_nefarious_grenadier', 'flyer'),
    ('enm_neo_nefarious_hover', 'flyer'), ('enm_thugs4less_melee', 'swarmer'), ('enm_thugs4less_shooter', 'ground'),
    ('enm_pirate_robot_melee', 'swarmer'), ('enm_pirate_shingle_q4b', 'swarmer'), ('enm_pirate_bladeball', 'swarmer'),
    ('enm_amoeboid_small_ps4', 'swarmer'), ('enm_amoeboid_medium_ps4', 'swarmer'), ('enm_amoeboid_large_ps4', 'swarmer'),
    ('enm_indigenous_crab', 'swarmer'), ('enm_indigenous_sandshark', 'swarmer'), ('enm_indigenous_hornedtoad', 'swarmer'),
    ('enm_indigenous_wasp', 'flyer'),
]
def setup_level(lua):
    rows = ',\n'.join('[%d] = { name = "%s", family = "%s", handle = %d, uid = "U%02d" }' % (i + 1, n, f, i + 1, i + 1)
                      for i, (n, f) in enumerate(ZORDOOM))
    lua.execute('local V = RANDO_SPAWNERS.V\nV.lvl = { tpl = {\n' + rows + '\n}, arms = {}, combat = {}, watch = {}, spawned = {} }')

def pick(lua, idx, key):
    return lua.eval('''(function()
      local V = RANDO_SPAWNERS.V
      local T = V.lvl.tpl[%d]
      local r = { kind = "factory", key = "%s", orig = { single = true, actors = %d, uid = T.uid } }
      local rep, why = V.pick(r, V.group_of(T), { T.name }, 0, true)
      if rep then local _, how = V.compat_allows(r, rep); return rep.name .. "|" .. tostring(how) end
      return "-|" .. tostring(why) end)()''' % (idx, key, idx))

# ---- 1. factions ------------------------------------------------------------------------------------------------
lua, LOG, SAID = make()
F = lambda n: lua.eval('RANDO_SPAWNERS.V.faction("%s")' % n)
check(F('enm_neo_nefarious_s') == 'neo' and F('enm_neo_nefarious_grenadier') == 'neo', 'faction: Nefarious troopers (cut names too)')
check(F('enm_indigenous_horn') == F('enm_indigenous_wasp') == 'wildlife', 'faction: Viceron creatures are one faction (wildlife)')
check(F('enm_thugs4less_skeleton_melee') == 'thugs4less' and F('enm_amoeboid_large_ps4') == 'amoeboid', 'faction: Goons, amoeboids')
check(lua.eval('RANDO_SPAWNERS.V.pair_kin("factory|enm_neo_nefarious_s/swarmer>enm_neo_nefarious_m/swarmer")') is True, 'pair_kin: Nefarious > Nefarious')
check(lua.eval('RANDO_SPAWNERS.V.pair_kin("factory|enm_neo_nefarious_s/swarmer>enm_amoeboid_large_/swarmer")') is False, 'pair_kin: Nefarious > amoeboid')

# ---- 2. picks on Zordoom: "all" (v0.75) vs "killable" --------------------------------------------------------------
cross_all, cross_kill, changed_kill, changed_all, total = 0, 0, 0, 0, 0
for mode in ('all', 'killable'):
    lua, LOG, SAID = make(mode)
    setup_level(lua)
    for i, (n, f) in enumerate(ZORDOOM):
        for k in range(8):                                     # 8 factories of each kind, different keys (different picks)
            res = pick(lua, i + 1, 'F%02d%d' % (i, k))
            rep, how = res.split('|', 1)
            if mode == 'all': total += 1
            if rep != '-':
                cross = lua.eval('RANDO_SPAWNERS.V.faction("%s")' % rep) != lua.eval('RANDO_SPAWNERS.V.faction("%s")' % n)
                if mode == 'all':
                    changed_all += 1; cross_all += cross
                else:
                    changed_kill += 1; cross_kill += cross
                    if cross: check(how == 'verified', f'killable: cross-faction pick {n} > {rep} only as a verified pair ({how})')
print(f'   Zordoom picks: all = {changed_all}/{total} changed, {cross_all} of another faction | killable = {changed_kill}/{total} changed, {cross_kill} of another faction')
check(cross_all > 0, 'all (v0.75): picks other factions at Nefarious spawners (the round-63 softlocks)')
check(cross_kill == 0, 'killable: no unproven other-faction pick on Zordoom')
check(changed_kill >= total * 0.6, f'killable: most Zordoom spawners still change ({changed_kill} of {total})')

# a Nefarious swarmer factory: killable picks a Nefarious kind
lua, LOG, SAID = make('killable'); setup_level(lua)
r = pick(lua, 3, 'E97360750F5B57C6')
check(r.split('|')[0].startswith('enm_neo_nefarious_'), f'warden office factory E97360750F5B57C6 (Nefarious swarmer) -> {r}')
# a wildlife spawner (sandshark): another creature, never a trooper
r = pick(lua, 17, '8A8A37B53D249CD9')
check(r.split('|')[0].startswith('enm_indigenous_'), f'sandshark factory -> another creature ({r})')
# enemy_cross_faction = true: one trial per level, watched
lua, LOG, SAID = make('killable', 'true'); setup_level(lua)
r = lua.eval('''(function()
  local V = RANDO_SPAWNERS.V
  local T = V.lvl.tpl[8]                         -- thugs4less melee: no other Goon walker but the shooter
  local r = { kind = "factory", key = "X1", orig = { single = true, actors = 8, uid = T.uid } }
  local rep = V.tpl and nil
  local ok1, how1 = V.compat_allows(r, V.lvl.tpl[13])       -- an amoeboid for a Goon: unproven other faction
  return tostring(ok1) .. "|" .. tostring(how1) end)()''')
check(r == 'true|trial', f'enemy_cross_faction = true: another faction is a watched TRIAL ({r})')
lua, LOG, SAID = make('killable', 'false'); setup_level(lua)
r = lua.eval('''(function() local V = RANDO_SPAWNERS.V
  local r = { kind = "factory", key = "X1", orig = { single = true, actors = 8, uid = "U08" } }
  local ok, how, why = V.compat_allows(r, V.lvl.tpl[13]); return tostring(ok) .. "|" .. tostring(why) end)()''')
check(r == 'false|cross', f'enemy_cross_faction = false (default): another faction stays out ({r})')

# ---- 3. the round-63 log replayed: every CHANGED pair under "killable" ----------------------------------------------
if LOGFILE and os.path.exists(LOGFILE):
    lua, LOG, SAID = make('killable')
    text = open(LOGFILE, encoding='utf-8', errors='replace').read()
    pat = re.compile(r'COMBAT (factory\|[^:]*): replaced bots spawned (\d+), died (\d+)')
    seen = {}
    for m in pat.finditer(text):
        p, s, d = m.group(1), int(m.group(2)), int(m.group(3))
        a = seen.setdefault(p, [0, 0]); a[0] += s; a[1] += d
    for m in re.finditer(r'COMBAT VERIFIED (factory\|\S+?):', text):
        a = seen.setdefault(m.group(1), [0, 0])
        if 'killed: gone' not in text[m.end():m.end() + 120].split('\n')[0]: a[1] = max(a[1], 1)
    killed_ok, blocked_bad = 0, 0
    for p, (s, d) in sorted(seen.items()):
        kin = lua.eval('RANDO_SPAWNERS.V.pair_kin("%s")' % p)
        st = lua.eval('(RANDO_SPAWNERS.V.compat_status("%s"))' % p)
        allowed = kin or st == 'verified'
        if d > 0: killed_ok += 1; check(allowed, f'round63 pair that died stays allowed: {p} ({d}/{s})')
        else: blocked_bad += 1; check(not allowed, f'round63 pair never killed is not used: {p} (0/{s})')
    check(killed_ok >= 8 and blocked_bad >= 8, f'round63: {killed_ok} killed pairs kept, {blocked_bad} never-killed pairs out')
    hd = re.findall(r'DEATH \d+ \| (\S+) replacing (\S+) \|.*\| killed: gone (\d+) s', text)
    check(len(hd) >= 30, f'round63: {len(hd)} "killed: gone" verdicts in the log (the horned toads)')
else:
    print('   (round-63 log not given: replay skipped)')

# ---- 4. the reload strike ------------------------------------------------------------------------------------------
lua, LOG, SAID = make('killable'); setup_level(lua)
lua.execute('''
local V = RANDO_SPAWNERS.V
RANDO_SPAWNERS.frame = 60 * 100
V.enabled = function() return true end
V.reset = function() end
V.put_back = function(A) A.restored = true end
PK = "factory|enm_neo_nefarious_s/swarmer>enm_neo_nefarious_h/swarmer"      -- kin, not verified
PV = "factory|enm_neo_nefarious_s/swarmer>enm_neo_nefarious_m/swarmer"      -- verified (built-in, round 63)
A1 = { rec = { key = "K1" }, pairs = { PK }, spawns = 1, alive = { [11] = true }, alive_n = 1 }
A2 = { rec = { key = "K2" }, pairs = { PV }, spawns = 1, alive = { [12] = true }, alive_n = 1 }
V.lvl.arms = { A1, A2 }
V.lvl.spawned[11] = { A = A1, T = V.lvl.tpl[4], frame = 60 * 40, pairs = { PK }, orig = "enm_neo_nefarious_swarmer" }
V.lvl.spawned[12] = { A = A2, T = V.lvl.tpl[2], frame = 60 * 40, pairs = { PV }, orig = "enm_neo_nefarious_swarmer" }
V.lvl.watch = { 11, 12 }
V.combat_c(PK).spawned = 1; V.combat_c(PV).spawned = 1
V.on_checkpoint({ loaded = true })
''')
st1 = lua.eval('(RANDO_SPAWNERS.V.compat_status(PK))')
saved1 = lua.eval('RANDO.state.enemy_combat[PK]')
check(st1 == 'rejected' and saved1 == 'suspect:1', f'reload strike 1: kin pair never killed in 60 s -> rejected this session, {saved1} in the save')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PV))') == 'verified', 'reload strike: a verified pair is never struck')
check(any('never killed before the reload' in s for s in SAID) and len(SAID) == 1, f'reload strike: one note on screen ({len(SAID)})')
# second session strike -> bad for the save
lua.execute('''local V = RANDO_SPAWNERS.V
V.session.compat_bad = {}; V.lvl.combat = {}
V.lvl.spawned[11].failed = nil
A1.restored = nil
V.combat_c(PK).spawned = 1
V.on_checkpoint({ loaded = true })''')
check(str(lua.eval('RANDO.state.enemy_combat[PK]')).startswith('bad:'), 'reload strike 2: rejected for the save')
# young bot (10 s) -> no strike
lua, LOG, SAID = make('killable'); setup_level(lua)
lua.execute('''local V = RANDO_SPAWNERS.V
RANDO_SPAWNERS.frame = 60 * 100; V.enabled = function() return true end; V.reset = function() end
V.put_back = function(A) A.restored = true end
PK = "factory|enm_neo_nefarious_s/swarmer>enm_neo_nefarious_h/swarmer"
A1 = { rec = { key = "K1" }, pairs = { PK }, spawns = 1, alive = { [11] = true }, alive_n = 1 }
V.lvl.arms = { A1 }
V.lvl.spawned[11] = { A = A1, T = V.lvl.tpl[4], frame = 60 * 90, pairs = { PK } }
V.lvl.watch = { 11 }
V.on_checkpoint({ loaded = true })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PK))') == 'unverified', 'reload strike: a bot 10 s old is not struck')
lua.execute('''local V = RANDO_SPAWNERS.V
V.lvl.spawned[11].frame = 60 * 70; A1.restored = nil
V.on_checkpoint({ loaded = true })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PK))') == 'unverified', 'reload strike: a same-faction bot 30 s old is not struck (a hard fight is no proof)')
lua.execute('''local V = RANDO_SPAWNERS.V
PC = "factory|enm_neo_nefarious_s/swarmer>enm_amoeboid_large_/ground"
V.lvl.spawned[13] = { A = A1, T = V.lvl.tpl[15], frame = 60 * 80, pairs = { PC } }
V.lvl.watch = { 11, 13 }; A1.restored = nil
V.on_checkpoint({ loaded = true })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PC))') == 'rejected', 'reload strike: an other-faction trial 20 s old is struck')
# one of the pair already killed on the level -> no strike
lua.execute('''local V = RANDO_SPAWNERS.V
V.lvl.spawned[11].frame = 0; V.combat_c(PK).died = 1; A1.restored = nil
V.on_checkpoint({ loaded = true })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PK))') == 'unverified', 'reload strike: a pair already killed here is not struck')

# ---- 5. a rejection the game disproves -----------------------------------------------------------------------------
lua, LOG, SAID = make('killable'); setup_level(lua)
lua.execute('''local V = RANDO_SPAWNERS.V
V.put_back = function(A) A.restored = true end
P1 = "factory|enm_neo_nefarious_x/flyer>enm_neo_nefarious_g/flyer"
P2 = "factory|enm_neo_nefarious_y/flyer>enm_neo_nefarious_g/flyer"
V.combat_reject({ P1 }, "alive 45 s", "x"); V.combat_reject({ P2 }, "alive 45 s", "x")
BAN1 = RANDO.state.enemy_combat["rep|enm_neo_nefarious_g/flyer"]
V.combat_died(5, { pairs = { P2 }, T = V.lvl.tpl[6], frame = 0 })''')
check(str(lua.eval('BAN1')).startswith('bad:'), 'grenadier banned after 2 rejections (as in round 63)')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(P2))') == 'verified', 'its later death reverses the rejection (COMBAT CHECK REVERSED)')
ban2 = lua.eval('RANDO.state.enemy_combat["rep|enm_neo_nefarious_g/flyer"]')
check(ban2 is not None and not str(ban2).startswith('bad:'), f'... and lifts the replacement ban ({ban2})')
check(any('COMBAT CHECK REVERSED' in l for l in LOG) and any('REPLACEMENT BAN LIFTED' in l for l in LOG), 'reversal logged')
# a built-in "bad" pair is never reversed by a death
lua.execute('''local V = RANDO_SPAWNERS.V
PB = "factory|enm_pirate_bladebal/swarmer>enm_pirate_robot_sh/ground"
V.combat_died(6, { pairs = { PB }, frame = 0 })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PB))') == 'rejected', 'a built-in bad pair stays rejected')

# ---- 6. "gone" as proof ---------------------------------------------------------------------------------------------
lua, LOG, SAID = make('killable'); setup_level(lua)
lua.execute('''local V = RANDO_SPAWNERS.V
RANDO_SPAWNERS.frame = 60 * 100
V.lvl.deaths_seen, V.lvl.gone_seen = 0, 0
PX = "factory|enm_neo_nefarious_q/swarmer>enm_indigenous_horn/swarmer"   -- another faction
PY = "factory|enm_neo_nefarious_q/swarmer>enm_neo_nefarious_h/swarmer"   -- kin
PZ = "factory|enm_neo_nefarious_r/swarmer>enm_neo_nefarious_h/swarmer"   -- kin
V.combat_gone(1, { pairs = { PX }, frame = 60 * 90 })
V.combat_gone(2, { pairs = { PY }, frame = 60 * 99 })
V.combat_gone(3, { pairs = { PZ }, frame = 60 * 90 })''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PX))') == 'unverified', 'gone: another faction vanishing is no kill')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PY))') == 'unverified', 'gone 1 s after spawning is no kill')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PZ))') == 'verified', 'gone 10 s after spawning (same faction) still counts as killed')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status("factory|enm_neo_nefarious_s/swarmer>enm_indigenous_horn/swarmer"))') == 'rejected',
      'round-63 horned toad pair is rejected by the built-in table (it was "verified" by vanishing)')

# ---- 7. the save migration -------------------------------------------------------------------------------------------
lua, LOG, SAID = make('killable', state='''{ enemy_combat = {
  ["factory|enm_neo_nefarious_h/flyer>enm_neo_nefarious_g/flyer"] = "bad:alive 46 s",
  ["factory|enm_neo_nefarious_s/flyer>enm_neo_nefarious_g/flyer"] = "bad:alive 45 s",
  ["rep|enm_neo_nefarious_g/flyer"] = "bad:could not be killed replacing enm_neo_nefarious_h/flyer, enm_neo_nefarious_s/flyer" },
  spawn_blocked = { ["v:D1EE6234A611F90E"] = "the checkpoint was loaded 5 times while it ran", ["v:KEEP"] = "story" } }''')
lua.execute('RANDO_SPAWNERS.V.migrate()')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status("factory|enm_neo_nefarious_h/flyer>enm_neo_nefarious_g/flyer"))') == 'verified',
      'migration: round 63\'s wrongly rejected grenadier pair is verified again')
check(lua.eval('RANDO.state.enemy_combat["rep|enm_neo_nefarious_g/flyer"]') is None, 'migration: the grenadier ban is lifted')
check(lua.eval('RANDO.state.spawn_blocked["v:D1EE6234A611F90E"]') is None and lua.eval('RANDO.state.spawn_blocked["v:KEEP"]') == 'story',
      'migration: encounters kept original after retries are randomized again (other blocks stay)')
check(lua.eval('RANDO.state.enemy_mig_076') is True, 'migration: done once per save')

# ---- 8. the flyer watch time ----------------------------------------------------------------------------------------
lua, LOG, SAID = make('killable'); setup_level(lua)
lua.execute('''local V = RANDO_SPAWNERS.V
RANDO_SPAWNERS.frame = 60 * 60
V.presence = function() return "alive" end
V.put_back = function(A) A.restored = true end
V.lvl.deaths_seen, V.lvl.gone_seen, V.lvl.last_death = 20, 0, 60 * 59
PF = "factory|enm_neo_nefarious_v/flyer>enm_neo_nefarious_s/flyer"
V.lvl.spawned[21] = { T = V.lvl.tpl[5], frame = 0, deaths0 = 0, pairs = { PF } }
V.lvl.watch = { 21 }
V.combat_watch()''')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PF))') == 'unverified', 'flyer alive 60 s while 20 died: not rejected yet (90 s for flyers)')
lua.execute('RANDO_SPAWNERS.frame = 60 * 95; RANDO_SPAWNERS.V.combat_watch()')
check(lua.eval('(RANDO_SPAWNERS.V.compat_status(PF))') == 'rejected', 'flyer alive 95 s while 20 died: rejected')

# ---- 9. every script loads together (Lua 5.4) -------------------------------------------------------------------------
lua = LuaRuntime(unpack_returned_tuples=True)
errs = []
for f in sorted(os.listdir(os.path.join(KIT, 'scripts'))):
    if f.endswith('.lua'):
        ok = lua.eval('function(s, n) local f, e = load(s, n); return f ~= nil, e end')(open(os.path.join(KIT, 'scripts', f), encoding='utf-8').read(), f)
        if not ok[0]: errs.append(f + ': ' + str(ok[1]))
check(not errs, 'every script compiles: ' + ('; '.join(errs) if errs else 'ok'))

print('FAILURES', fails); sys.exit(1 if fails else 0)
