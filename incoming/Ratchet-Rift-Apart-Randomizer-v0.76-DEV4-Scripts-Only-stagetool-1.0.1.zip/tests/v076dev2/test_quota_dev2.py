# v0.76-DEV2 generator: the weapon quota (weapon_quota_missions / weapon_quota_collectibles / weapon_quota_shop).
#   quotas 0  -> every seed exactly as DEV1 (same fingerprint, same placements)
#   defaults  -> valid seeds (audit clean); every planet meets its quota where the pool allows, shortfalls are in the notes
# Run from the kit folder:  python tests/v076dev2/test_quota_dev2.py . <DEV1 kit folder>
import sys, os
from lupa import LuaRuntime
NEW = sys.argv[1]
OLD = sys.argv[2] if len(sys.argv) > 2 else None
def runtime(kit):
    lua = LuaRuntime(unpack_returned_tuples=True)
    lua.execute('rivet = { log = function() end }')
    for f in ('01_rando_data.lua', '02_rando_generator.lua', '03_rando_campaign.lua'):
        lua.execute(open(os.path.join(kit, 'scripts', f), encoding='utf-8').read())
    lua.execute('''
function GEN_ONE(seed, opts)
  local s, err = RANDO_GEN.generate(seed, opts, nil, nil)
  if not s then return { err = tostring(err) } end
  local items = {}
  for _, lid in ipairs(RANDO_GEN.sorted_keys(s.locations)) do items[#items + 1] = lid .. "=" .. tostring(s.locations[lid].item) end
  local probs = RANDO_GEN.audit(s)
  local q = {}
  for pid, r in pairs(s.quota_report or {}) do q[#q + 1] = string.format("%s:%d/%d:%d/%d", pid, r.missions[1], r.missions[2], r.collectibles[1], r.collectibles[2]) end
  table.sort(q)
  local shared = 0
  for _ in pairs(s.quota_shared or {}) do shared = shared + 1 end
  local open = 0
  for _ in pairs(s.shop.slots or {}) do open = open + 1 end
  return { fp = s.fingerprint, items = table.concat(items, ";"), problems = table.concat(probs or {}, " | "),
           quota = table.concat(q, " "), shared = shared, open = open, notes = table.concat(s.warnings or {}, " | "),
           spoiler = RANDO_GEN.spoiler(s) }
end''')
    return lua
new = runtime(NEW)
old = runtime(OLD) if OLD else None
fails = 0
def check(c, m):
    global fails
    if not c: fails += 1; print('FAIL', m)
gen = lambda L, seed, o: L.eval('function(s, o) return GEN_ONE(s, o) end')(seed, L.eval(o))
DEV = 'distribution = "goldbolts_first", omega_early = true, start_omega = 0, travel_lock = true, weapon_xp = true, collectibles = true'
# 1. quotas off = DEV1's seeds
if old:
    for v in ['{ %s, weapon_quota_missions = 0, weapon_quota_collectibles = 0 }' % DEV, '{ weapon_quota_missions = 0, weapon_quota_collectibles = 0 }']:
        for i in range(15):
            seed = f'dev2-q0-{i}'
            a = gen(new, seed, v)
            b = gen(old, seed, v.replace(', weapon_quota_missions = 0, weapon_quota_collectibles = 0', '').replace('weapon_quota_missions = 0, weapon_quota_collectibles = 0', ''))
            check(a['err'] is None and b['err'] is None, f'{v} {seed}: generated {a["err"]} {b["err"]}')
            if a['err'] or b['err']: continue
            check(a['fp'] == b['fp'] and a['items'] == b['items'], f'{v} {seed}: quotas 0 = the same seed as DEV1')
# 2. defaults: valid, quota met as far as the pool allows
met = tot = 0
shared_counts, open_counts = [], []
for v in ['{ %s }' % DEV, '{ }', '{ distribution = "spread" }', '{ %s, weapon_quota_shop = "close" }' % DEV,
          '{ %s, weapon_quota_shop = "off" }' % DEV, '{ %s, shop_weapons = 0 }' % DEV, '{ %s, start_omega = 1 }' % DEV.replace(', start_omega = 0', '')]:
    vm = mt = 0
    for i in range(25):
        seed = f'dev2-quota-{i}'
        a = gen(new, seed, v)
        check(a['err'] is None, f'{v} {seed}: generated {a["err"]}')
        if a['err']: continue
        check(a['problems'] == '', f'{v} {seed}: audit {a["problems"]}')
        for part in a['quota'].split():
            pid, m, c = part.split(':')
            mh, mn = map(int, m.split('/')); ch, cn = map(int, c.split('/'))
            tot += 2; mt += 2
            if mh >= mn: met += 1; vm += 1
            if ch >= cn: met += 1; vm += 1
            if 'weapon_quota_shop = "off"' not in v and 'start_omega = 1' not in v:
                check(mh >= mn and ch >= cn, f'{v} {seed}: {pid} quota met ({part}) notes: {a["notes"][:300]}')
            if 'start_omega = 1' in v:
                check((mn - mh) + (cn - ch) <= 1, f'{v} {seed}: start_omega = 1 leaves at most one place short ({part})')
                if mh < mn or ch < cn: check('weapon quota: ' + pid in a['notes'], f'{v} {seed}: the shortfall is in the notes')
        if v == '{ %s }' % DEV: shared_counts.append(a['shared']); open_counts.append(a['open'])
        if 'close' in v: check(a['shared'] == 0, f'{v} {seed}: close mode shares nothing')
        check('WEAPON QUOTA' in a['spoiler'], f'{v} {seed}: spoiler has the quota section')
    print(f'{v}: quota groups met {vm}/{mt}')
print('dev settings: shared with the shop min/avg/max', min(shared_counts), sum(shared_counts) / len(shared_counts), max(shared_counts),
      '| open shop slots', min(open_counts), max(open_counts))
print('FAILURES', fails)
sys.exit(1 if fails else 0)
