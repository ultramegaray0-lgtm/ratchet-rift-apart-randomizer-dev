# v0.76-DEV2 WEAPON XP GAIN (weapon_xp_gain): the XP a held weapon EARNS is multiplied; the randomizer's own XP rewards
# never are; a load that takes XP back only moves the baseline; "random" / "random_each" are fixed by the seed.
# Run from the kit folder:  python tests/v076dev2/test_xpgain_dev2.py .
import sys, os, struct
sys.argv = [sys.argv[0], sys.argv[1]]
KIT = sys.argv[1]
sys.path.insert(0, os.path.join(KIT, 'tests', 'dev8'))
from lupa import LuaRuntime
MEM = {}; LOG = []
def put(a, bs):
    for i, b in enumerate(bs): MEM[a + i] = b
def py_read(addr, n):
    a = int(str(addr), 16); out = []
    for i in range(int(n)):
        if a + i not in MEM: break
        out.append('%02X' % MEM[a + i])
    return ' '.join(out) if out else None
def py_write(addr, text):
    a = int(str(addr), 16); put(a, [int(x, 16) for x in str(text).split()]); return True
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1
BASE = 0x20000000
def setup(gain, recs):
    MEM.clear(); LOG.clear()
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals(); g.py_read, g.py_write = py_read, py_write
    g.py_log = lambda *a: LOG.append('\t'.join(str(x) for x in a))
    lua.execute('''rivet = { log = function(...) py_log(...) end, read = function(a, n) return py_read(a, n) end,
                           write = function(a, t) return py_write(a, t) end }''')
    for f in ('01_rando_data.lua', '02_rando_generator.lua'):
        lua.execute(open(os.path.join(KIT, 'scripts', f), encoding='utf-8').read())
    lua.execute('''
RANDO = { config = { weapon_xp_target = "smart", omega_runtime = true, weapon_xp_gain = %s, weapon_xp_gain_min = 2, weapon_xp_gain_max = 50 },
          state = { xp_pending = {}, xp_done = {}, omega = {} },
          mark_changed = function() end, say = function(t) py_log("SAY", t) end,
          item_name = function(k) return RANDO_GEN.item_name(k) end }
RANDO_SEED = { fingerprint = "abc123def456" }
-- the runtime's multiplier (10_rando_runtime.lua R.xp_gain_for), loaded from the real file below
''' % gain)
    # take R.xp_gain_for / R.xp_gain_active from the runtime file (the block between their markers)
    src = open(os.path.join(KIT, 'scripts', '10_rando_runtime.lua'), encoding='utf-8').read()
    a = src.index('R.xp_gain_cache = {}'); b = src.index('function R.xp_gain_text()')
    block = src[a:b].replace('R.', 'RANDO.').replace('SEED and SEED.fingerprint', 'RANDO_SEED and RANDO_SEED.fingerprint')
    lua.execute('local GEN = RANDO_GEN\n' + block)
    lua.execute(open(os.path.join(KIT, 'scripts', '17_rando_omega.lua'), encoding='utf-8').read())
    ids = lua.eval('(function() local t = {} for w, id in pairs(RANDO_OMEGA.ID_OF) do t[w] = id end return t end)()')
    lua.execute('RANDO_OMEGA.inv = { route = "type data", hero_owned = true, records = {} }; RANDO_OMEGA.ddl_layout = { live = true, verified = true, id = 0, omega = 136 }')
    for i, (w, slot, xp) in enumerate(recs):
        a = BASE + i * 0x200
        put(a, [0] * 0x100)
        put(a, list(bytes.fromhex(ids[w]))[::-1])
        put(a + 8, list(struct.pack('<I', 1))); put(a + 12, list(struct.pack('<I', slot))); put(a + 16, list(struct.pack('<I', xp)))
        put(a + 20, list(struct.pack('<f', 10.0))); put(a + 24, list(struct.pack('<f', 10.0)))
        lua.execute('RANDO_OMEGA.inv.records["%s"] = { id_at = %d }' % (w, a))
    return lua
def xp_of(i): return struct.unpack('<I', bytes(MEM[BASE + i * 0x200 + 16 + k] for k in range(4)))[0]
def set_xp(i, v): put(BASE + i * 0x200 + 16, list(struct.pack('<I', v)))
def run(lua, fn='xp_gain_pass'):
    lua.execute('local co = coroutine.create(RANDO_OMEGA.%s); while coroutine.status(co) ~= "dead" do local ok, e = coroutine.resume(co); assert(ok, e) end' % fn)
R = [('enforcer', 1001, 15000), ('cold_snap', 1002, 2000), ('negatron_collider', 5015, 0)]
lua = setup('20', R)
run(lua)
check(xp_of(0) == 15000 and xp_of(1) == 2000, 'first read: a baseline, nothing written')
set_xp(0, 15100)                                  # a kill: +100
run(lua)
check(xp_of(0) == 15000 + 100 * 20, f'x20: +100 earned -> +2000 ({xp_of(0)})')
run(lua)
check(xp_of(0) == 17000, 'nothing earned since: nothing written (the write is the new baseline)')
check(xp_of(2) == 0, 'an empty slot (weapon not held) is never written')
# an XP reward is never multiplied
lua.execute('RANDO.state.xp_pending["goldbolt:3"] = 5000')
run(lua, 'xp_pass')
after_reward = max(xp_of(0), xp_of(1))
run(lua)
check(max(xp_of(0), xp_of(1)) == after_reward, 'an XP reward (5000) is not multiplied by the gain')
# a checkpoint load takes XP back: only the baseline moves
set_xp(1, 1500); run(lua)
check(xp_of(1) == 1500, 'a load that takes XP back: nothing written')
set_xp(1, 1510); run(lua)
check(xp_of(1) == 1500 + 10 * 20, 'after it, the next kill is multiplied from the new baseline')
# a huge jump (not a kill) is only taken as the baseline
set_xp(0, xp_of(0) + 900000); before = xp_of(0); run(lua)
check(xp_of(0) == before, 'a jump bigger than O.XPG_MAX_STEP is not multiplied')
# below 1 takes some back, never below the last read
lua = setup('0.5', R); run(lua); set_xp(0, 15200); run(lua)
check(xp_of(0) == 15100, f'x0.5: +200 earned -> +100 kept ({xp_of(0)})')
# 1 = off
lua = setup('1', R)
check(lua.eval('RANDO.xp_gain_active()') is False, 'x1: the gain is off')
# random: one multiplier per seed, inside the range, stable
lua = setup('"random"', R)
m1, m2 = lua.eval('RANDO.xp_gain_for("enforcer")'), lua.eval('RANDO.xp_gain_for("cold_snap")')
check(m1 == m2 and 2 <= m1 <= 50, f'random: one multiplier for the seed ({m1})')
lua = setup('"random_each"', R)
ms = {w: lua.eval('RANDO.xp_gain_for("%s")' % w) for w in ('enforcer', 'cold_snap', 'ryno_8', 'bombardier', 'headhunter')}
check(all(2 <= v <= 50 for v in ms.values()) and len(set(ms.values())) > 1, f'random_each: each weapon its own ({ms})')
check(lua.eval('RANDO.xp_gain_for("enforcer")') == ms['enforcer'], 'random_each: the same weapon keeps its multiplier')
print('FAILURES', fails)
sys.exit(1 if fails else 0)
