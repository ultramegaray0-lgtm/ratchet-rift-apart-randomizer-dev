# v0.76-DEV2 Enemy Randomizer: kept over a checkpoint load, force (key B), the live note, Omega giving way.
# DEV1's rivet.log (Nefarious City): every story-step checkpoint load put back every change and forgot the level's
# enemy kinds; the courtyard fight ran with 1 kind known ("no other enemy kind known on this level", 0 of 5 replaced).
# A fake scene (script variables in memory) replays: changes made, a checkpoint load, the new level listed again.
# Run from the kit folder:  python tests/v076dev2/test_enemy_dev2.py .
import sys, os
from lupa import LuaRuntime
KIT = sys.argv[1]
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1

MEM = {}
def put(a, bs):
    for i, b in enumerate(bs): MEM[a + i] = b
def py_read(addr, n):
    a = int(str(addr), 16); out = []
    for i in range(int(n)):
        if a + i not in MEM: break
        out.append('%02X' % MEM[a + i])
    return ' '.join(out) if out else None
def py_write(addr, text):
    a = int(str(addr), 16)
    put(a, [int(x, 16) for x in str(text).split()])
    return True

BASE, VS = 0x10000000, 0x40
def set_var(idx, uid_hex, actors, gen=1, typ=5):
    a = BASE + idx * VS
    put(a, [0] * VS)
    put(a, list(bytes.fromhex(uid_hex))[::-1])
    put(a + 0x10, list(actors.to_bytes(4, 'little')))
    put(a + 0x34, list(typ.to_bytes(2, 'little')))
    put(a + 0x36, list(gen.to_bytes(2, 'little')))
def get_var(idx):
    a = BASE + idx * VS
    uid = ''.join('%02X' % MEM[a + i] for i in range(7, -1, -1))
    act = int.from_bytes(bytes(MEM[a + 0x10 + i] for i in range(4)), 'little')
    return uid, act

def make():
    MEM.clear()
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals(); LOG = []; SAID = []
    g.py_log = lambda *a: LOG.append('\t'.join(str(x) for x in a))
    g.py_say = lambda t, *a: SAID.append(str(t))
    g.py_read, g.py_write = py_read, py_write
    lua.execute('rivet = setmetatable({ log = function(...) py_log(...) end, read = function(a, n) return py_read(a, n) end, '
                'write = function(a, t) return py_write(a, t) end }, { __index = function() return function() return nil end end })')
    for f in ('01_rando_data.lua', '02_rando_generator.lua'):
        lua.execute(open(os.path.join(KIT, 'scripts', f), encoding='utf-8').read())
    lua.execute('RANDO = { config = { enemy_compat = "killable", enemy_randomizer = true }, state = { enemy_combat = {} }, '
                'mark_changed = function() end, say = function(t) py_say(t) end, subscribe = function() end }')
    lua.execute(open(os.path.join(KIT, 'scripts', '16_rando_spawners.lua'), encoding='utf-8').read())
    lua.execute('''
local V = RANDO_SPAWNERS.V
SC = { base = %d, max = 64 }
V.scene = function() return SC end
V.enabled = function() return true end
V.role_on = function() return true end
RANDO_SPAWNERS.frame = 100
''' % BASE)
    return lua, LOG, SAID

# three Nefarious kinds, three factories (vars 1..3), template handles 11/12/13 with uids
KINDS = [('enm_neo_nefarious_shooter', 'ground', 11, '00000000000000B1'),
         ('enm_neo_nefarious_melee', 'swarmer', 12, '00000000000000B2'),
         ('enm_neo_nefarious_swarmer', 'swarmer', 13, '00000000000000B3')]
def level(lua, label, fresh=True):
    lua.execute('''
local V = RANDO_SPAWNERS.V
if %s then V.new_level("%s") end
V.lvl.scans = 1
for i = 1, 3 do
  local r = { kind = "factory", actor = 900 + i, key = "F" .. i, var = { idx = i, gen = 1 } }
  V.add_rec(r)
end
''' % ('true' if fresh else 'false', label))
def learn_kinds(lua):
    for n, fam, h, uid in KINDS:
        lua.execute('''local V = RANDO_SPAWNERS.V
local T = V.tpl_of(%d, "%s"); T.name, T.family, T.class = "%s", "%s", "x"; T.role = V.role_of(T)''' % (h, uid, n, fam))

lua, LOG, SAID = make()
for i, (n, fam, h, uid) in enumerate(KINDS):
    set_var(i + 1, uid, h)
level(lua, 'planet NefCity')
lua.execute('''local V = RANDO_SPAWNERS.V
for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end''')
learn_kinds(lua)
lua.execute('''local V = RANDO_SPAWNERS.V
for _, r in ipairs(V.lvl.order) do V.plan_rec(SC, r) end''')
n_arms = lua.eval('#RANDO_SPAWNERS.V.lvl.arms')
check(n_arms >= 2, f'before the load: {n_arms} factories changed (Nefarious for Nefarious)')
written = {i: get_var(i) for i in (1, 2, 3)}
# the checkpoint load (the game keeps the scene: variables and template handles stay)
lua.execute('RANDO_SPAWNERS.V.on_checkpoint({ loaded = true })')
after = {i: get_var(i) for i in (1, 2, 3)}
check(after == written, 'checkpoint load: kept changes are NOT put back (no window with the originals)')
check(any('change(s) and' in l and 'kept until' in l for l in LOG), 'checkpoint load: the carry is logged')
level(lua, 'after the checkpoint', False)
lua.execute('''local V = RANDO_SPAWNERS.V
for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end''')
kept = lua.eval('RANDO_SPAWNERS.V.lvl.kept or 0')
check(kept == n_arms, f'after the load: {kept} of {n_arms} changes resumed without a write')
origs_ok = lua.eval('''(function() local V = RANDO_SPAWNERS.V
  for i, r in ipairs(V.lvl.order) do if not (r.orig and r.orig.actors == 10 + i) then return false end end return true end)()''')
check(origs_ok, 'after the load: every spawner knows its TRUE original (not the replacement it held)')
kinds = lua.eval('(function() local n = 0 for _, T in pairs(RANDO_SPAWNERS.V.lvl.tpl) do if RANDO_SPAWNERS.V.usable(T) then n = n + 1 end end return n end)()')
check(kinds == 3, f'after the load: the 3 enemy kinds are known again at once ({kinds})')
# leaving: everything resumed is put back by the normal path
lua.execute('RANDO_SPAWNERS.V.put_back_all("leaving NefCity")')
check({i: get_var(i) for i in (1, 2, 3)} == {i + 1: (KINDS[i][3], KINDS[i][2]) for i in range(3)}, 'resumed changes are put back like any other')

# a load that REBUILT the scene: variables back at their originals, new template handles -> nothing old used
lua, LOG, SAID = make()
for i, (n, fam, h, uid) in enumerate(KINDS): set_var(i + 1, uid, h)
level(lua, 'planet NefCity')
lua.execute('local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end')
learn_kinds(lua)
lua.execute('local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.plan_rec(SC, r) end')
lua.execute('RANDO_SPAWNERS.V.on_checkpoint({ loaded = true })')
for i, (n, fam, h, uid) in enumerate(KINDS): set_var(i + 1, 'C' + uid[1:], h + 100)     # rebuilt: new uids and handles
level(lua, 'rebuilt', False)
lua.execute('local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end')
check(lua.eval('RANDO_SPAWNERS.V.lvl.kept or 0') == 0, 'rebuilt scene: no change is resumed')
check(lua.eval('RANDO_SPAWNERS.V.lvl.carry.ok') is None, 'rebuilt scene: the old kinds are NOT used (no proof)')
lua.execute('RANDO_SPAWNERS.V.lvl.scans = 5; RANDO_SPAWNERS.V.list_nodes_off = true')
lua.execute('''local V = RANDO_SPAWNERS.V
local s = V.lvl.carry
if s and not s.ok and V.lvl.scans > V.CARRY_SCANS and not s.expired then s.expired = true; V.put_back_carry(s, "test") end''')
check({i: get_var(i) for i in (1, 2, 3)} == {i + 1: ('C' + KINDS[i][3][1:], KINDS[i][2] + 100) for i in range(3)},
      'rebuilt scene: variables the game reset are never written')

# FORCE (key B): spawners planned again, the listing at once, a note after it
lua, LOG, SAID = make()
for i, (n, fam, h, uid) in enumerate(KINDS): set_var(i + 1, uid, h)
level(lua, 'planet NefCity')
lua.execute('local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.read_one_orig(SC, r) end')
# only one kind known: nothing can change
lua.execute('''local V = RANDO_SPAWNERS.V
local T = V.tpl_of(11, "00000000000000B1"); T.name, T.family = "enm_neo_nefarious_shooter", "ground"; T.role = V.role_of(T)
V.lvl.tpl[12], V.lvl.tpl[13] = nil, nil
for _, r in ipairs(V.lvl.order) do V.plan_rec(SC, r) end''')
check(lua.eval('#RANDO_SPAWNERS.V.lvl.arms') == 0, 'one kind known: nothing changed (DEV1 courtyard)')
check(lua.eval('RANDO_SPAWNERS.V.lvl.starved') is True, 'a pick with no other kind asks for the save\'s kinds again soon')
learn_kinds(lua)
n = lua.eval('RANDO_SPAWNERS.V.force("B")')
check(n >= 1 and lua.eval('RANDO_SPAWNERS.V.lvl.next_scan') == 100, f'force: {n} spawner(s) planned again, the listing is due now')
check(lua.eval('RANDO_SPAWNERS.V.lvl.reg_checked') is False, 'force: the save\'s enemy kinds are looked for again')
lua.execute('local V = RANDO_SPAWNERS.V; for _, r in ipairs(V.lvl.order) do V.plan_rec(SC, r) end')
check(lua.eval('#RANDO_SPAWNERS.V.lvl.arms') >= 2, 'force: once the kinds are there, the spawners change')
lua.execute('RANDO_SPAWNERS.frame = 400; RANDO_SPAWNERS.V.force_tick(400)')
check(any('forced' in s for s in SAID), 'force: a note says what it changed')
# busy flag for Omega
lua.execute('RANDO_SPAWNERS.V.lvl.queue = { { h = 1 } }')
check(lua.eval('RANDO_SPAWNERS.busy()') is True, 'busy while spawns wait (Omega gives way)')
lua.execute('RANDO_SPAWNERS.V.lvl.queue = {}; RANDO_SPAWNERS.V.job = nil')
check(lua.eval('RANDO_SPAWNERS.busy()') is False, 'not busy when idle')
# light status for the live note
st = lua.eval('RANDO_SPAWNERS.V.status(true)')
check(st['changed'] >= 2 and st['known'] == 0, 'light status: this level only (no registry walk)')
print('FAILURES', fails)
sys.exit(1 if fails else 0)
