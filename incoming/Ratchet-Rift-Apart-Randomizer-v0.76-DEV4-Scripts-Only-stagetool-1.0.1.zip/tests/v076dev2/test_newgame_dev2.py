# v0.76-DEV2 runtime: a New Game gets a NEW random seed (new_game_new_seed), the old save says superseded_by and a restore of
# it follows to the newer seed; weapon_xp_gain settings; a quota extra is paid with its location; a shared shop weapon bought
# first pays weapon XP instead. Loads every script of the kit with a stub rivet_hook and drives the frame callback.
# Run from the kit folder:  python tests/v076dev2/test_newgame_dev2.py .
import sys, os, glob
from lupa import LuaRuntime
KIT = sys.argv[1]
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1

def boot(settings):
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals(); LOG = []
    g.py_log = lambda *a: LOG.append('\t'.join(str(x) for x in a))
    lua.execute('''
CLOCK = 0
FRAMES, EVENTS, KEYS = {}, {}, {}
rivet = setmetatable({
  log = function(...) py_log(...) end,
  time = function() return CLOCK end,
  on_frame = function(fn) FRAMES[#FRAMES + 1] = fn; return true end,
  on_event = function(cls, fn) EVENTS[cls] = EVENTS[cls] or {}; table.insert(EVENTS[cls], fn); return true end,
  on_key = function(vk, fn) KEYS[vk] = fn; return true end,
  key = function(n) if n == "F6" then return 0x75 end return nil end,
  scene_ready = function() return true end,
  hero = function() return 1 end,
  notify = function(t) py_log("NOTIFY", t); return true end,
  read = function() return nil end,
  write = function() return false end,
}, { __index = function() return function() return nil end end })
function FIRE(cls, fields) for _, fn in ipairs(EVENTS[cls] or {}) do fn({ fields = fields }) end end
function STEP(n) for _ = 1, n do CLOCK = CLOCK + 1 / 60; for _, fn in ipairs(FRAMES) do fn(1 / 60) end end end
''')
    lua.execute('RANDO_SETTINGS = ' + settings)
    names = ['01_rando_data', '02_rando_generator', '03_rando_campaign', '05_rando_bindings', '06_rando_capabilities',
             '09_rando_real', '10_rando_runtime', '11_rando_campaign', '12_rando_shop', '13_rando_armor', '14_rando_travel',
             '15_rando_hub', '16_rando_spawners', '17_rando_omega', 'enemy', 'boss', 'chaos']
    for n in names:
        src = open(os.path.join(KIT, 'scripts', n + '.lua'), encoding='utf-8').read()
        lua.execute(src)
    return lua, LOG

lua, LOG = boot('{ seed = "random", preset = "balanced", weapon_xp_gain = "random", enemy_live_status = true }')
check(lua.eval('RANDO.config.weapon_xp_gain') == 'random', 'weapon_xp_gain = "random" is accepted')
check(lua.eval('RANDO.config.enemy_randomizer') is True, 'the Enemy Randomizer is ON by default')
# the companion hands a random seed; it is generated over the frames; no saved progress
first = lua.eval('rando_use_seed("first-seed-111")')
for _ in range(400):
    lua.execute('STEP(1)')
    if lua.eval('RANDO_SEED ~= nil'): break
check(lua.eval('RANDO_SEED and RANDO_SEED.seed') == 'first-seed-111', 'the companion\'s seed is generated')
lua.eval('rando_mark_restored()')
check(lua.eval('RANDO.state.started') is True, 'the first run starts')
fp1 = lua.eval('RANDO_SEED.fingerprint'); boot1 = lua.eval('RANDO.boot')
lua.execute('RANDO.state.enemy_reg = { X = "enm|ground||enemy" }; RANDO.state.planet_shuffle = true')
old_state = lua.eval('RANDO.state')
# New Game: the prologue's first cinematic objective
lua.execute('CLOCK = CLOCK + 100')
lua.execute('FIRE("ObjectiveStateChangedEvent", { MissionName = "MIS_INTRO", ObjectiveName = "OBJ_INTRO_PARADE_START_CINE", ObjectiveState = 1 })')
check(old_state['superseded_by'] is not None, f'the old seed\'s state says superseded_by ({old_state["superseded_by"]})')
check(lua.eval('RANDO.boot') != boot1, 'the status line gets a new boot (the companion re-reads it)')
# events during generation are kept and replayed
lua.execute('FIRE("PlanetChangedEvent", { NewPlanetName = "Malinon", OldPlanetName = "NefCity" })')
for _ in range(600):
    lua.execute('STEP(1)')
    if lua.eval('RANDO_SEED ~= nil and RANDO.state ~= nil and RANDO.state.started'): break
lua.execute('STEP(2)')
check(lua.eval('RANDO_SEED.seed') == old_state['superseded_by'], 'a NEW seed: ' + str(lua.eval('RANDO_SEED.seed')))
check(lua.eval('RANDO_SEED.fingerprint') != fp1, 'with its own fingerprint (its own save)')
check(lua.eval('RANDO.state.started') is True and lua.eval('RANDO.state.run') == 1, 'the new seed starts at once (run 1)')
check(lua.eval('RANDO.state.enemy_reg and RANDO.state.enemy_reg.X') is not None and lua.eval('RANDO.state.planet_shuffle') is True,
      'what a New Game keeps (enemy knowledge, planet shuffle switch) is kept')
check(lua.eval('RANDO.state.previous_seed') == 'first-seed-111', 'the new run remembers the seed before it')
check(any('replaying' in l for l in LOG), 'events during the generation are replayed')
check(any('NEW seed' in l for l in LOG), 'the screen says it is a NEW seed')
# the companion offering the OLD seed again is answered with the current one
check(lua.eval('rando_use_seed("first-seed-111")') == lua.eval('RANDO_SEED.seed'), 'rando_use_seed answers the current seed')
# a restore of a save that a New Game left behind follows the chain
lua2, LOG2 = boot('{ seed = "random", preset = "balanced" }')
lua2.eval('rando_use_seed("first-seed-111")')
for _ in range(400):
    lua2.execute('STEP(1)')
    if lua2.eval('RANDO_SEED ~= nil'): break
fp = lua2.eval('RANDO_SEED.fingerprint')
r = lua2.eval('rando_import_state({ fingerprint = "%s", seed = "first-seed-111", superseded_by = "lombax-rift-kit-777", run = 4 })' % fp)
for _ in range(400):
    lua2.execute('STEP(1)')
    if lua2.eval('RANDO_SEED ~= nil'): break
check(lua2.eval('RANDO_SEED and RANDO_SEED.seed') == 'lombax-rift-kit-777', 'a restored save marked superseded_by: the newer seed is followed')
check(lua2.eval('RANDO.restored') is False, '... and its own save is waited for (nothing handed out before it)')
# new_game_new_seed = false: the same seed starts over (as before)
lua3, LOG3 = boot('{ seed = "random", preset = "balanced", new_game_new_seed = false }')
lua3.eval('rando_use_seed("first-seed-111")')
for _ in range(400):
    lua3.execute('STEP(1)')
    if lua3.eval('RANDO_SEED ~= nil'): break
lua3.eval('rando_mark_restored()')
lua3.execute('CLOCK = CLOCK + 100')
lua3.execute('FIRE("ObjectiveStateChangedEvent", { MissionName = "MIS_INTRO", ObjectiveName = "OBJ_INTRO_PARADE_START_CINE", ObjectiveState = 1 })')
check(lua3.eval('RANDO_SEED.seed') == 'first-seed-111' and lua3.eval('RANDO.state.run') == 2, 'new_game_new_seed = false: the same seed, run 2')
# a fixed seed always starts over
lua4, LOG4 = boot('{ seed = "lombax-ryno-2026", preset = "balanced", weapon_xp_gain = 500 }')
check(lua4.eval('RANDO.config.weapon_xp_gain') == 20, 'weapon_xp_gain = 500 is refused (0-100), 20 kept')
print('FAILURES', fails)
sys.exit(1 if fails else 0)
