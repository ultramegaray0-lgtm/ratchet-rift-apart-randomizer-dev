v0.76-DEV2 offline tests (Python 3 + lupa: pip install lupa). Run from the kit folder:
  python tests/v076dev2/test_quota_dev2.py . [DEV1 kit folder]   weapon quota; with the DEV1 kit: quotas 0 = DEV1's seeds
  python tests/v076dev2/test_shop_dev2.py . [DEV1 kit folder]    the vendor search after a frame-budget cut (DEV1 stalls)
  python tests/v076dev2/test_enemy_dev2.py .                     kept over a checkpoint load, force (B), busy, live status
  python tests/v076dev2/test_xpgain_dev2.py .                    weapon_xp_gain (x20, random, rewards never multiplied)
  python tests/v076dev2/test_newgame_dev2.py .                   the whole kit loaded: a New Game makes a new random seed
  python tests/v076dev2/test_genbudget_dev2.py . [older kit]       the seed is made under rivet_hook's frame deadline (DEV3)
