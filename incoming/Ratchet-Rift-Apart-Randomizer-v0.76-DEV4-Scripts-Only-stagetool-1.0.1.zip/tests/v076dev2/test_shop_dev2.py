# v0.76-DEV2 shop: DEV1's rivet.log (line 273-274) - the frame budget cut the vendor's weapon-config lookups once and the
# vendor was never looked for again ("looking for the vendor" all session, Ms. Zurkon sold her usual weapons).
# Replays that with the shop harness: a budget error in the lookups (and one in the request itself) - the vendor must still
# be rewritten. With the DEV1 kit (second argument) the same run is shown to stall.
# Run from the kit folder:  python tests/v076dev2/test_shop_dev2.py . [DEV1 kit folder]
import sys, os, importlib
KIT = sys.argv[1]
OLD = sys.argv[2] if len(sys.argv) > 2 else None
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1
SETTINGS = '{ shop = "shuffle", shop_bonus = true, omega_weapons = true, include_arsenal_restored = true }'
BUDGET_IN_LOOKUP = r'''
local orig = RANDO_REAL.lookup_config
local n = 0
RANDO_REAL.lookup_config = function(id, cb)
  n = n + 1
  if n == 3 then error("scripts\\12_rando_shop.lua:190: ran past the 8 ms frame budget", 0) end
  return orig(id, cb)
end'''
BUDGET_IN_REQUEST = r'''
-- the request is cut after it counted a lookup that was never sent (what DEV1's log shows: no answer ever came)
local orig = RANDO_SHOP.request_pointers
local once = true
RANDO_SHOP.request_pointers = function(rr)
  orig(rr)
  if once then once = false; RANDO_SHOP.ptr_wait = RANDO_SHOP.ptr_wait + 1; error("ran past the 8 ms frame budget", 0) end
end'''
# DEV1's own code path: a budget error inside its request (before any lookup was counted) - it never looks again
OLD_INJECT = r'''
local orig = RANDO_GEN.sorted_keys
local once = true
RANDO_GEN.sorted_keys = function(t)
  if once and debug.traceback():find("request_pointers", 1, true) then once = false; error("ran past the 8 ms frame budget", 0) end
  return orig(t)
end'''
def run(kit, inject, frames=6000):
    sys.argv = [sys.argv[0], os.path.join(kit, 'scripts')]
    sys.path.insert(0, os.path.join(kit, 'docs'))
    import shop_harness as H
    importlib.reload(H)
    lua = H.build(SETTINGS)
    lua.execute(inject)
    H.run_frames(frames)
    sys.path.pop(0)
    return H
H = run(KIT, BUDGET_IN_LOOKUP)
check(len(H.WRITES) > 0, 'budget error inside a lookup: the vendor is still rewritten (%d writes)' % len(H.WRITES))
check(any('weapon configs in memory' in l or 'did not answer' in l for l in H.LOG), 'the lookups finish (or time out) after the error')
H = run(KIT, BUDGET_IN_REQUEST)
check(len(H.WRITES) > 0, 'budget error inside the request: the vendor is still rewritten (%d writes)' % len(H.WRITES))
check(any('asked again' in l for l in H.LOG), 'the interrupted request is asked again')
# checkpoint loads start a new round
H = run(KIT, '')
n0 = len(H.WRITES)
H.lua.execute('RANDO_SHOP.on_checkpoint_load()')
check(H.lua.eval('RANDO_SHOP.load_round()') == 2, 'a checkpoint load starts a new round of the vendor search')
if OLD:
    H = run(OLD, OLD_INJECT)
    print('INFO DEV1 kit with the same budget error: %d writes (0 = the stall of DEV1\'s log)' % len(H.WRITES))
print('FAILURES', fails)
sys.exit(1 if fails else 0)
