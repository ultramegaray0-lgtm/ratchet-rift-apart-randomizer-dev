# v0.76-DEV2 (round 65): the seed must be generated in-game even when rivet_hook's frame budget is tight. Round 65's New Game
# seed was generated during the parade and the 8 ms budget killed it 30 times (the weapon quota pass never yielded). This
# replays rivet_hook's deadline: a count hook every 10,000 instructions errors "ran past the 8 ms frame budget" once the frame
# callback has run longer than BUDGET (a few ms here: this PC is faster than a game frame's leftover).
# Run from the kit folder:  python tests/v076dev2/test_genbudget_dev2.py . [older kit folder to compare]
import sys, os
from lupa import LuaRuntime
KIT = sys.argv[1]
OTHER = sys.argv[2] if len(sys.argv) > 2 else None
BUDGET = float(os.environ.get('BUDGET_MS', '3')) / 1000
fails = 0
def check(c, m):
    global fails
    print(('PASS ' if c else 'FAIL ') + m)
    if not c: fails += 1
def boot(kit, settings):
    lua = LuaRuntime(unpack_returned_tuples=True)
    g = lua.globals(); LOG = []
    g.py_log = lambda *a: LOG.append('\t'.join(str(x) for x in a))
    lua.execute('''
CLOCK = 0
FRAMES, EVENTS = {}, {}
rivet = setmetatable({
  log = function(...) py_log(...) end, time = function() return CLOCK end,
  on_frame = function(fn) FRAMES[#FRAMES + 1] = fn; return true end,
  on_event = function(cls, fn) EVENTS[cls] = EVENTS[cls] or {}; table.insert(EVENTS[cls], fn); return true end,
  on_key = function() return true end, key = function(n) if n == "F6" then return 0x75 end end,
  scene_ready = function() return true end, hero = function() return 1 end,
  notify = function(t) py_log("NOTIFY", t); return true end, read = function() return nil end, write = function() return false end,
}, { __index = function() return function() return nil end end })
function FIRE(cls, fields) for _, fn in ipairs(EVENTS[cls] or {}) do fn({ fields = fields }) end end
-- rivet_hook's deadline: one per frame callback, checked every 10,000 instructions - in every coroutine too (src/scripting.cpp)
DEADLINE = nil
local function hook() if DEADLINE and os.clock() > DEADLINE then DEADLINE = nil; error("ran past the 8 ms frame budget", 0) end end
local create = coroutine.create
coroutine.create = function(f) local co = create(f); debug.sethook(co, hook, "", 10000); return co end
function STEP(n, budget)
  for _ = 1, n do
    CLOCK = CLOCK + 1 / 60
    for _, fn in ipairs(FRAMES) do
      DEADLINE = os.clock() + budget
      debug.sethook(hook, "", 10000)
      local ok, e = pcall(fn, 1 / 60)
      debug.sethook()
      DEADLINE = nil
    end
  end
end''')
    lua.execute('RANDO_SETTINGS = ' + settings)
    for n in ['01_rando_data', '02_rando_generator', '03_rando_campaign', '05_rando_bindings', '06_rando_capabilities', '09_rando_real',
              '10_rando_runtime', '11_rando_campaign', '12_rando_shop', '13_rando_armor', '14_rando_travel', '15_rando_hub',
              '16_rando_spawners', '17_rando_omega', 'enemy', 'boss', 'chaos']:
        lua.execute(open(os.path.join(kit, 'scripts', n + '.lua'), encoding='utf-8').read())
    return lua, LOG
DEV = '{ seed = "random", preset = "balanced", distribution = "goldbolts_first", omega_early = true, travel_lock = true, weapon_xp = true }'
def run(kit, label):
    lua, LOG = boot(kit, DEV)
    lua.eval('rando_use_seed("rift-lombax-blizar-611")')
    lua.execute('STEP(3000, %f)' % BUDGET)
    ok1 = lua.eval('RANDO_SEED ~= nil')
    lua.eval('rando_mark_restored()')
    # New Game: the new seed is made in the game's frames
    lua.execute('CLOCK = CLOCK + 100')
    lua.execute('FIRE("ObjectiveStateChangedEvent", { MissionName = "MIS_INTRO", ObjectiveName = "OBJ_INTRO_PARADE_START_CINE", ObjectiveState = 1 })')
    lua.execute('STEP(6000, %f)' % BUDGET)
    ok2 = lua.eval('RANDO_SEED ~= nil and RANDO.state ~= nil and RANDO.state.started == true')
    errs = sum(1 for l in LOG if 'RANDO-ERROR generator' in l)
    gave_up = any('could not be generated' in l for l in LOG)
    print(f'INFO {label}: first seed {ok1}, New Game seed {ok2}, generator budget errors logged {errs}, gave up {gave_up}')
    return ok1, ok2, gave_up
a1, a2, g = run(KIT, 'this kit')
check(a1, f'the first seed is generated under a {BUDGET*1000:.0f} ms budget')
check(a2, 'the New Game seed is generated under the same budget')
check(not g, 'it never gives up')
if OTHER: run(OTHER, 'other kit')
print('FAILURES', fails)
sys.exit(1 if fails else 0)
