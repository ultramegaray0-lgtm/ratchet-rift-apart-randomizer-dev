# Testing (Randomizer 10.0, Public Release v0.52; dev 10.15)

Results come in four kinds, and a pass in one is never evidence for another. VERIFICATION_REPORT.md
sorts every feature into them. This page covers how the tests run and what to check in your
first full playthrough.

## 1. Automated tests (this build)

`python run_tests.py`: **536 tests, 0 failures, 0 errors, 21 skipped** (TEST_RESULTS.txt; dev 10.11 adds tests/test_v1011.py, 20;
dev 10.12 adds tests/test_v1012.py, 32 - see TEST_REPORT_10.12.md; dev 10.13 adds tests/test_v1013.py, 23 - TEST_REPORT_10.13.md;
dev 10.15 adds tests/test_v1015.py, 32 - TEST_REPORT_10.15.md).
Dev 10.27: 722 run, 0 failures, 23 skipped (tests/test_v1027.py adds 40 for the Enemy Randomizer's variable route).
Dev 10.28: 744 run, 0 failures, 23 skipped (tests/test_v1028.py adds 22: round38 real-log facts and the fixes).
Dev 10.29: 769 run, 0 failures, 23 skipped (tests/test_v1029.py adds 25: 7 on round39's real log, 18 simulator -
every spawn mechanism, family, the ledger, notes, bosses, checkpoints, planets and a 600-spawn busy level).
Dev 10.30: 804 run, 0 failures, 23 skipped (tests/test_v1030.py adds 35: 11 on round40's real log, 20 simulator -
combat compatibility, the death / no-death watch, the initialization check, trials, groups, bosses, factories first,
the frame budget - and 4 on the install). Against dev 10.29's scripts all 20 simulator tests fail.
All of these are SIMULATOR tests: none of them is a result from the real game. The simulator cannot know whether an
enemy can be killed; it only shows what the engine does with the deaths the game reports (or their absence).
The skipped tests:
- 9 need PowerShell 7, which could not run on the build machine;
- 8 need the 5.0 and 6.0 git commits, which are not in this repository.

| Suite | Tests | What it covers |
|---|---|---|
| **test_v1015** | 32 | dev 10.15: Omega weapons: the 20 items (the weapon's own id, never a real item); omega off = every seed is the 10.13 seed (git); on = the same seed plus each Omega once, never Gold Bolt / shop / random start, start_items and exclude, the audit; weapon -> Omega, Omega -> weapon, Omega with neither owned, both at once, repeats, all 20 weapons; a non-flag byte never written; omega_runtime off; without 17; learning the byte from two purchases, never from one with an upgrade, never from a byte every record holds as 1, never from a new weapon; kept over New Game; save/load, a save that lost the flag, the late-restore merge, loads moving the records, the inventory restore and a New Game+ Omega never downgraded; a seed's locations paying Omegas; held back from player packages |
| **test_v1013** | 23 | dev 10.13: Chaos Randomizer: loads OFF, BACKSPACE toggles and says so, saved and kept over New Game; every category replaced and used both ways (bosses <-> regular, story bosses, unclassified); other planets' templates; few repeats; seeded; priority over Enemy/Boss and their exact picks back when OFF; no guard of any kind; integrity (unmatched nodes never written); removal; never in a player package |
| **test_v1012** | 32 | dev 10.12: Enemy / Boss Randomizer against the simulated encounter model: off = nothing read or written; only template ids change and the node completes the encounter once, after the last enemy; tiers and families never mix; story bosses and friendlies never touched; bosses permuted; each switch only its own, saved and kept over New Game; safety nets (no spawn, stuck, retries, wrong family, story boss areas); layout by signature; frame budget; any of the three files removed |
| **test_v1011** | 20 | dev 10.11: Coordinates never on revisits and always opening a playable first visit (an independent Python check of the rules, both fills, your settings, fewer locations), the audit catching both, the switch; open planets' visits made active between stories (never while a story runs, never on your planet); a primed landing loads nothing; a landing started there loads the intro (Blizar's destroyed pad); a stuck first step reloaded at the intro; Viceron before Torren IV sent back with the reason; first visits listed first; the game's trip to an open Sargasso played |
| **test_v90** | 20 | 9.0: no hub; retired presets and settings; every mode starts prologue > Nefarious City > Sargasso; your 9.0 and 8.5.2 settings files; a New Game played to Sargasso with no warp, flight, mission write or hero swap; a leftover hub script reported and inert; locked levels still send you back |
| test_generator, test_registry | 39 | seeds, items, prices, currency, the weapon registry, mutation tests (the checkers catch broken seeds) |
| test_campaign, test_levels | 48 | campaign and level-lock replays (9.0's fixed start), mission control, the director |
| test_runtime | 86 | deliveries, the shop, armor, currency, save/restore, the real event streams of rounds 13-20 |
| test_v81, test_v82, test_v83 | 34 | checkpoint catalog, test travel, keys |
| test_v84 | 24 | registry, weapon types, the shop's pointer layout, ARSENAL_RESTORED, landings, the kit check, INSTALL.txt naming exactly the kit's files |
| test_v85 | 19 | the 8.5 fixes: mailbox take-back, late restore, New Game resets, shop routes |
| test_native | 3 | rando_give.dll: the source rebuilds to the shipped DLL **byte for byte**; its game-code checks match both code dumps |
| test_companion, test_tools, test_regression_v5/v6 | 21 | companion (needs pwsh), spoiler and log tools; 5.0/6.0 regressions (need git history) |

The older suites pin the settings they were written for (`tests/harness.py`, CLASSIC_TEST_SETTINGS:
no Coordinates, the game's own order, Raritanium 20-150). Your defaults changed in 8.5.1; test_v90
runs them, and your kit 04 file, as they are.

## 2-dev17. Dev 10.30 (kit 10.0.19): every replacement must die - ONE test

Build: commit of dev 10.30 on main. Copy `rando_give.dll` (unchanged v7) next to RiftApart.exe and the WHOLE `scripts`
folder into <game>\scripts. **Delete every `dev(...).lua` from <game>\scripts** (they now live in `dev_scripts\` and
are not needed). Check rivet.log: `RANDO-KIT release dev 10.30 (kit 10.0.19)`, `all 12 required scripts are 10.0.19`,
no `RANDO-ERROR RANDO-KIT` line (if one names an old dev file, delete that file). Banner: "Randomizer dev 10.30".
Same save is fine. `-` ON (Ctrl+`-` ends with "combat: 3 pair(s) verified, 2 rejected (verified)").
1. **Zurkon, challenge A1 to the end.** Kill everything. LOOK: no pirate robot SHOOTER where a bladeball came; every
   enemy dies. Press Ctrl+`-` at the end.
2. **Zurkon A1 once more** (restart it). Same check.
3. Write down: any enemy you could not kill (which one, which wave), and whether A1 finished. Send rivet.log.
Optional, only if you want more variety tested: set `enemy_compat = "trial"` in 04_rando_settings.lua and play ONE
ordinary fight on another planet (Sargasso, Savali...). If an enemy will not die, keep fighting about a minute: a corner
note says its spawners use the original enemy again; then load the last checkpoint. Set it back to "verified" after.
What the log answers without you: `DEATH <bot> | X replacing Y | N s after its spawn` for every replaced bot that died,
`COMBAT <pair>: replaced bots spawned N, died D, ... alive at the end A` per level, `COMBAT VERIFIED` / `COMBAT CHECK
FAILED` (trial), `VERIFY ... | initialization OK ...`, and `CHANGED ... [template H uid U from S; ...]` (which template
actor each change used - the clue to WHY round40's shooters could not die).

## 2-dev16. Dev 10.29 (kit 10.0.18): the Enemy Randomizer overhaul - ONE consolidated test

Build: commit of dev 10.29 on main. Copy `rando_give.dll` (v7) next to RiftApart.exe and the WHOLE `scripts` folder
(banner "Randomizer dev 10.29"; log `RANDO-ENEMIES variable route loaded (dev 10.29)`). Remove `dev(spawnprobe).lua`
from the game's scripts folder (its job is done; it costs frame budget). Same save as before is fine.
Both `-` (Enemy) and `=` (Boss) Randomizers ON (Ctrl+`-` / Ctrl+`=` say so); `enemy_notify = true` (default).
1. **Zurkon, challenge A1 to the end.** Watch the corner: "[ENEMY RANDOMIZER] SUCCESS - Original: Pirate Robot
   Shooter -> Replacement: Goons-4-Less Shooter" (or similar) as the waves come. LOOK: thugs where pirates were?
   At the end press Ctrl+`-`: "N of M enemy spawn(s) here were replaced".
2. **Zurkon, the pub brawl / a challenge with robomutts and thugs, twice** (load the checkpoint for the second run).
   Second run: notes for "node Template group", other enemies where robomutts / thugs came?
3. **Sargasso**, two ordinary fights (wasps, horned toads, thugs). Ctrl+`-` after each.
4. **Cordelion** (or any planet you have open: Savali, Blizar Prime, Torren IV), one ordinary fight. Ctrl+`-`.
5. Write down: what you SAW replaced (one or two examples), anything stuck or unbeatable, any challenge that did not
   finish. Send rivet.log and those notes.
What the log will answer without you: `SPAWN ... | SUCCESS / NOT CHANGED: <why>` for every enemy spawn,
`ENEMY SPAWNS on this level: N, replaced R (x%) ... why: ...` at every level end, `level detail: ... spawn points
indexed N ... spawns given up 0`, `CHANGED AGAIN` (a better pick before the spawner ran), `VERIFY ... node Template group`.

## 2-dev15. Dev 10.28 (kit 10.0.18): the Enemy Randomizer after round38 - groups, nodes, no false "stuck"

Build: commit of dev 10.28 on main. Copy `rando_give.dll` (v7) next to RiftApart.exe and the WHOLE `scripts` folder
(banner "Randomizer dev 10.28"; log `RANDO-ENEMIES variable route loaded (dev 10.28)`). For a lighter frame budget
you may remove `dev(spawnprobe).lua` (round38's budget errors came partly from it); keep it if you can, its node
records help the group work.
The Enemy Randomizer is ON in this dev kit; if Ctrl+`-` says OFF, press `-` once. Use the SAME save as round38 if you
can: the log should then say `5 spawner(s) 10.27 wrongly kept original ... are randomized again`.
1. Zurkon, challenge A1 to the end. LOOK: other walkers in later waves; NO "encounter looks stuck" note while you fight.
2. Zurkon, the challenge with robomutts / thugs (round38: A5 area, thugs at spawn index 8 / 9), TWICE in a row (the
   first run learns the group; load the checkpoint or restart it for the second). LOOK at the second run: does
   anything else come where the robomutts / thugs came? Does it finish?
3. Sargasso, any fight with wasps / horned toads / thugs (round38 proved a jetpack thug -> wasp there). Press Ctrl+`-`.
4. One more planet with regular enemies (Savali, Blizar Prime or Torren IV, any wave). Press Ctrl+`-`.
5. Note anything stuck, unbeatable, or a challenge that does not finish, and which enemies you saw where. Send rivet.log.
Lines: `CHANGED ...`, `VERIFY ...`, `group node ...: member ...`, `spawn N of X (family) at location L index I: tied to
no spawner variable` (an enemy no adapter could follow: the next step for groups), `level detail: node Template: ...
| node Template group: ... | SpawnFactory-0 spawns tied to nothing N | deaths seen D (of our bots d), bots gone G | jobs
dropped J` (why node and group spawners were not changed; whether deaths and gone bots are seen), `put back (the level
was quiet ...)` (the new stuck rule), `template actors never answered ...`.

## 2-dev14. Dev 10.27 (kit 10.0.18): the Enemy Randomizer itself (no developer file needed)

Build: commit of dev 10.27 on main. Copy `rando_give.dll` (v7) next to RiftApart.exe and the WHOLE `scripts` folder
(banner "Randomizer dev 10.27"; log `RANDO-KIT all 12 required scripts are 10.0.18` and `RANDO-ENEMIES variable route
loaded (dev 10.27)`). dev(spawnproof).lua may stay: it stands down while the Enemy Randomizer is ON.
The Enemy Randomizer is ON in this dev kit; if Ctrl+`-` says OFF, press `-` once.
1. Zurkon, challenge A1 (the benchmark), to the end. After the first wave a corner note should say
   "Enemy Randomizer: working - X came as Y". LOOK: do later waves bring other walker kinds where the usual ones came?
2. Zurkon, a challenge with robomutts / thugs, TWICE (the first run learns the group; the second should change it).
   LOOK at the second run: other walkers where robomutts / thugs came?
3. One ordinary fight on another planet (any wave of regular enemies). Press Ctrl+`-` there and note the counts.
4. Note anything stuck, unbeatable, or a challenge that does not finish. Send rivet.log and what you saw.
Lines: `RANDO-ENEMIES scan ...` (how many factory / node / group variables; "template actors asked before a spawn: N,
answered M"), `CHANGED ...`, `VERIFY ...: REPLACEMENT SPAWNED / ORIGINAL SPAWNED`, `group node ...: member ...`,
`ADAPTER OFF ...` (an adapter the game ignored), `put back ...`, `level summary ...`.

## 2-dev13. Dev 10.26 (kit 10.0.17): one enemy kind -> another on the factories still to come (Zurkon)

Build: commit of dev 10.26 on main. Copy `rando_give.dll` (v7) next to RiftApart.exe and the WHOLE `scripts` folder
(banner "Randomizer dev 10.26", log "v6 loaded (factory Templates route, fresh factories)").
1. Zurkon, challenge A1, to the end.
2. After the first enemies, the screen says e.g. `SPAWNPROOF ARMED: enm_pirate_robot_me should now come as
   enm_pirate_robot_sh`. In the next waves, where melee robots would come, shooter robots should come instead.
3. The screen then says `SPAWNPROOF: REPLACEMENT SPAWNED (...)` or `ORIGINAL SPAWNED (...)`.
4. LOOK: do the waves bring the other kind? Does the challenge finish? Send rivet.log and what you saw.
Lines: `EXPERIMENT n: X -> Y on k factory(ies) that have not spawned yet: ...`, `ARMED ... read back OK`, `VERIFY node
factory F ...`, `[ARMED factory variable ...]` spawns, `put back ...`; `factory route waiting: ...` if nothing fits.

## 2-dev12. Dev 10.25 (kit 10.0.17): one factory's Templates swap (Zurkon)

Build: commit of dev 10.25 on main. Copy, from `mod/RiftApartRandomizer/`: `rando_give.dll` next to RiftApart.exe AND
the WHOLE `scripts` folder into <game>\scripts (your last log still ran dev 10.23 scripts: the on-screen banner must
say "Randomizer dev 10.25"; spawnproof must log "v5 loaded (factory Templates route)"). No dev(spawnprobe).lua.
1. Zurkon, challenge A1, play it to the end.
2. After the first wave the screen should say `SPAWNPROOF ARMED: next <enemy> here should be <other enemy>`, e.g.
   a robot shooter's spot now bringing a bladeball. Then `SPAWNPROOF: REPLACEMENT SPAWNED (...)` or `ORIGINAL
   SPAWNED` (then it tries another factory by itself).
3. LOOK at the wave: do you see the other enemy where the old one used to come? Does the challenge finish?
4. Send rivet.log and what you saw.
Lines: `factories on scarstu: N with a Templates variable ...`, `spawn ... factory Templates = T`, `learned: ...
factory Templates value(s)`, `factory F chosen (...)`, `ARMED ... ftemplate ... read back OK`, `VERIFY ...`, the
next spawns marked `[ARMED factory variable, spawn k since]`, `put back ...`.

## 2-dev11. Dev 10.24 (kit 10.0.17): the Factories experiment with the right helper (Zurkon)

Build: commit of dev 10.24 on main. Copy, from `mod/RiftApartRandomizer/`:
- `rando_give.dll` next to RiftApart.exe (overwrite the old one: the kit's is v7 now; nothing else to copy by hand);
- the whole `scripts` folder into <game>\scripts (without `dev(spawnprobe).lua`).
Then exactly as 2-dev10 below: Zurkon, challenge A1 to the end, watch the screen, send rivet.log + what you saw.
NEW: if anything stops the experiment, the screen says `SPAWNPROOF BLOCKED: <reason>` as soon as you are on Zurkon.
If you see that, it is not worth playing the challenge - send rivet.log right away.

## 2-dev10. Dev 10.23 (kit 10.0.17): the Factories experiment, for real this time (Zurkon)

Build: commit of dev 10.23 on main. Files: the kit's WHOLE `scripts` folder (the kit is 10.0.17: the runtime changed;
`RANDO-KIT all 12 required scripts are 10.0.17` must appear), with `dev(spawnproof).lua` v3 and WITHOUT
`dev(spawnprobe).lua`; `rando_give_source/dev_build/rando_give.dll` (v7) over the game folder's rando_give.dll.
1. Start the companion BEFORE the game if you can (not required any more, but it keeps the log simple).
2. Load your save, go to Zurkon. In rivet.log (or just trust it) the file now says `level reset (planet Zurkon): ON
   ZURKON - active`. Play ONE multi-wave challenge of ordinary enemies (A1) to the end.
3. WATCH THE SCREEN: `SPAWNPROOF ARMED: next X here should be Y` appears when it changes a node; then
   `SPAWNPROOF: REPLACEMENT SPAWNED (Y)` / `ORIGINAL SPAWNED` / `SOMETHING ELSE SPAWNED` when that node spawns.
   If you see REPLACEMENT SPAWNED, look at the enemy that just appeared: is it really a Y? Does the wave finish?
4. Quit normally, send rivet.log, and say what you saw on screen.
Lines that answer each question: `v3 loaded ... own events: planet yes, spawns yes` (subscriptions); `level reset`
(where it thinks it is); `scan N on scarstu: ... Y Factories` (nodes found); `spawn H ... via LastSpawn|Spawner
slot; slot factory = F` (spawn request seen and tied); `learned:` (originals identified); `ARMED ... read back OK`
(replacement written); `VERIFY ...` (what the game created); `put back`, `level summary`.

## 2-dev9. Dev 10.22 (kit 10.0.16): Factories replacements (Zurkon)

Build: commit of dev 10.22 on main. Files: the kit's whole `scripts` folder with `dev(spawnproof).lua` v2, but
**without** `dev(spawnprobe).lua` (delete it from <game>\scripts: it costs frame budget and v2 logs what is
needed), AND `rando_give_source/dev_build/rando_give.dll` (v7) over the game folder's rando_give.dll.
1. Load your save, go to Zurkon (Zurkie's Battleplex). Play ONE multi-wave challenge of ordinary enemies to the
   end (A1 is fine). The file learns from the first waves and arms nodes of later waves.
2. If a later wave brings an enemy type that does not belong there, that is the replacement. Finish the
   challenge (that it completes is part of the test). A second challenge in the same session is welcome.
3. Quit normally and send rivet.log.
Expected `RANDO-SPAWNPROOF` lines: `v2 loaded`; `scan N on scarstu: ... X Template, Y Factories ...`;
`spawn H (SpawnFactory F, ...): node U via LastSpawn|Spawner slot; slot factory = F; spawned ...`;
`factory F: classes ...; node variables ...`; `learned: ...`; then `ARMED k/4 node ... read back OK; ...`,
`VERIFY node ...: REPLACEMENT SPAWNED` (or ORIGINAL / SOMETHING ELSE), `put back (...)`, `level summary`.
What each answer means: REPLACEMENT SPAWNED = the mechanism for Enemy / Boss / Chaos is proven; ORIGINAL
SPAWNED = the node does not read the variable/copy at spawn time (the factory's own variables, logged, are the
next place); no `ARMED` = read `learned:` and `level summary` (fewer than 2 factories with enemies, or MIXED).

## 2-dev8. Dev 10.21 (kit 10.0.16): ONE controlled enemy replacement (Zurkon)

Build: commit of dev 10.21 on main. Files: the kit's whole `scripts` folder (dev(spawnproof).lua and
dev(spawnprobe).lua included) AND `rando_give_source/dev_build/rando_give.dll` copied over the game
folder's rando_give.dll (it must say v7; the kit's top-level DLL is the older v6).
1. Load your save, go to Zurkon (Zurkie's Battleplex). Start an arena challenge with several waves of
   ordinary enemies (the A1 challenge you replayed is fine) and play it to the end. The file only acts on
   Zurkon, once per session, only in memory.
2. Watch for the first enemy of a later wave: if the file armed a node, one encounter should spawn a
   different ordinary enemy than usual. Finish the challenge (that it completes is part of the test).
3. Quit normally and send rivet.log.
Expected `RANDO-SPAWNPROOF` lines: `SceneManager ... (signature matched 1 x)`; `scan N on scarstu: X node(s)
...; Y with a Template variable`; `spawn H is node U's (its LastSpawn) ...`; then `ARMED node ... read back
OK`, `VERIFY node ...: REPLACEMENT SPAWNED` (or ORIGINAL SPAWNED / SOMETHING ELSE SPAWNED) and `put back
(its Spawner stopped) ...: OK`. Each line answers one open question: Y = 0 means arena nodes do not use the
Template variable; no `spawn ... is node` line means LastSpawn does not tie spawns to nodes; ORIGINAL
SPAWNED means the node does not read the variable at each spawn.

## 2-dev7. Dev 10.20 (kit 10.0.15): ONE focused test - where the encounter's Templates live

Nothing is randomized by this test and nothing is written to the game: dev(spawnprobe).lua only reads.
1. Install the whole dev kit's `scripts` folder, `dev(spawnprobe).lua` included (delete the old *_rando_*,
   enemy/boss/chaos and dev(*) files first). The Enemy / Boss / Chaos switches do not matter.
2. Load your save and go to Zurkon (Zurkie's Battleplex). Start one arena challenge you can replay and fight
   until at least two waves have spawned (finishing it is better). Then go back to the table once
   (a checkpoint load) and quit the game normally.
3. Send rivet.log. Needed: every `RANDO-SPAWNPROBE` line. Expected kinds:
   `index N (...)` (one per load: how many nodes, whether every Spawner matched +0x60, where Spawners hold
   pointers), `spawn N:` (what the game actually created: uid, actor asset, classes, Template flag),
   `sweep N:` / `stopped:` (which Spawner bytes change while an encounter runs), `probe ...` (type data,
   bytes, pointer targets) and, most important, `UID HIT` lines (a loaded actor's uid found in or one / two
   pointers from the node or its Spawner: a template bot there marks the Templates list).
What decides the next step: a `UID HIT` naming a TEMPLATE bot whose actor asset matches a `spawn` line is the
list; then ONE slot of ONE encounter is changed (with read-back and a `verify` of the next spawn) before
anything else is enabled. If there is no such hit, the list is not reachable from the node, and the next
step is the spawn function itself (rando_give.dll), not more offsets.

## 2-dev6. v0.71-DEV2 (kit 10.0.37): Omega on a held weapon, early Omega test (round55)

Start a New Game with this kit (the seed changes: omega_early = true). Settings: omega_test = 6, start_omega = 1.
1. Early in Nefarious City / Zurkon, look for `RANDO-OMEGA-TEST <weapon> arrives as its Omega version` (each Gold Bolt,
   pod or mission that pays a weapon, up to 6 Omega weapons) and `Omega <weapon> applied`.
2. IN THE GAME: open the weapon wheel / upgrade screen of each. An Omega weapon shows its Omega name and a level cap of
   10 (docs/OMEGA.md). Say which weapons are Omega, and whether any is missing from the wheel.
3. The new guard: `RANDO-OMEGA ... waits: the record of <weapon> is an empty slot` means the game does not hold that weapon.
   It is followed by `EVIDENCE empty slot ...` (send it) and, 15 s later, `sending <weapon> again`. Then either
   `Given back` / `applied` (fixed) or the same wait again (the weapon cannot be given there).
4. Check the Negatron Collider (the start Omega) after the Nefarious City intro is over: is it in the wheel?
5. Die once and retry: the Omega flags must still show `the game holds <weapon> as Omega` after the load.
6. To go back to the normal seed: omega_early = false, omega_test = 0 in 04_rando_settings.lua.

## 2-dev5. Dev 10.15 (kit 10.0.11): Omega weapons (gameplay test plan)

Needs a Challenge Mode save (finish the story once) and the developer kit (`17_rando_omega.lua`).
Read OMEGA.md first. Use a spare save slot.

0. **Install.** `RANDO-KIT all 12 required scripts are 10.0.11`; `RANDO-OMEGA loaded (Omega flag not learned yet)`.
1. **The records.** On any planet: `RANDO-OMEGA inventory: N weapon record(s) in <class> (array at +0x..)`,
   N = the weapons you own. If it says `inventory not found`, send rivet.log (it has the component's bytes).
2. **Learning.** At Ms. Zurkon buy the Omega of one weapon: `Omega purchase 1 of 2 (...): candidate byte(s) ...`.
   Leave, come back, buy a second weapon's Omega: `LEARNED: the Omega flag is the byte at +0x..` and the HUD
   message. If no line appears after a purchase, the game reports no `PurchaseWeaponEvent` for Omegas: send rivet.log.
3. **A seed with Omegas.** `omega_weapons = true` in 04 (a new seed: New Game in Challenge Mode). The spoiler's
   OMEGA VERSIONS section lists where each is.
4. **Omega first.** Find an Omega whose weapon you do not have: the weapon arrives first, then `... is yours`.
   Check in the weapon menu: Omega name, level cap 10, the Omega upgrade nodes. Save, quit, load: still Omega.
5. **Weapon after its Omega.** Find that weapon's own reward: `you have its Omega version already (kept)`;
   the weapon stays Omega.
6. **Weapon first, then its Omega**: the weapon you have becomes Omega; nothing is added twice.
7. **Restore.** Ctrl+0 twice (items sent again): every Omega stays Omega (`RANDO-OMEGA kept ...` if the game
   had cleared one).
8. **Status.** `;` / F9: `Omega n/m`.

## 2-dev3. Dev 10.13 (kit 10.0.9): Chaos Randomizer (gameplay test plan)

Read CHAOS.md first: Chaos has no protection, so a stuck run is an expected result, not a failure.
Use a spare save. What is tested here is that Chaos does what it says, not that the game stays beatable.

0. **Install.** `RANDO-KIT all 12 required scripts are 10.0.9`; `RANDO-CHAOS installed (OFF ...)`;
   banner `Randomizer dev 10.13`.
1. **The key.** Does `BACKSPACE` reach the game (`RANDO-KEY BACKSPACE` in rivet.log) without a game
   action of its own? "CHAOS RANDOMIZER: ON" on screen; `Ctrl+BACKSPACE` shows the status.
2. **Everything changes.** `RANDO-SPAWNERS plan (...): N slot(s) changed ... chaos (priority, P
   template(s))`. Play encounters: what spawns? Note whether each replacement spawns, moves, fights,
   dies, and whether the encounter completes (no outcome is required).
3. **Bosses <-> regular.** A large enemy encounter that now spawns small ones and the other way round.
4. **Cross-planet.** Play a planet with Chaos on, travel to another: `RANDO-CHAOS pool: N new
   template(s) from <planet>`, and `Ctrl+BACKSPACE` "N from elsewhere here". **Do other planets'
   templates spawn, spawn wrong, or make the game misbehave or crash?** If it crashes, try
   `chaos_cross_planet = false`.
5. **Priority.** With `-` and `=` ON, switch Chaos on: their changes are replaced; switch it off:
   their own picks come back (Ctrl+- / Ctrl+= counts as before Chaos).
6. **Persistence.** Restart the game (companion running) and start a New Game: Chaos still ON.
7. **Getting unstuck.** In a broken encounter: BACKSPACE, then load the last checkpoint: the
   original encounter.
8. **Frame time.** Any `ran past the 8 ms frame budget` line naming 16_rando_spawners or chaos.lua?

## 2-dev2. Dev 10.12 (kit 10.0.8): Enemy Randomizer and Boss Randomizer (gameplay test plan)

Seeds are unchanged: a 10.11 save continues. Copy `16_rando_spawners.lua`, `enemy.lua`, `boss.lua`
with the rest of `scripts\`. Both features start OFF. Test whole encounters from start to finish,
not only whether enemies look different. Note for every case: PASS / FAIL / not reached, and keep
rivet.log. ENEMIES_AND_BOSSES.md section 7 says which lines to look for.

0. **Install.** `RANDO-KIT all 12 required scripts are 10.0.8`; `RANDO-ENEMY installed (OFF ...)`,
   `RANDO-BOSS installed (OFF ...)`; banner `Randomizer dev 10.12`.
1. **Both OFF (play 2-3 encounters).** No `RANDO-SPAWNERS census` line at all. Enemies as usual.
2. **Enemy ON (`-`).** "Enemy Randomizer: ON". `census 1 (...): N spawner node(s) read ... layout ...`
   (send the line). Play a few encounters: `learned <id> = <family>` lines, then `plan (...): N slot(s)
   changed`. Later encounters on the planet: different regular enemies?
3. **Encounter completion (the key test).** In a changed encounter (`Ctrl+-` shows the count): kill
   all but one: the door / wave / objective must NOT advance; kill the last: it must advance once.
   Arena doors, "defeat the enemies" objectives, wave spawners.
4. **Death and reload.** Die in a changed encounter, retry, finish it. Load the last checkpoint once.
   A third death there puts it back (`kept original`): is that encounter then normal?
5. **Planet change and hub return.** Fly away and back (planet shuffle on and off): census again,
   nothing wrong in other features (weapons given, shop, Gold Bolts, collectibles).
6. **Enemy OFF in the middle of an encounter.** The remaining spawns are the originals; it completes.
7. **Boss ON (`=`), enemy OFF.** On a planet with large enemies (Grunthors, tanks, Manglers): are they
   other large enemies (none added, none doubled)? Health bar, death, arena exit.
8. **A story boss** (e.g. Sargasso's Seekerpede, Cordelion, Viceron's warden, the finale) with both
   ON: the boss and its adds are the game's own; `story boss area ... every change put back` if the
   checkpoint name contains BOSS/FINALE/HEAVY_FIGHT/CHASE. Cutscene, health bar, next area as usual.
9. **Both ON, enemy ON + boss OFF, enemy OFF + boss ON, both OFF**: one encounter of each kind per
   combination; the switches survive a game restart (the companion) and a New Game.
10. **Frame time.** Any `ran past the 8 ms frame budget` line naming 16_rando_spawners?

## 2-dev. Dev 10.11 (kit 10.0.7): new planets start at their intro

A new seed (generator 10.11.0): start with **New Game**, planet shuffle on (`0`).

1. **Install check.** `RANDO-KIT all 12 required scripts are 10.0.7`; the banner reads
   `Randomizer dev 10.11 (kit 10.0.7)`.
2. **After Nefarious City's story** (or at the hub when it is done): `making the next visit of N
   open planet(s) active` and `prime <visit>: start MIS_... (Available -> Active)` lines. No warp,
   no hero swap.
3. **Coordinates found (the key test).** "X is open: ..." on screen. Fly there with the ship's
   planet menu. Does the planet's **intro** play and the first mission start? Logged: `planet menu:
   landed on X at <checkpoint>` and either `... was active before the landing - its arrival is the
   game's own; nothing loaded` or a warp `travel: warp to <intro> ... (its intro)`. Then the story's
   `objective MIS_... OBJ_..._GO_TO_...` should turn 2 (done). Please note which checkpoint the
   game landed at (`RANDO-CHECKPOINT` right after the landing).
4. **A planet whose first visit is not open yet.** A planet shown as "its first visit needs ...
   first" sends you back from the planet menu with that reason. (Viceron's Coordinates now come from
   Torren IV's story, so this should be rare.)
5. **The `]` list** (dev keys only): first visits before revisits; no "revisit" entry for a planet
   whose first visit is still to come.
6. **Nefarious City's end** with Sargasso's Coordinates held: the game's own trip to Sargasso is
   played (`its first visit is open: hub_follow_new`); without them it is undone as before.

## 2. Round 27: v0.54 (build 10.0.5)

Your round 26 save carries over (same seed, same fingerprint). No New Game is needed.

1. **Install check.** `RANDO-KIT all 14 scripts are 10.0.5`; RANDO-KEYS lists `planet shuffle 0`;
   the banner reads `Randomizer v0.54 (kit 10.0.5)`.
2. **Load the Viceron save.** `arrived on viceron (a load) - nothing changed` and **no** `the
   game's own story took you to`. Then, 7 s later, `RANDO-RESTORE after the load on viceron: ...`:
   do your weapons come back ("Given back: ...")? If not, press `Ctrl+0` twice.
3. **`0`.** `planet shuffle OFF`; `]` / `Ctrl+]` answer "planet shuffle is off"; travel with the
   ship: nothing sends you back. Press `0` again: `planet shuffle ON`. Restart the game: the
   choice is kept (`planet shuffle is OFF in this save` when it was off).
4. **A trip with `Ctrl+]`.** After landing: `RANDO-RESTORE after the trip to <planet>: ... nothing
   to do` with your weapons intact. If the inventory is emptied, the line says so and the items come
   back. Please send the log either way: the lines around the landing show what emptied it.
5. **`[`** shows "only cancels the trip back"; no warp.
6. **The shop:** look for `as pointers:` and `slot object 0 of the array` in RANDO-SHOP lines.

## 2a. Round 26: v0.53 (build 10.0.4)

Your round 25 save carries over (same seed, same fingerprint). Load it; no New Game is needed.

1. **Install check.** `RANDO-KIT all 14 scripts are 10.0.4`.
2. **Load the save in Nefarious City.** `planetary travel and level bits left to the game while
   nefcity_1 runs` (and **no** `planetary travel: done (0x0 -> 0x1)` while the city's story runs).
3. **The boss fight (the key test).** At the shift to Savali / Sargasso: does Ratchet arrive
   **without** the ship, on solid ground? Logged: `arrived on savali during nefcity_1`, then on the
   way back `back on nefarious_city from savali during nefcity_1 - the story's own travel` (no
   "destinations open" message in the fight).
4. **After the city's story.** Once MIS_NEFCITY_01 completes and you are back in the city:
   `planetary travel: done (0x0 -> 0x1)` and the level bits again; the ship's planet menu works.
5. Then continue with the round 25 list below from step 4.

## 2b. Round 25: v0.52 (build 10.0.3)

Use a spare save slot and the kit's settings (hub = true). Your round 24 seed carries over (same
fingerprint), but start a **New Game**: the new start only runs from the parade. Send the whole
rivet.log afterwards. Each step names the log line that shows it worked.

1. **Install check.** `RANDO-KIT all 14 scripts are 10.0.3`.
2. **New Game → Nefarious City (the key test).** Play the parade until the warp. In this order:
   - `going to the hub (Nefarious City): the parade handed Ratchet back after his wrench`
   - `prologue: MIS_INTRO written Complete Finished` (now **before** the story starts)
   - `made available MIS_NEFCITY_01`, `start MIS_NEFCITY_01 done (available -> active)`
   - `with nefcity_1: made available MIS_NEFCITY_01_TRAINSTATION`
   - `opening of nefcity_1: <NAME> (hash 3046787773, ...)` **(note the name)**, or
     `hash 3046787773 is not among the checkpoints your game lists` plus `checkpoints listed for
     nefarious_city:` (send that line)
   - `travel: warp to <NAME>`, then `RANDO-CHECKPOINT <NAME>` and `opening of nefcity_1 loaded`

   **Most important:** does the arrival cutscene play, then gameplay? Look for
   `objective MIS_NEFCITY_01 OBJ_NEFCITY_GO_TO_NEFCITY 2` and the next objective lines.
3. **If it still waits at "go to Nefarious City":** don't press anything for a minute (the hub
   reloads the opening once, `[STORY RELOAD]`). Then try `/` once. Note what each did.
4. **The city's story to its end.** Does the train station part work? Then the game flies you to
   Sargasso: is `[ORDER KEPT]` logged, and are you back in Nefarious City (at `CHK_NEFCITY_SHIP`)?
5. **Battle Arena.** `]` to "Battle Arena", `Ctrl+]`. Does Zurkon's arena intro play? Finish it:
   are you brought back to Nefarious City?
6. **A shuffled planet.** Once a "Coordinates" reward arrives, `]` shows that planet. Go there. Note
   whether its story starts, and the `RANDO-CHECKPOINT` lines (`learned the start of ...`).
7. **Planet menu.** From the ship, pick a planet you have no Coordinates for: are you sent back to
   Nefarious City?
8. **Rewards.** Every Gold Bolt gives an item (weapon, gadget, armor or Coordinates), matching the
   spoiler.

## 3. Running the automated tests yourself

`pip install lupa capstone`, then `python run_tests.py`; `python tools/big_batch.py` for the
43,000-seed batch (about 5 minutes). Optional, each skipped when missing:
- PowerShell 7, for the companion tests;
- a C compiler, for the DLL core test;
- clang + lld-link + llvm-dlltool, for the byte-for-byte DLL rebuild;
- git history, for the regression tests.

## 2-dev7. v0.71-DEV3 (kit 10.0.38): the shop sells randomized items

1. New Game. rivet.log: "RANDO-SHOP TABLE", "vendor ... N weapon slots, M changed", then a "RANDO-SHOP VERIFY" line.
2. Open Ms. Zurkon: compare the weapons with the spoiler SHOP / SHOP BONUS section.
3. Press \ (dev kit) to list the bonuses. Buy a bonus weapon: expect a "BUY ..." log line and "Shop bonus: ...".
4. Ctrl+\ twice pays the next bonus without a purchase (tests the grant).
5. If the vendor still shows vanilla weapons, send rivet.log (VERIFY says whether the stock was reset).
6. Prices may stay vanilla if the price offset does not match.

## 2-dev8. v0.71-DEV5 (kit 10.0.38): the shop bonuses pay

1. rivet.log: "RANDO-KIT release v0.71-DEV5". Open Ms. Zurkon once.
2. "RANDO-SHOP BONUS <slot> sells <weapon> + <item>" lines (one per bonus) and the corner note.
3. Buy the weapon of a bonus slot: expect "BUY ... (by config) in the slot of ... - pays the bonus shop:..." and the
   message "Shop bonus: <item>". Check the item arrives (gadget, armor piece, Omega flag).
4. "RANDO-SHOP EVIDENCE field +0x.." lines, "EVIDENCE N entries sell something ..." and "Price at +0x.. (u32, N slots ..)":
   send the whole rivet.log. Check her prices on the screen against the spoiler.
5. EXPERIMENT: shop_show_items = "try", restart, New Game not needed. Does a closed slot list a gadget / armor piece? Buying it
   should log "BUY ... the slot that shows <item> - pays shop:..". If the game stops when she opens, set "notify" again.
