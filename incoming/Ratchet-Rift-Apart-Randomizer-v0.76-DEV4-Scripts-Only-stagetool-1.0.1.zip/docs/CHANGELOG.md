# Changelog

## v0.76-DEV4 (kit 10.0.43; dev kit, not released): the .stage Enemy Randomizer, Phase A (single spawner)

WHY: the runtime route races the game. DEV3's rivet.log: of 692 enemy spawns, 62 spawned the ORIGINAL although the spawner's
variable held the replacement, and 50 spawned before the randomizer had read or planned their spawner. The .stage route changes
a spawner's template reference in the level's own zone file, so the game loads it like any asset (docs/STAGE_ENEMY_RANDOMIZER.md).
- NEW tools/stage_enemies (Python, standard library): reads the game's toc, dag and archives (read only) and
  - `probe`: searches a planet's zones for every template uid, spawner key and enemy .actor id your scripts and logs know;
  - `poc`: changes ONE Zone Script Vars reference (8 bytes, same size, same sections) to a combat-verified replacement whose
    template actor is placed in the same zone, and writes RandoEnemies.stage, a backup of the original zone and the manifest;
  - `verify`, `install` (LAST in rivet.toml [assets] paths, rivet.toml backed up), `uninstall`, `selftest` (48 checks).
  Asset ids are checked against the ids the game itself gave in rivet.log; LZ4 against the reference compressor.
- NEW scripts/18_rando_stage_enemies.lua (optional): announces .stage mode and verifies it in the game - STAGE VARIABLE (the
  patched spawner holds the .stage value = the zone loaded, or still the original = it did not), STAGE SPAWN, STAGE DEATH /
  GONE / ALIVE, STAGE SUMMARY. It changes nothing.
- 16_rando_spawners.lua: .stage mode (manifest installed, or enemy_source = "stage"): no runtime spawner write at all - plan,
  V.arm, V.repick, V.rotate and the legacy slot route (Chaos) refuse; earlier changes are put back; spawns are still listed and
  logged ("NOT CHANGED: .stage mode ..."). Without a manifest nothing changes (the Lua route is the fallback).
- 04 / 10: enemy_source = "auto" | "stage" | "lua" ("lua" is ignored while a .stage manifest is installed).
- Kit 10.0.43: every script and developer script restamped; 18_rando_stage_enemies is an optional kit file.
- NOT RUN against the real game files or in the game (no game here). Phase A is the next round.
- Phase A, static part (tool 1.0.1): the probe on your game found template uids in Zone Script Vars (785) and Zone Actors
  (321). POC built: Ardolis ard_firstvisit_gp.zone, Zone Script Vars +4912, pirate robot shooter 899208BF8F48C554 -> brawler
  92C793D47A4657B6 (8 bytes; spawner CECB812E81FB7301 at CHK_ARD_START). Not installed, not run in the game yet.
- FIX tool 1.0.1: the manifest's `spawner_keys` named every same-kind spawner of the zone (each twice); now only the
  spawners rivet.log saw holding the original uid (`same_kind_spawner_keys` keeps the rest, JSON only). With 1.0.0 the
  in-game check would have called untouched spawners "changed" and counted their spawns as "original". Ranking and the
  .stage bytes are unchanged. selftest: 53 checks (5 new).
- DOCS tool 1.0.1: `verify` needs `--log` with the logs probe used. It knows a template uid only from V.REG_BUILTIN and
  its --log files, so for uids learned in your game (the Ardolis POC's both are) `verify` without them reports "not one
  known template uid replaced by another". The documented command and poc's "next:" line now pass them; keep a copy of
  that rivet.log (the game rewrites it on its next start). verify's rule is unchanged.

## v0.76-DEV3 (kit 10.0.42; dev kit, not released): the New Game seed is generated in the game's frames

ROUND 65 (rivet.log of DEV2): the shop shuffle worked (one budget cut in the lookups, asked again, 19 of 19 slots written and
verified) and the Enemy Randomizer changed the Nefarious City factories at once. Then New Game: the new seed
pocket-bolt-rift-628 was generated during the parade, and rivet_hook's 8 ms frame budget killed the generator 4 times in a row
- every time inside the weapon quota pass (02_rando_generator.lua:1030 / 1046 / 1073 / 1085 / 1260 / 1891), which never yielded
and called the solver several times. After 3 restarts the runtime gave up for the whole session; every later request (the
companion asking for the old seed rift-lombax-blizar-611 every ~20 s) then failed at its first error. No seed: no randomizer.
- 02_rando_generator.lua: G.generate sets G._yield for its run; G.solve yields every 16 locations and every sphere, the weapon
  quota pass yields in its donor / home / fill loops, location_pool and item_pool every 32 entries; the sorted keys of the
  database's items and locations are made once (a copy is handed out). Placements are unchanged (the quota test's DEV1
  identity still holds).
- 10_rando_runtime.lua: a generator slice also ends once the frame has used R.GEN_FRAME_MAX (4 ms, R.frame_t0); a frame-budget
  error restarts the generation up to 40 times (the slice halves down to 0.5 ms) and every new request starts with a fresh
  count; rando_use_seed keeps making a New Game's pending seed rather than the companion's remembered one.
- tests/v076dev2/test_genbudget_dev2.py replays rivet_hook's deadline (count hook every 10,000 instructions, in coroutines too):
  DEV2 gives up at a 3 ms budget on this PC (as in the game at 8 ms); DEV3 makes both seeds at 3 ms and at 1 ms.


## v0.76-DEV2 (kit 10.0.41; dev kit, not released): enemies kept over checkpoints, shop unstuck, weapon quota, XP x20, new seed per New Game

ROUND 64 (rivet.log of DEV1; prologue, Nefarious City up to the glove). What went wrong:
- SHOP never shuffled: the weapon-config lookups were cut by the 8 ms frame budget at frame 1440 ("RANDO-ERROR shop: ran past
  the 8 ms frame budget") before H.ptr_asked was set; ptr_wait never reached 0 and the 30 s timeout counted from "now" every
  time, so the vendor was never searched ("looking for the vendor" all session, the Burst Pistol bought as itself).
- ENEMIES: 9 of 24 replaced in one fight, 0 of 5 in the courtyard, 0 of 5 at the glove. Every story-step checkpoint load
  ("Loaded=true" at BAZAAR, SKIDD_FOLLOW, COURTYARD_COMBAT, GETGLOVE) put back every change and forgot the level's kinds;
  the next listing was cut by the frame budget 17 times while the shop and Omega's component index read ran in the same
  frames. The courtyard ran with 1 kind known ("no other enemy kind known on this level").
- NEW GAME started the same seed again (run 4 of ardolis-nefarious-savali-645).

12_rando_shop.lua: the lookups are asked 4 per frame, counted only once sent, each request has its own token, the timeout
starts with the request, an interrupted request is asked again, and a checkpoint load starts a new search round (and drops a
running search, whose addresses the load may free). tests/v076dev2/test_shop_dev2.py replays the stall (DEV1: 0 writes).

16_rando_spawners.lua / enemy.lua:
- KEPT OVER A CHECKPOINT LOAD (V.make_carry / V.resume / V.carry_confirm): a change whose variable still holds exactly what was
  written is kept (nothing written, its true original remembered); the level's enemy kinds come back once the new level proves
  it is the same scene (a variable holds a known template handle + uid, or a kept write). No proof after 3 listings: kept
  writes still in place are put back. Level / planet loads keep nothing. Rejected pairs, encounters kept original for the
  seed and group spawners are put back as before.
- B (key_enemies_force): V.force - every unchanged spawner planned again, unread values read again, the save's kinds looked
  for again, the listing at once; a note ~2 s later says what changed. Switches the Enemy Randomizer on if it was off.
- enemy_live_status (dev settings: on): the Ctrl+- note stays on screen, updated every 2.5 s (not logged); Ctrl+- toggles it.
- First listing 2 frames after a reset (was 6), listings every 90 frames (was 120), the save's kinds looked for again soon
  after a pick found no other kind. The Enemy Randomizer runs before the shop and the armor in the frame; Omega's long jobs
  run every 4th frame while it is busy (SP.busy).
- enemy_randomizer = true is now the code default.

02_rando_generator.lua: WEAPON QUOTA (weapon_quota_missions = 2, weapon_quota_collectibles = 2, weapon_quota_shop = "share").
Every planet gets that many weapons or Omega versions on its story-mission rewards and its collectibles (Gold Bolts), filled round by round in story order from: unplaced Omegas, locations that can spare one (swaps; early weapons stay),
checked moves of logic items (the whole seed re-solved), then Ms. Zurkon's weapons ("share": sold AND a reward; "close": her
slot closes). A place whose logic item cannot move (Torren IV's story holds Viceron's Coordinates) gets the weapon riding
along (seed.extra: that place gives both). An Omega may now sit on a Gold Bolt (G.bolt_ok). Spoiler: WEAPON QUOTA section.
Quotas 0 and 0 = exactly DEV1's seeds (same fingerprint and placements). With the default pool (20 weapons, 20 Omegas,
2 start weapons, 8 shop weapons) the 37 quota places need every Omega and all 8 shop weapons shared; start_omega = 1 leaves
the last planet one collectible short (the dev settings now use start_omega = 0).

10_rando_runtime.lua / 17_rando_omega.lua:
- weapon_xp_gain (default 20): XP a held weapon earns is multiplied (O.xp_gain_pass, every 45 frames); a number 0-100,
  "random" (one per seed) or "random_each" (one per weapon), weapon_xp_gain_min/max = 2/50. XP rewards are never multiplied;
  a load that takes XP back only moves the baseline. Never changes the seed.
- new_game_new_seed (default true, seed = "random" only): a New Game makes a NEW random seed in place (the old save gets
  superseded_by; the status line gets a new boot; the new seed starts at once, keeping what a New Game always kept). A restore
  of a superseded save follows it to the newer seed.
- A quota extra is paid with its location; a shared shop weapon bought first pays weapon_xp_max XP for it instead.

Tests (tests/v076dev2): test_quota_dev2 (quotas 0 = DEV1 seeds; 6 setting variants x 25 seeds, audit clean), test_shop_dev2,
test_enemy_dev2 (carry / force / busy), test_xpgain_dev2, test_newgame_dev2 (the whole kit loaded, a New Game reseeds).

## v0.76-DEV1 (kit 10.0.40; dev kit, not released): Enemy Randomizer "killable" - only enemies proven killable there

ROUND 63 (rivet.log of v0.75; Savali / Nefarious City tower, Viceron / Zordoom; enemy_compat "all", movement kept).
Every replaced enemy was tallied by pair (spawner's original kind > replacement kind):
- SAME faction (Nefarious > Nefarious, Goons-4-Less skeleton melee <> shooter): 125 replaced, 125 died.
- OTHER faction at Nefarious factories on Zordoom (amoeboid large/small, Goons melee, pirate shingle, crab, wasp,
  sandshark): 26 replaced, 0 died. The warden office was reloaded 5 times with the same 8 amoeboids and 6 Goons standing
  there before its 21 factories kept their originals; the combat watch never fired (every try ended before its 45 s).
- 32 horned toads at Nefarious factories on the evac platform "died" by vanishing in batches 1-23 s after spawning, with no
  death event - 10.33's "gone = killed" rule verified that pair although none was fought.
- A Nefarious grenadier (flying) was rejected at 45 s and died the same second; its kind was then banned for the save.
- Coverage losses (not softlocks): 72 "original despite a change" on Zordoom (late changes), 92 Savali skeleton spawns not
  tied to a spawner (their factory has no Templates variable), 300+ "kind not known yet".

16_rando_spawners.lua:
- enemy_compat = "killable" (new default, code and settings): a pair verified in your save or the built-in table, or a
  kind of the SAME FACTION (V.faction: neo, thugs4less, pirate, amoeboid, wildlife = every indigenous_* creature). Another
  faction needs proof first; enemy_cross_faction = true lets one spawner per level try it (TRIAL, watched). "unclear"
  classes never stand in unproven. A size variant is used only when nothing else is allowed. Walkers/flyers stay apart.
- RELOAD STRIKE (V.reload_strikes): a checkpoint load while a replaced bot of an unverified pair is alive (15 s after its
  spawn; 45 s for a same-faction pair) and none of that pair was killed on the level rejects the pair for the session
  (suspect:1 in the save; a second strike = bad). The next try plans the encounter without it. V.RETRY_LIMIT 5 -> 3.
- A death after a rejection REVERSES it (COMBAT CHECK REVERSED) and lifts a replacement ban that rested on it
  (V.clear_rep_failure; REPLACEMENT BAN LIFTED). Built-in "bad" pairs are never reversed.
- Flyers get V.COMBAT_SECONDS_FLYER = 90 s in the combat watch (walkers 45 s).
- "Gone" is a kill only for a same-faction pair and from V.GONE_MIN_SECONDS = 3 s on (else a GONE line, "not taken as a kill").
- Built-in evidence: 12 same-faction pairs "ok", 9 other-faction pairs "bad" (incl. the horned toad pair); 31 template uids
  (Nefarious, pirates, Goons, skeletons, dropships, mounts) so a new save knows them before their first spawn.
- Save migration (once): built-in "ok" pairs override older rejections (round 63's grenadier pairs; its ban is lifted), and
  encounters kept original after retries are randomized again (killable picks only).
- The banner says "combat compatibility killable; KILLABLE: ...".
Other scripts: version 10.0.40, R.RELEASE "v0.76-DEV1"; 10_rando_runtime defaults enemy_compat "killable",
enemy_cross_faction false; dev 04_rando_settings: enemy_compat "killable", enemy_mix_movement false.
Offline: tests/v076/test_killable_v076.py (59 checks incl. a replay of every round-63 pair); tests/dev8 enemy/armor/xp pass.
Zordoom pool, 152 simulated factories: "all" changed 152, 134 of them to another faction; "killable" changes 144, none.
Not verified in the game. tests/dev9/test_owned_dev9.py already fails on the unmodified v0.75 scripts (harness seeds have no
shop bonus); not touched here.

## v0.71-DEV9 (kit 10.0.38; dev kit, not released): a shop bonus on a weapon you already own is given directly

ROUND 61 (rivet.log of DEV8; seed clank-pocket-rift-774). The DEV8 shop fix held: one write, "29 weapon slots, 28 changed",
VERIFY 28 of 28, six bonuses announced. But the save already held every weapon of the seed's shop (the Omega census listed 23
weapon records with XP: Enforcer 15,807, Bouncer 238,680, Warmonger 1,351,861 ...), and Ms. Zurkon shows an owned weapon as
owned - nothing can be bought in that slot, which is exactly how the closed slots (Burst Pistol) are closed. No
PurchaseWeaponEvent came in the whole session, so no bonus was ever paid ("Enforcer = Box Breaker" while you had the Enforcer).
In a new game the same happens whenever the weapon reaches you before the purchase: an Omega reward sends its weapon first
("Omega Mr. Fungi - Mr. Fungi added first"), a weapon the shop gave directly.
- 12_rando_shop.lua: H.owned_tick (every H.OWNED_EVERY = 300 frames, before the tick's early returns): for every unpaid bonus
  slot, the weapon it sells (H.bonus_sells: H.shown, or the slot's own weapon once the vendor was given up; nothing while the
  vendor is not known yet) is checked with H.owns: 09_rando_real.lua confirmed / owned (never "failed"), state.shop_given, or
  RANDO_OMEGA.held. Owned in two looks H.OWNED_CONFIRM (300) frames apart -> rt.collect(lid, "shop bonus: you already own X")
  with "Ms. Zurkon: you already have the X - Y is yours"; its queued note is dropped. A purchase in between pays first
  (s.collected), so nothing is paid twice. RANDO-SHOP OWNED lines; bonus_lines tag "[you own it: given soon]".
- 17_rando_omega.lua: O.held_pass reads every record of the hero's own set (hero_owned): held = the weapon's id, ItemCount 1 and
  not an empty slot (slot 5000+ with no XP and no ammo). After every census and every O.HELD_EVERY (600) frames (job "held");
  dropped by every load. rivet.log "RANDO-OMEGA held: N weapon(s) in your inventory: ..." when the list changes.
- shop_pay_owned (runtime, default true; 04_rando_settings.lua, 10_rando_runtime.lua). Seeds unchanged.
- Offline: tests/dev9/test_owned_dev9.py (harness vendor, 4 seeds): an owned slot weapon pays its bonus once and only it, not at
  the first look, "failed" and a one-look ownership pay nothing, RANDO_OMEGA.held pays, a purchase pays once, shop_pay_owned =
  false pays nothing, every weapon owned pays every bonus once, nothing before the vendor is known; O.held_pass on fake records.
  tests/dev8 shop / xp / armor / enemy still pass.
- Not run in the game.

## v0.71-DEV8 (kit 10.0.38; dev kit, not released): the shop is written once, armor phantoms, enemy_compat = "max", weapon XP

ROUND 60 (rivet.log of DEV7 + the DEV8 shop-fix files; seed clank-pocket-rift-774).
- SHOP (12_rando_shop.lua). The vendor was searched and written four times: the first try ran past the 8 ms frame budget at the
  slot writes (12_rando_shop.lua:573), BEFORE its mark, and each later try read the weapons already written as the slots' own.
  The Enforcer's slot (selling the Ricochet) was taken for the Ricochet's slot and given the Void Repulser; the closed slots
  all read "burst_pistol" and counted once, so the Mr. Fungi, Negatron, Lightning Rod and Drillhound slots were not found:
  4 of 8 weapons for sale, Bouncer / Cold Snap / Enforcer / Glove of Doom "given directly", 3 of 6 bonuses on closed slots,
  "prices left as they are" (the price field held other slots' prices). Fixes:
  - H.orig / H.match_at: every slot write is recorded (address -> the slot's own weapon, the value written) BEFORE it is made,
    for the session; a search reads such a slot as its own weapon. Prices the same way (H.price_orig). A reloaded config
    never holds a written value at the same address, so nothing stale is used.
  - The writes start in a fresh frame (one yield after the search); the check compares with what was read (sl.cur).
    A slot that already holds the seed's weapon is not written again; a slot that must sell its own weapon is put back.
  - REROUTE: a seed slot the vendor lacks sells its weapon in one of the vendor's closed slots (earliest first), its bonus
    and price go with it (H.shown, H.price_key); "given directly" only when no closed slot is left.
  - Offline: tests/dev8/test_shop_dev8.py (harness vendor, budget kill emulated after 2-24 writes, 5 seeds): memory and
    stock equal the uninterrupted run; DEV7 fails it (77 failures). Reroute with two missing slots: weapons and bonuses paid.
- ARMOR (13_rando_armor.lua). The Galactic Ranger helmet (Sargasso pocket dimension, not intercepted) paid Omega Warmonger by
  polling. At CHK_CPZ_00_INTRO_CINE 16 pieces read owned in one poll and all 16 sources were paid at once. A.MASS (3) or more
  new pieces in one poll are phantoms (state.armor_phantom; RANDO-ARMOR PHANTOM), cleared when they read not owned again;
  nothing is polled during a load and A.SETTLE frames after. tests/dev8/test_armor_dev8.py (DEV7: 17 paid; DEV8: 1).
- ENEMIES (16_rando_spawners.lua). 2,348 spawns, 129 replaced. enemy_compat = "max" (dev default; "all" = DEV7): mixed
  movement (enemy_mix_movement defaults on in max), V.compat_allows accepts every pair, V.combat_reject only logs
  ("COMBAT WATCH ... kept"). A pool shark still takes flyers only (r.strict_group). The 5-retry safety net and story boss
  areas are unchanged. Round 60 estimate: ~400 more spawns eligible (243 "rejected", 40 "no other flyer", walker spawns on
  levels with a flyer). Not changed: timing ("original despite a change" 756, "spawned before the randomizer read" 214).
- WEAPON XP (02_rando_generator.lua, 10_rando_runtime.lua, 17_rando_omega.lua). Generator: weapon_xp (default false: not in
  the fingerprint, 160 seeds identical to DEV7), weapon_xp_percent 25, weapon_xp_min/max 2000/20000; "filler:xp:N" on that
  share of the currency locations (own stream "#weapon_xp#"; items never move); audit and spoiler know it. Runtime: pay()
  queues state.xp_pending; O.xp_pass writes WeaponItemPrius.XP (+16 from the id) of a held record (slot < 5000, ItemCount 1)
  once the layout is trusted - weapon_xp_target "smart" (Omega first, least XP) | "lowest"; read back; a checkpoint load that
  takes it back is given again (2x). tests/dev8/test_gen_dev8.py, test_xp_dev8.py. Dev settings: weapon_xp = true.
- Not run in the game.

## v0.71-DEV7 (kit 10.0.38; dev kit, not released): readable bonus notes, shown when you talk to Ms. Zurkon, and item text on her screen

ROUND 59 (DEV6 in the game): the one long corner note showed 2-3 words and was cut off, it came ~20 s into a load, and her screen
still named only the weapons.
- 12_rando_shop.lua: H.announce_bonuses queues one short "center" message per bonus (H.msgq / H.pump_notes, 4 s each, ~4.8 s apart).
  H.watch_signals subscribes the event names that could mean "vendor opened" (VENDOR_SIGNALS, missing ones skipped silently) and shows
  the notes on the first hit (not twice within 30 s); generic names (interaction, dialog, menu) are only logged (VENDOR-EVIDENCE, max 40).
  With no vendor signal ever seen, the notes follow a purchase. shop_note_when = "vendor" | "load" | "both".
- H.rename_tick / H.rename_pair (shop_rename = "desc" | "name" | "probe" | "off"): the weapon item config of a bonus slot gets the
  bonus item's name text in its description (or name) field; same field type on both sides only, read back, put back when the bonus
  is paid, applied again once per load. RENAME-PROBE logs the fields of both configs. Not tested in the game.
- dev(debug).lua: key \ shows the same short notes.
- Seeds unchanged. Offline test with a stub vendor and configs (notes, signal, swap, restore on purchase): passes. Not run in the game.

## v0.71-DEV6 (kit 10.0.38; dev kit, not released): the shop bonuses are announced even when the vendor is not rewritten

ROUND 58 LOG (rivet.log of DEV5): the bonuses paid (Q-Force boots, Glitch), but no TABLE / VERIFY / BONUS line was logged: the vendor
was never rewritten, so Ms. Zurkon sold her usual weapons and the bonus note - which only ran after a rewrite - never appeared.
The vendor screen shows the weapon's own game text, which a script cannot rename.
- 12_rando_shop.lua: H.maybe_announce names every pair ("Topiary Sprinkler = Q-Force boots") on screen and in rivet.log
  (RANDO-SHOP BONUS), ~20 s into each of the first 3 loads, with or without a vendor rewrite; paid bonuses are left out.
- New RANDO-SHOP STATE line (once per load and reason): why the vendor is not rewritten (mode, helper, lookups).
- The helper-address log block ran under the 8 ms budget and aborted the tick; it is now deferred and under pcall.
- Seeds unchanged. Not run in the game.

## v0.71-DEV5 (kit 10.0.38; dev kit, not released): the shop bonuses pay; shop evidence moved to later frames

ROUND 57 LOG (rivet.log of DEV4): VERIFY 28 of 28 slots kept the seed's weapon; the purchases (BurstPistol, Dimensionator,
MrFunGuy) logged "not a weapon of this kit's registry" / "no bonus rides on it", so no bonus was paid. Causes and changes:
- 12_rando_shop.lua H.weapon_of_purchase: a purchase is matched by WeaponConfig (double, within 4096 of the id) and by the
  normalized name (config name mrfunguy, key mr_fungi, display name); WEAPON_MRFUNGI was never "wpn_mrfungi_item.config".
- H.apply: the field dump (EVIDENCE field +0x..), the unknown-entry list, the optional items and the prices run after a
  frame break, from the pre-write copy of the array. Round 57's prices and EVIDENCE were swallowed by the 8 ms budget.
- H.apply_prices checks every slot still sells what was written before writing its price.
- New: H.announce_bonuses (corner note + RANDO-SHOP BONUS lines); shop_show_items = "notify" | "try" | "off" (runtime
  option, 04_rando_settings.lua). "try" writes gadget / armor bonuses into closed slots by item id (untested, may stop the game).
- Seeds unchanged from DEV4 (the generator was not touched).
Offline: tests/harness.py (a fake vendor in memory, lupa) - 36 runs (12 seeds x notify / try / off): slot writes, VERIFY,
prices, field dump, bonus payment by name and by config number, hosted-item payment. Not run in the game.

## v0.71-DEV2 (kit 10.0.37; dev kit, not released): Omega only on a held weapon, and early Omega for the next test

ROUND 54 LOG (rivet.log of v0.71-DEV1). Both Omega rewards were "applied" (Negatron Collider from the start, Pixelizer from
an armor pod) and the game was seen holding both flags - but the two weapon records were not alike:
- Pixelizer (given in Zurkon): item slot +12 = 1005 (the WeaponAddedEvent's WeaponType), XP 317740, ammo 16/16.
- Negatron Collider (given in the Nefarious City intro; WeaponAddedEvent 1002, "confirmed"): slot 5015, XP 0, ammo 0/0 in
  every scan of the session. 5000 + n is what every weapon the hero does not hold looks like (drillhound 5016, ...).
  So the weapon gift of the intro is gone once the game leaves Nefarious City, and the Omega flag was written on its
  EMPTY record. Every other check passes for an empty record (ItemCount 1, ammo floats, Test list), so none caught it.
  (The restored Fusion Grenade / Volcanic Eruptor have no known id and cannot be checked in this log.)
FIX (17_rando_omega.lua, 09_rando_real.lua):
- O.empty_slot(): slot >= 5000, XP 0, ammo 0. set_flag never writes (or reports "already") on such a record, the keep
  loops stay quiet about it, read_game_omega does not count it. The reward stays pending, so "Omega X is yours" is only
  said for a weapon the game holds.
- O.note_empty(): the first time per load RANDO-OMEGA logs the slot, XP, ammo and 40 bytes of the record (EVIDENCE empty
  slot ...); after 900 frames it asks RANDO_REAL.regive (new, 09_rando_real.lua: one confirmed weapon queued again, the
  hub's restore for a single item) - at most 2 sends per weapon and load. A weapon the game still holds answers with
  nothing new, a lost one is added ("Given back").
NOT VERIFIED IN THE GAME: that the weapon gift is dropped when the intro ends (the log shows the effect, not the cause),
that sending it again brings it back, and that slot >= 5000 is empty for every weapon (it is for all 21 records of round54).

TEST SETTINGS (dev defaults in 04_rando_settings.lua; both off elsewhere, the public release is untouched):
- omega_early = true (generator, a new setting; not in the fingerprint while false, so every other seed is unchanged):
  the Omega versions are placed on the locations the start alone can reach FIRST (the ones that would give Bolts or
  Raritanium). Gold Bolts, Spybots, Lorbs, armor and the early weapons keep their items (an Omega on a Gold Bolt is not
  possible: G.bolt_worthy). 240 seeds (goldbolts_first / spread, on / off) all valid; with it on ~3.4 of ~13.5 early
  locations hold an Omega (2.5 without).
- omega_test = 6 (runtime, R.config; 0 = off): a weapon reward of a weapon that has an Omega version arrives AS that
  Omega version (the weapon first, then its flag) until 6 Omega weapons are held. Works on Gold Bolts, pods, missions
  and the start. The weapon reward is recorded too, so the weapon met later adds nothing and the Omega is kept.
  rivet.log: "RANDO-OMEGA-TEST <weapon> arrives as its Omega version".
Tests: the dev repo's suite was not run for this change (no access in the session); see docs/TESTING.md 2-dev6.

## v0.71-DEV1 (kit 10.0.36; dev kit, not released): the shop by config pointer, Spybots and Lorbs that pay

SHOP (12_rando_shop.lua, dev settings shop = "shuffle" again). Rounds 17-45 always found an array at +0x48 of
Ms. Zurkon's VendorConfig but never a weapon's 64-bit id in it or in the objects it points to. Two findings:
- rivet.config() cannot show ItemDatas at all: rivet_hook 2.0.0's ddl::values_of() skips arrays of structs
  (src/ddl_visit.cpp), so DEV5's probe (round54: 9 plain numbers) never said anything about the slots.
- A field naming another config is most likely a POINTER to that loaded config. rando_give.dll kind 7 (the lookup
  that already finds the vendor) now also gives the address of every weapon the seed can put in a slot, once per
  load (~20, the Burst Pistol first; 09_rando_real.lua serves kind-7 lookups every frame instead of every 30th).
  An 8-byte field equal to one of those addresses counts as that weapon, in both layouts (inline elements and
  slot objects); a write puts the new weapon's config address there and reads it back. Ids are still tried; one
  form per array, the one with more matches.
- A slot's new weapon whose config is not loaded keeps the slot's own weapon and is given directly.
- Neither form found: once per session RANDO-SHOP EVIDENCE logs the config's first 0x100 bytes, the first 0x40 of
  every array in it and some looked-up addresses - the next round's data.
- Nothing during a load (10_rando_runtime.lua: the shop tick needs not R.loading; a running search is dropped).
- Fixed while testing: the slot-object vote tie-break compared "offset:form" as TEXT ("112:ptr" < "16:ptr") and
  chose the next object's Item (+0x70) - every slot would have been written one object further on. Now numeric.
NOT VERIFIED IN THE GAME: that Item is a config pointer. The simulator's S.vendor_item_pointers is that ASSUMPTION.

SPYBOTS AND LORBS (dev settings collectibles = true; the generator already placed items there: 400 dev seeds,
~9.6 non-currency items per seed on the 22 locations, all valid). round54's "events subscribed 23/23" shows the
bound classes RYNOPlayPickedUpEvent, RYNOScriptPickupEvent and RuinPlayPickedUpEvent exist in the game; no pickup
has been logged yet.
- 05_rando_bindings.lua: RuinScriptPickupEvent also pays a Lorb (if the game has it; listed otherwise).
  collectible_watch: 9 more class names, subscribed log-only - the start lists which exist ("RANDO-COLLECTIBLE event
  classes watched ... | not in this game: ..."), and the first 5 of each are logged with their fields.
- 10_rando_runtime.lua: R.collectible_status / R.claim_collectible; RANDO-COLLECTIBLE says "(the game's event)" or
  "(by hand)"; a claim never goes past the seed's last Spybot / Lorb.
- dev(keys).lua (and dev(debug).lua): F2 / F3 show Spybots / Lorbs paid and the next reward; Ctrl+F2 / Ctrl+F3
  twice pay a pickup the game did not report (settings key_spybot / key_lorb).
- CraiggerBears stay out (no count, no event known).
Tests: tests/test_v071_dev1.py (14). Suite 922 run, 0 failures, 22 skipped.

## v0.70 (kit 10.0.35): v0.62-DEV14 released

The public v0.70 package (tools/build_public_release.py) is this kit without developer files, boss.lua or chaos.lua,
with the player's settings (release/04_rando_settings.lua). The private dev line continues on fix/v0.62-dev5.
- Kit 10.0.35 and the release label v0.70 everywhere (01_rando_data.lua and the dev scripts had stayed at 10.0.29
  through DEV10-DEV14, which were built outside the repo).
- 10_rando_runtime.lua: one Omega reward logged "received <name>" twice (grant() and R.grant_omega(); round54
  lines 622-623 "received Omega Ricochet" x2). Only grant() logs it now. It was always one reward.
- Tests caught up with DEV10-DEV14 (they were never run on those builds; 63 failures against DEV14):
  - version pins 10.0.29 / v0.62-DEV9 -> 10.0.35 / v0.70; dev(debug).lua rebuilt from the single files;
  - omega_weapons is on by default since DEV12 (the player's decision): the 10.13/10.15 compatibility tests now
    set omega_weapons = false explicitly, and round24's fingerprint 8869cc994ae4 is checked with it off;
  - the Omega status reads "Omega found/total" (DEV12); VERSION.txt is a kit file (DEV10);
  - DEV10's starvation guard runs a short Omega slice under FRAME_HARD: the busy-frame test now fills the frame;
  - an Omega reward is a flag on its weapon, not a delivery: the whole-seed test skips omega: keys;
  - tests/sim/rivet_sim.lua models rivet.script_node refusing during a load (rivet_hook 2.0.0 inspect);
  - new tests/test_v070.py (7: the load guard in the simulator, and tests/omega_sims/sim_omega_dev14.py in all six
    modes). Suite: 908 run, 0 failures, 22 skipped.
Not verified in the game: DEV14's crash fix (round55 will show RANDO-LOAD lines at each death).

## v0.62-DEV14 (kit 10.0.34; dev kit, not released): round54 - the game crashed on death, retry and load

round54 rivet.log: "RANDO-KIT release v0.62-DEV13 (kit 10.0.33)", seed ardolis-qwark-viceron-393, run 8. Omega works
(Omega Ricochet applied, "layout TRUSTED"). The game crashed when the hero died; deleting dev(debug).lua, chaos.lua,
boss.lua or turning the Enemy Randomizer off did not help. The public release and the earlier dev kits did not crash.
The log stops (no error, no "fini") right after the death's reload began: "PlanetChangedEvent OldPlanetName=NefCity",
then "direct delivery: trying again on this planet" (the NewPlanetName line was deduplicated by RANDO-DISCOVER).
A census had started just before ("reading the scene's component index (64432 components)").
- Cause (from rivet_hook 2.0.0's source, src/game_thread.cpp and src/ddl_visit.cpp): the scripts run mid-frame on the
  game thread; when it stops pumping for 250 ms - every load: death, retry, checkpoint, save load, travel - rivet_hook
  runs them from the RENDER thread while the game frees and rebuilds the level on its own threads. rivet.read checks
  each address with VirtualQuery, but the game can release the page between that check and the copy: an access
  violation that kills the game without a line in rivet.log. DEV13 is the first kit that walks the whole component
  index (tens of thousands of reads a frame) and starts it again 150 frames after every checkpoint load (the DEV13
  checkpoint hook) - so the census was running when the reload began. Before DEV13 the census never got this far
  (nothing trusted) and the public release has no Omega census.
- rivet.time_scale() does NOT raise on the render thread (only setting it does), so 09_rando_real.lua's "loading"
  check never saw a load: deliveries could go out mid-load too.
- 10_rando_runtime.lua: R.loading_now() asks rivet.script_node(0), which off the game thread answers "nodes can only
  be read on the game thread, and it is not pumping (loading?)" before touching anything, and on the game thread
  refuses handle 0 at once. A frame 0.25 s or more after the previous one counts as a load too. R.update_loading runs
  first in every frame; logged as "RANDO-LOAD a load began ..." / "RANDO-LOAD the load is over (N frames)".
- 17_rando_omega.lua and 16_rando_spawners.lua get ready = false during a load (nothing read, nothing written).
  O.on_loading (every loading frame) drops every address Omega holds - census, records, snapshot, jobs, handle cache -
  and the search waits O.SETTLE frames after the load ends. The Omega logic itself is unchanged: the layout, the
  randomizer's Omega rewards and the game's Omegas stay known and are read/kept again after the load.
- 16_rando_spawners.lua: turning the Enemy Randomizer off puts its spawners back only outside a load.
- 09_rando_real.lua: game_running() is false during a load, and the settle wait after a load starts when it ends.
Tests: tests/sim_omega_dev14.py (DEV13's modes round53, checkpoint, ngplus, ngplus_xp0 plus death - the hero dies in
the middle of the census, the items are freed and rebuilt - and hitch - the load seen only as a 0.4 s gap) passes
on seeds 1-3. Against DEV13's scripts, death fails "nothing read during the load". The whole kit in the dev repo's
rivet simulator: no load error, no RANDO-ERROR across three reloads, the load check fired on all four loads.
Not verified in the game yet: that the crash is gone (the log of the next death will show RANDO-LOAD lines).
Not changed: the generator; seeds and fingerprints are the same.

## v0.62-DEV13 (kit 10.0.33; dev kit, not released): round53 - the Omega check rejected real records

round53 rivet.log: "RANDO-KIT release v0.62-DEV12 (kit 10.0.32)", seed ardolis-qwark-viceron-393, a Challenge Mode run
(NefCity -> Cordelion -> Zurkie's -> Sargasso). Eight censuses ran; every one ended "NOT trusted: nothing is written",
so not one Omega was set (status "Omega 1/20 (flag not found yet)"); six Omega rewards from armor pods stayed pending.
- The records were right: XP, ammo and ItemCount matched (bouncer XP 417644 ammo 8/8, ryno_8 XP 819305 ...). They
  failed only "SelectedCell N" with N = 118-216 (16-20 of 25 records). round52's Pixelizer 117 was the same thing.
  17_rando_omega.lua: SelectedCell is logged, not checked. Applied to round53's own numbers, both GameEquipInventory
  censuses that ran on a settled level pass 25/25 (lines 960-967 and 1291-1298 of the log).
- During arena challenge A3 the sets swap: GameEquipInventory reads ItemCount 0 and GameOverrideInventory ItemCount 1
  (log 1383-1410). Nothing is trusted then (the override set is never a candidate); it is after the challenge.
- Two censuses picked GameOverrideInventory (24 records, all ItemCount 0) over GameEquipInventory (20): the larger set
  won. Now each of the hero's sets is checked, the one with the most passing records wins, GameEquipInventory wins a
  tie, and an Override set is never written. set_flag also re-reads ItemCount = 1 right before writing.
- The first census (37,927 components, 1795 frames) ran across three checkpoint loads; its records were other objects'
  memory (pointer pairs, ItemCount 4186226608). A checkpoint load (CheckpointTriggeredEvent Loaded=true) now drops a
  running census and the records; hooked through RANDO_TRAVEL.on_checkpoint, no new rivet.on_event (subscription limit).
- Budget kills at 17_rando_omega.lua:564 (the id scan over each 0x800-byte instance): it yields every 32 slots now.
- Challenge Mode: an Omega reward for a carried-over weapon sent the weapon again as its prerequisite; the game never
  answers for a weapon you have, direct delivery tried every target and paused ALL rewards ("the game did not react
  to any target", "5 randomizer rewards waiting"), and the Omega waited until UserEquippedWeaponEvent. A weapon whose
  trusted GameEquipInventory record holds ItemCount 1 and XP > 0 now counts as delivered, and its queued send is
  called off (RANDO_REAL.set_owned, bookkeeping only). XP 0 is not taken as proof.
Not changed: the generator; seeds and fingerprints are the same. tests/sim_omega_dev13.py (modes round53, checkpoint,
ngplus, ngplus_xp0) passes; DEV12 fails round53 the way the game did. tests/sim_omega_dev10/11.py give DEV12's results.
Not explained by round53's log: the reported crashes. The log ends with rivet's orderly shutdown ("[rivet] fini
complete") and no error just before it; the last thing running was an Omega census, which only reads.

## v0.62-DEV12 (kit 10.0.32; dev kit, not released): round52 - Omega VERIFIED IN THE GAME

tests/data/round52_rivet.log: "RANDO-KIT release v0.62-DEV11 (kit 10.0.31)". VERIFIED IN THE GAME:
- the census finds the weapons: GameWeaponItem x33-35 + GameMeleeWeaponItem x2-4; the weapon id is at instance+1152
  (instance+120 holds it too); 24-29 of 25-29 records match WeaponItemPrius's fields (Pixelizer's SelectedCell 117 is
  the one miss); a Challenge Mode save shows real values (XP 813617, ammo 300/300, Omega 1 on six weapons);
- the randomizer's write: "Omega Ricochet applied (flag set ...)", read back as Omega 1 by the next census;
- six purchases at Ms. Zurkon (Pixelizer, Bouncer, TopiaryBlaster, Tunneler, Glove of Doom, BuzzBlades) each turned the
  same byte (+0x88 from the id) from 0 to 1: "CONFIRMED in the game". NUMPAD1 answered at once ("18 weapons, N Omega").
Bug found: after loading ANOTHER save, the Omegas bought in the first save were written into it ("kept the game's
Omega bouncer - its flag had been cleared (after a load), set again"). Fixed: O.forget clears O.game_omega and O.fails
on every load; the game's own Omegas are read again after it; only the randomizer's rewards (state.omega) are kept.
Status line: "Omega found/total", total = the seed's Omega rewards (registry: location or start).
01_rando_data.lua: the 20 omega:* items verified_in_game = true (informational; seeds are unchanged).
02_rando_generator.lua (your decisions after round52):
- omega_weapons is ON by default (G.DEFAULTS): every new seed has the 20 Omega versions as rewards. A seed made with
  the old default is a different seed now (fingerprint) - set omega_weapons = false to keep it (KNOWN_ISSUES 0h);
- Omega versions are never placed on Spybots / Lorbs (collectible locations: pickup events not bound yet; round52's seed
  had 5 of 19 there); a new validation check refuses one there. Non-Omega placements are unchanged (their own stream);
  the Omega versions and the currency of the freed locations move. Seed ardolis-qwark-viceron-393 (fingerprint
  unchanged, explicit omega_weapons=true): 1 at the start, 19 on story / side / armor-source locations, none on a
  collectible. 120 default seeds (4 presets x 30): all valid, 2400 of 2400 Omega versions on locations, 0 on collectibles.

## v0.62-DEV11 (kit 10.0.31; dev kit, not released): round51 - the weapons are GameWeaponItem components

tests/data/round51_rivet.log: "RANDO-KIT release v0.62-DEV10 (kit 10.0.30)". VERIFIED IN THE GAME: the type-data census
(SceneManager.componentLookups, 32,778-52,872 components, ComponentInfo -> prius type) runs to the end without a budget
kill (974-1145 frames) and names the item classes: "GadgetSwingshotItem (GadgetSwingshotItemPrius) x1, GameGeneralItem
(ItemPrius) x11, GameMeleeWeaponItem (ItemPrius) x4, GameWeaponItem (ItemPrius) x33, VanityItem (VanityItemPrius) x160".
So the weapon items exist, but their class's prius is plain ItemPrius and no component has WeaponItemPrius: "no live
WeaponItemPrius component". The item probes show items keep NO prius holder (GameGeneralItem +0x08 = 0, 1104 bytes): the
fields are in the instance. Inventories named on the hero: GameGeneralInventory, GameMissionInventory,
GameOverrideInventory, GameEquipInventory (8552), GameProgressionInventory. NUMPAD1 queued behind the census and answered
~1000 frames later, after a warp, in one unreadable corner line.
17_rando_omega.lua:
- a weapon class is one whose name has "WeaponItem" (GameWeaponItem, GameMeleeWeaponItem) or whose prius is
  WeaponItemPrius; the whole instance (ComponentInfo +0x78 size, at most 0x800) and a prius holder, if any, are searched
  for any weapon's item id; the places most items agree on are tried in order (up to 4);
- the records of a place are checked against WeaponItemPrius's order from the id on (rcra_ddl.json): ItemCount +8 = 1,
  LastCheckpointAmmo +20 / LoadedAmmo +24 sane floats, SelectedCell +112 < 64, Test +120 a sane list, Omega +136 = 0/1.
  >= 90% of the records (at least 3) must pass, else nothing is written; every weapon's XP / ammo / cell / Omega is logged
  so the ammo can be compared with the HUD; the first record's bytes (id-0x40, 0x100) are logged once;
- owner: the hero's actor or an actor of an inventory the game named on the hero; else the only owner with >= 8 weapons;
- a class name that could not be read is not cached (it is asked again);
- a quiet frame gives a longer slice (up to 3 ms while the frame stays under 4.5 ms);
- the search ends with a centre banner "Randomizer: Omega ready - N weapons found" (or "... not trusted yet");
- O.start_job_front: a debug job runs before a census.
dev(debug).lua NUMPAD1: answers at once in the large banner - the census progress ("searching NN% (~S s)") or
"Omega: N weapons, M Omega"; details only in rivet.log.
Tested only in the memory simulator (tests/sim_omega_dev11.py: GameWeaponItem with an ItemPrius class and the fields in
the instance; a failing field check writes nothing).

## v0.62-DEV10 (kit 10.0.30; dev kit, not released): round50 - the Omega flag from the game's own type data

tests/data/round50_rivet.log: "RANDO-KIT release v0.62-DEV9 (kit 10.0.29)", installed whole. VERIFIED IN THE GAME: the
DEV9 SceneManager handle lookup - "inventory candidate GameGeneralInventory handle=2191609 size=8480 (InventoryChangedEvent,
by handle)", and four stale item handles were told apart by their slot generation ("slot generation 3, the handle's 2").
Why nothing was found: the component walk still had to finish before any handle was tried, and every
GadgetItemAddedEvent threw the walk away (it finished only after all six purchases); the Omega job runs last in the
frame, after the Enemy Randomizer, so its 3 ms room was rarely there; the level changed while the first candidate was
being read; the four item probes were spent on handles queued in the previous load. All six purchases (Pixelizer,
Bouncer, Glove of Doom, Tunneler, Ricochet, TopiaryBlaster) were new weapons: no Challenge Mode, nothing to learn from.
WeaponConfig of PurchaseWeaponEvent (8B712ADD0166xxxx for Pixelizer, ...) is the item config id the randomizer uses.
17_rando_omega.lua - THE TYPE-DATA ROUTE (rivet_hook src/game/ddl.hpp, src/ddl_visit.hpp, src/scene_query.cpp;
neptuwunium/rivet docs/ddl/rcra_ddl.json):
- the weapons are the live components whose class's prius type is WeaponItemPrius (type id 0xA89E9C3C) or
  MeleeWeaponItemPrius (0x2F1E071F), found in SceneManager.componentLookups (+0x13C8, count +0x13EC) - the index
  rivet.find_component walks. ComponentInfo +0xC8 = DDLTypeInfo*; its prius instance is Component +0x08 -> holder +0x10;
- the Omega byte's place is the live field table of that type (DDLTypeInfo +0x18 count, +0x50 names, +0x58 types,
  +0x78 offsets): ItemConfigHash +48, Omega +184 (bool) in rivet's DDL dump, i.e. +0x88 from the weapon's id. The live
  table must name both fields or nothing is written (records are then read with the dump's numbers only);
- the hero's weapons are told apart by owner (Component +0x10 = the hero's Actor*, read from GameInventoryManager);
  records of another owner are only read;
- an Omega purchase no longer teaches a byte, it confirms the type data's ("CONFIRMED in the game"); the DEV5-DEV9
  inventory search and learning stay as the fallback;
- the class verdicts (ComponentInfo -> item / weapon) are cached for the session; a census stopped by the frame budget
  continues where it was (O.dstate); a short read is retried in the next slice (O.read_full);
- starvation: after O.STARVE_FRAMES (4) skipped busy frames in a row, the Omega tick runs anyway with a 0.75 ms slice
  while the frame has used less than O.FRAME_HARD (5 ms); "inventory: ..." reports frames run / skipped;
- handles named by inventory events are resolved without waiting for the walk; a gadget no longer restarts the walk;
  the item-probe queue is cleared with every load.
dev(debug).lua: NUMPAD1 uses the records already found (else the type data) and lists the weapons that are Omega now.
Tested only in a new memory simulator (tests/sim_omega_dev10.py: SceneManager, component index, ComponentInfo,
DDLTypeInfo, holders, budget kills, busy frames, a missing field table, changed offsets, no SceneManager). The repo's
pytest suite was NOT run for this kit (the dev repo was not reachable from this session).

## v0.62-DEV9 (kit 10.0.29; dev kit, not released): round49 - the inventories are outside the hero's list

tests/data/round49_rivet.log: "RANDO-KIT release v0.62-DEV8 (kit 10.0.28)", installed whole. VERIFIED IN THE GAME: the
DEV8 budget fix - the component walk finished ("hero component list walked: 141 components"), no search was killed.
Still no weapon records: the five candidates were all picked by class name (GameInventoryManager, GameEquipManager,
HeroWeaponManagerLocal, HeroWeaponStateIdleReady(Local)). The inventories the events name on the hero
(InventoryChangedEvent { Actor = 1072366, Component = 2129937 / 2129951 / 2129975 / 2129997 / 2129999 },
GadgetItemAddedEvent { InventoryHandle = 2129937 / 2129997 }) are NOT in the hero's component list (their handles are
below the hero's own components). 17_rando_omega.lua:
- resolves a component handle through the SceneManager the way the game does (rivet_hook src/game/scene_manager.hpp:
  handle = id:20 | generation:12; +0x1398 components { Component*, generation, lookupIndex }, +0x13C8 lookups
  { Component*, ComponentInfo* }); the SceneManager comes from rando_give.dll v7 via 16_rando_spawners.lua (the same
  one the Enemy Randomizer used in this log). Those inventories are searched first ("..., by handle");
- also reads arrays of u32 item HANDLES (each item resolved, the weapon id looked for in the item and its prius data);
- logs the class and first bytes of the first 4 items GadgetItemAddedEvent names ("item handle N: <class> ...") - the
  item layout for the next round;
- an unresolvable handle is logged once with its reason (e.g. "rando_give.dll is v5, v7 is needed").
dev(debug).lua: END before HOME no longer only says "press HOME first" (round49 pressed it five times): it chooses the
planet you are on and shows its room; END again warps there.
Other round49 facts: all five purchases (Pixelizer, Glove of Doom, Bouncer, CarpetBomber, Gooner) were new weapons -
no Challenge Mode, no Omega for sale. HeroWeaponManagerLocal holds u32 weapon types (1002 / 1011 / 1012 = the
WeaponAddedEvent WeaponType numbers). One spawner scan was cut by the budget (16_rando_spawners.lua:274) and retried.
Tests 901 run, 0 failures, 22 skipped (new: tests/test_v062_dev9.py; the SceneManager inventory in the simulator,
SIM.inv_scene, is synthetic).

## v0.62-DEV8 (kit 10.0.28; dev kit, not released): round48 - the Omega search was killed by the frame budget

tests/data/round48_rivet.log: "RANDO-KIT release v0.62-DEV7 (kit 10.0.27)" - the whole kit was installed this time.
The new component-list walk never finished: rivet_hook killed the search job 19 times ("RANDO-ERROR search: ran past
the 8 ms frame budget" at 17_rando_omega.lua:23, the walk's reads). rivet_hook arms ONE 8 ms deadline per callback and
its instruction-count hook also runs inside coroutines, so a job that yields after every read still dies when the
frame is already busy. The four purchases of the run were all new weapons (VendorPurchaseEvent + PurchaseWeaponEvent):
no Omega was bought, because Ms. Zurkon sells Omegas only in Challenge Mode.
17_rando_omega.lua:
- jobs run only in a frame with room: 10_rando_runtime.lua stamps R.frame_t0 at the start of each on_frame, and the
  Omega job is skipped when more than O.FRAME_ROOM (3 ms) of the frame has gone already;
- reads are time-sliced (O.SLICE_SECONDS = 1.5 ms per resume) instead of one fixed yield per read;
- the walk keeps its place (O.wstate): a killed job continues at the next component instead of starting over;
- a search killed by an error is taken up again after 30 frames (was: the normal search interval).
Tests 891 run, 0 failures, 22 skipped (new: Round48BudgetTests in tests/test_v062_dev6.py).

## v0.62-DEV7 (kit 10.0.27; dev kit, not released): round47 - a mixed install

tests/data/round47_rivet.log: "RANDO-KIT release v0.62-DEV5 (kit 10.0.25)" with dev(debug).lua and
dev(omega_inventory_probe).lua of 10.0.26 - only the developer file of DEV6 was copied, so DEV6's Omega code never ran
(DEV5's search overran the budget at 17_rando_omega.lua:263 again; the four purchases were all new weapons with
PurchaseWeaponEvent, not Omegas). The kit check called the NEWER file "an old developer file" to delete. 10_rando_runtime.lua
now reports a developer file newer than the kit as "the scripts folder is OLDER ... copy the WHOLE scripts folder".
Shop: the read-only probe shows rivet.config(VendorConfig) answers only plain numbers (ID, IdleVOTriggerTime,
PurchaseWeaponHoldTime, TabChangeDelayDuration, Type, UpgradeCell*) - no ItemDatas, so config_set cannot reach the
slots; shop = "vanilla" stays. Tests 888 run, 0 failures, 22 skipped.


## v0.62-DEV6 (kit 10.0.26; dev kit, not released): round46 - Omega purchases did not register

Log: tests/data/round46_rivet.log (DEV5 in the game). The player bought Omega MagShield and Omega Warmonger and used
dev(debug).lua NUMPAD1 / NUMPAD2 many times; nothing was learned. Four causes, all in the log:
1. "no array of weapon records" in GameInventoryManager / HeroWeaponManagerLocal / GameEquipManager on every load (and so
   "[DEBUG] Omega: no weapon records" on every NUMPAD press). The hero's real inventories are named only by handle:
   InventoryChangedEvent { Actor = 1072366 = the hero, Component = 2129937 / 2129951 / 2129975 / 2129997 / 2129999 },
   GadgetItemAddedEvent { InventoryHandle = 2129937 }; the probe's name list was cut by rivet.log after 47 of 132.
2. An Omega purchase sends ONLY VendorPurchaseEvent { WeaponName = "MagShield" } - no PurchaseWeaponEvent, which
   O.on_purchase listened to.
3. EnteredVendorEvent never came (20 purchases), so the "before" read was never taken.
4. The search's header loop overran the 8 ms budget 60+ times (17_rando_omega.lua:263), killing the job.
Fixes (17_rando_omega.lua): O.walk() reads the hero's own component list with rivet_hook's documented layout
(Component +0x10 Actor*, +0x1C handle, +0x25 flags; Actor +0x68 list / +0x70 count; ComponentInfo +0x60 name /
+0x78 size), from an anchor rivet.component() answers and only if the walk finds that anchor again; the components the
inventory events name are searched first, then every walked class name that looks like an inventory; a second pointer
hop (item object -> its prius data at +0x08). Learning: the records are read when found and every ~5 s while the flag is
unknown; a VendorPurchaseEvent of an owned weapon with no PurchaseWeaponEvent within 20 frames is an Omega purchase
(O.weapon_of_vendor_name maps the vendor's names; round46's pairs are a test). The header loop pauses.
Also: +15 enemy template uids from round46. Tests: tests/test_v062_dev6.py (10; a simulated live layout with an
INVENTED inventory class name). Suite 886 run, 0 failures, 22 skipped. Not run in the game.


## v0.62-DEV5 (kit 10.0.25; dev kit, not released): round45 (the DEV4 log)

Asked: randomize every enemy that can be randomized (round45: 7%), Omega in the pool and one Omega at the start, Spybots
give items, the shop sells weapons that are Gold Bolt rewards, check planet travel again, a dev(debug).lua that warps to
any planet / room and holds every developer tool, upload to the private repo. Log: tests/data/round45_rivet.log.

- ENEMY RANDOMIZER (16_rando_spawners.lua): round45 Ardolis replaced 6 of 68 spawns; 49 of the 51 unchanged were "kind
  not known yet" - their template uids were not in V.REG_BUILTIN. tools/harvest_enemy_uids.py takes every enemy / boss
  uid any log named in a "learned template" line (one kind in every log, never MIXED) and V.REG_BUILTIN now has them
  (+53: 29 pool sharks, 11 swarmers, 4 robot shooters, 3 amoeboids, 2 Grunthors, 2 transports, ...). A template actor
  that answers only rivet.name is classified by that name when every known template of the name has one kind
  (V.kind_by_name). V.SOURCE_ONLY: a pool shark (GameBotPoolShark) is never a replacement - round45 put pool sharks at
  crab / pirate spawns - and its spawners take flyers only.
- OMEGA (17_rando_omega.lua): the live hero has none of ItemInventory / ItemInventoryPrius / GridInventory(Prius)
  (round45's enumeration); GameInventoryManager, HeroWeaponManagerLocal and GameEquipManager are now searched (whole
  component, up to 0x2200 bytes) for the weapon records, and once found every record's bytes are logged once
  (RANDO-OMEGA record ...). New setting start_omega (0-20, own random stream; 0 keeps every seed): the dev settings
  start every new game with one random Omega and its weapon. The flag is still written only once its byte is known.
- SPYBOTS / LORBS (05_rando_bindings.lua, 10_rando_runtime.lua): from neptuwunium/rivet's DDL - a Spybot is a RYNO plan
  (enum 0x81D3E717, 10 plans), picked up with RYNOPlayPickedUpEvent { RynoId } (RYNOScriptPickupEvent for a scripted
  one); a Lorb is a Ruin token (enum 0xECCC3486, Lorb_01..12), RuinPlayPickedUpEvent { RuinId }. Bound with the id: one
  plan pays once per run whichever event comes.
- SHOP: rounds 17-45 never found the vendor's slot array, so with shop = "shuffle" Ms. Zurkon sold her usual weapons -
  also those the seed put on Gold Bolts. The dev settings now say shop = "vanilla" (none of her weapons is a reward).
  12_rando_shop.lua logs once, read-only, what rivet.config() answers for each VendorConfig (RANDO-SHOP PROBE).
- TRAVEL (15_rando_hub.lua H.on_menu_accept): the v0.61 repair cancelled the waiting trip back only for a menu
  destination placed on a known planet; an unplaced landing checkpoint kept the 12 s timer and warped the player back
  to Nefarious City after landing where they chose (test_v060 / test_v055 "the game's order with shuffle off" failed
  on DEV4). Any menu flight that is not to the trip's own planet cancels it again.
- dev(debug).lua (tools/build_dev_debug.py): every dev(*).lua in one file (sections, switchable) plus WARP ANYWHERE /
  UNSTUCK (HOME, PAGEUP/PAGEDOWN, END, INSERT, DELETE) and an Omega record compare (NUMPAD1 / NUMPAD2 / Ctrl+NUMPAD2).
- Kit 10.0.25, release label v0.62-DEV5 everywhere (DEV4 had left tests and tools at 10.0.23: 55 failures).
- Tests: tests/test_v062_dev5.py (26). Full suite 876 run, 0 failures, 22 skipped. NOTHING of DEV5 has run in the game.


Newest first. 8.4 and 8.5 are stabilization releases: no new features, the same seeds as 8.3.

## Public Release v0.60 (beta, kit 10.0.23; dev 10.33 + the shuffle-independent trip back)

Player-visible: the Enemy Randomizer (on by default; - and Ctrl+-), Omega weapons (omega_weapons, off by default:
the in-game flag is not written yet), Install-ArsenalRestored.bat back in the download, the trip back to Nefarious
City after a finished planet with planet shuffle on AND off, rando_give.dll v7, Spybots/Lorbs hold no rewards. Not in
the download: the Boss and Chaos Randomizers, developer files. Every seed differs from v0.55. DEVELOPMENT_LOG.md has
the details.

## Dev 10.30 (kit 10.0.19; not released): combat compatibility after round40 ("enemies that could not be killed")

Asked: find and fix why some randomized enemies (the pirates with guns) could not be killed; make every replacement
combat-functional; spawn coverage; Boss Randomizer audit; one consistent release; tests. Log: round40 (dev 10.29 in the
game: Zurkon A1 twice, A3, the pub, Ardolis, Cordelion). Seeds unchanged.

- ROUND40 EVIDENCE: 40 replaced spawns, all Zurkon A1 factories, every one logged "SUCCESS". Run 1: 20 replaced, the
  game's BotDeathCompleteEvent named 12 of them - exactly the 10 brawler + 2 bladeball replacements; the 8 pirate robot
  shooters a bladeball factory spawned (DD6478DACCDD2129) never died (run 2: 13 of 20). With your report ("the
  randomized pirates with guns were unkillable") the failing pair is bladeball factory -> robot shooter. WHY that bot
  cannot die is not proven (see KNOWN_ISSUES 0w); the fix does not depend on it.
- Combat compatibility (16_rando_spawners.lua, "COMBAT COMPATIBILITY"): a replacement is a PAIR (spawner kind |
  original kind > replacement kind). V.COMPAT_BUILTIN holds the in-game evidence (3 verified pairs, 2 rejected);
  `enemy_compat = "verified"` (new setting, default) uses only verified pairs - an unverified enemy never enters the
  pool; "trial" also allows unverified pairs of the same bot class, one spawner per level, watched; "any" = 10.29's
  rules (simulator tests only). Evidence is kept in the save (`state.enemy_combat`, kept over New Game).
- Combat watch: every replaced bot is followed; a death naming it is the proof (`DEATH <bot> | ... replacing ...`,
  an unverified pair becomes verified for the save: `COMBAT VERIFIED`); a bot alive 45 s after its spawn while 6 other
  bots died = `COMBAT CHECK FAILED`: the pair is rejected (a built-in verified pair after 2 such failures), every
  spawner using it is put back at once and a corner note says so. A frame-budget error is no answer (never "alive"); a
  bot removed without a death is "gone" (no evidence either way).
- Initialization check: the components of the game's own spawns of a kind (intersection of up to 5) against the
  replacement's; one missing = the pair is rejected. VERIFY lines now say "initialization OK / MISSING ... | combat
  ... - a death of it is the proof". Per level: `COMBAT <pair>: replaced bots spawned N, died D, gone G, alive at the
  end A | pair verified/rejected/unverified (evidence)`. CHANGED lines name the template handle, uid and source.
- Spawn coverage: factories are read and planned BEFORE the level's nodes are listed (round40: 31 spawns "before the
  randomizer read its spawner", 34 "before it planned it"); the first listing 6 frames after a load (was 20); a node
  listing that fails no longer stops the scan; a factory changed early is put back if a node listed later shares its
  variable and has spawned; the watchdog runs while a long job runs.
- Boss Randomizer: on the same compatibility rules; no boss-tier pair has in-game evidence, so in "verified" it
  changes nothing (round40 shows no boss-tier swap either: "0 boss spawner(s) changed here"). The 8 story bosses stay
  protected (unchanged rules). boss.lua logs this; Ctrl+`=` shows the mode.
- One release: every script tagged 10.0.19, banner "Randomizer dev 10.30", the route line names the release; the
  developer tools moved to `mod/RiftApartRandomizer/dev_scripts/` (the scripts folder holds only the release); a
  dev(name).lua of another kit left in <game>\scripts is named for deletion (round40: dev(spawnprobe).lua caused all
  10 "ran past the 8 ms frame budget" errors).
- rando_give.dll: unchanged (v7, sha256 8055703e...; rebuilt byte for byte from rando_give_source by the test suite).
- tools/combat_audit.py (new): replacements per pair against the deaths per level visit of any rivet.log.
- Tests: tests/test_v1030.py (35: 11 round40 log facts, 20 simulator, 4 kit); run against dev 10.29's scripts, all 20
  simulator tests and 3 of the 4 kit tests fail (the 4th checks that the DLL is unchanged). test_v1027's simulator harness pins `enemy_compat = "any"` (its subject is scheduling);
  older tests updated for the dev_scripts layout and the 10.0.19 / dev 10.30 labels. Full suite: see TESTING.md.

## Dev 10.29 (kit 10.0.18; not released): the Enemy Randomizer overhaul

Asked: a comprehensive Enemy Randomizer, provably working, after round39 ("didn't notice any new enemies"). Seeds unchanged.

- Tying (16_rando_spawners.lua V.index_loc / V.tie_one): every node's `Location` variable (2761897147) indexed per
  listing (groups expanded by rivet.script_node); a SpawnFactory-0 spawn is tied by one lookup; a spawn point no
  listed node has waits for the next listing once (V.pump's deferred list); not-enemy spawners skip all work.
- Picks (V.pick / V.repick / V.species / V.base_name): another species first, never a size variant; a change that
  has not spawned is re-picked when the pool grows ("CHANGED AGAIN"); pick keys survive cut vs full names.
- Identity (V.asset_name): the spawned actor's full asset name through its component's actor pointer (the method
  dev(spawnprobe) used in round31-39); V.display gives player-facing names (Goons-4-Less Jetpack, Sargasso Wasp...).
- Ledger and notes (V.ledger_add / V.note / V.notes_tick): `SPAWN` line per enemy spawn (planet, encounter = the
  active mission and checkpoint, spawner, original, selected, spawned, result, reason), per-level "ENEMY SPAWNS"
  summary with reasons and per-kind counts, corner notes queued one per 3 s (4 waiting at most, the rest counted),
  setting `enemy_notify` (default true). enemy.lua Ctrl+`-`: "N of M enemy spawn(s) here were replaced".
- Robustness: process_one re-entrant (e.* marks), budget errors keep the spawn for the next frame (60 frames at most,
  then "spawns given up" in the level detail), queue 1024.
- Boss Randomizer (boss.lua) on the variable route (`boss_route = "vars"`; "census" or enemy_route = "census" keeps
  the old one): V.group_of gives boss tier its own pools (boss_walker / boss_flyer / boss_turret); story bosses,
  friendlies, mounts and unclear classes never; switching one client off puts back only its own changes.
- docs/ENEMY_RANDOMIZER_COVERAGE.md (new), tools/enemy_census.py (new). Banner dev 10.29.
- Tests: tests/test_v1029.py (25: 7 real round39 log facts, 18 simulator); 4 older tests follow the new rules.
  Full suite: 769 run, 0 failures, 23 skipped.

## Dev 10.28 (kit 10.0.18; not released): round38 fixes for the Enemy Randomizer

Asked: perfect the Enemy Randomizer (no Boss / Chaos work). Log: round38 (the first real run of 10.27). Seeds unchanged.

- Stuck rule (16_rando_spawners.lua V.watchdog): bots that no longer answer (V.gone) leave their encounter; stuck =
  bots alive AND the whole level quiet (no death of anything, no enemy spawn, no bot gone) for 180 s; it puts back for
  the level and counts a retry (5 -> kept original for the seed). V.migrate drops 10.27's "without a death" blocks.
- Frame budget: V.pump, one job whose progress lives in the level record (put-backs, spawn queue, plan cursor);
  restarted after a budget error (40 restarts without progress drop it; counted as "jobs dropped"); budget errors
  counted, not logged; the arm pass runs only when something changed (lvl.dirty). V.SLICE 1.5 -> 1 ms.
- Put-backs: V.put_back is safe (pcall); an interrupted one waits in V.pending and runs before any read; half-written
  and unreadable variables are retried; on leaving a planet (PlanetChangedEvent with OldPlanetName only) everything is
  put back while the variables are still there; after an unload the log says "nothing to write".
- Tying SpawnFactory-0 spawns (V.tie_one): per spawn, a location cache checked against the node's own record,
  LastSpawn, the spawned-actors variable 942662419, the whole 17-entry spawn ring, and for groups rivet.script_node;
  a location that tied to nothing 3 times is skipped for the level.
- V.same_kind: name AND bot family (the two thugs of one cut name). Template-actor asks stop after 40 with no answer.
- Diagnostics: "level detail" per level (why node / group spawners were not changed, untied spawns, deaths seen and
  tied, bots gone, jobs dropped); every enemy spawn tied to no spawner is logged (6 per level).
- Banner dev 10.28. Tests: tests/test_v1028.py (22: 7 on round38's real log, 15 simulator); 3 test_v1027 tests follow the
  new rules. Full suite: 744 run, 0 failures, 23 skipped.

## Dev 10.27 (kit 10.0.18; not released): the Enemy Randomizer on the proven method

Asked: rebuild the Enemy Randomizer on round37's factory method, cover every normal enemy and spawning mechanism.
Seeds unchanged. **Nothing of 10.27 has run in the game yet.**

- 16_rando_spawners.lua, new section SP.V ("the variable route"): one registry and one rule set over three adapters -
  factory `Templates` (PROVEN in round37), node `Template` one actor, node `Template` GROUP (robomutts / thugs; the
  group is replaced by one enemy, re-chosen after every spawn). Lists the level's SunsetSpawnerFactory and
  SpawnerScriptAction nodes every 2 s, reads each variable's original, learns what every template spawns (spawns,
  template actors before a spawn, the save), changes only spawners that have not spawned on this level, verifies the
  first spawn of each change, switches an adapter off for the session when the game ignores it, and puts back on
  checkpoint loads, level / planet changes, `-` off, story boss areas, stuck (180 s) and retried (5x) encounters.
- Rules: role "enemy" only (never boss tier, health-bar enemies, story bosses, friendlies, NPCs, mounts, props);
  walkers -> walkers, flyers -> flyers, turrets -> turrets; another kind; loaded on this level; seeded by enemy name
  and spawner id. Learned kinds and group members are saved (state.enemy_reg / enemy_groups, kept over New Game and
  a companion restore).
- enemy.lua: registers on the variable route (`route = "vars"`); Ctrl+`-` shows changed spawners per adapter, enemy
  kinds here / known, replaced / ignored this session. The old census route stays for the Boss and Chaos Randomizers
  (still not working) and, for the tests, `enemy_route = "census"`.
- On screen: "Enemy Randomizer: working" (first confirmed replacement of a session), "Enemy Randomizer cannot work"
  (rando_give.dll v6), "one kind of spawner cannot be changed" (adapter off), stuck / retried notes.
- dev(spawnproof).lua stands down while the Enemy Randomizer is ON.
- Banner dev 10.27, kit 10.0.18 (every RANDO_FILES tag). Tests: tests/test_v1027.py (40: rules; the production engine
  in the simulator - detection, selection, waves, checkpoints, transitions, the key, ignored writes, shared and
  regenerated variables, budget errors, errors, helper v6, health bars, stuck / retried encounters, boss areas, node
  and group adapters; round37's real factory data replayed). Old-route tests run with enemy_route = "census".
  Full suite: 722 run, 0 failures, 23 skipped.

## Dev 10.26 result (round37): first enemy replacements in the game

- spawnproof v6, two runs of Zurkon challenge A1: robot shooter -> robot melee on 3 fresh factories each run; 6/6
  REPLACEMENT SPAWNED, 20/20 spawns of those factories were robot melee; both runs completed; all put back.
- The Enemy / Boss / Chaos Randomizers do not use this route yet (they still change nothing).
- Tests: tests/test_v1026_result.py (5).

## Dev 10.26 (kit 10.0.17; not released): fresh factories only

Asked: (the rivet.log of 2026-11-18, dev 10.25, tests/data/round36_rivet.log). Seeds unchanged. **Still no replacement
seen in the game.**

- Found in the log: v5 armed factory 1109878 (Templates 1109383 robot melee -> 1109378 robot shooter): the write read
  back OK and was put back OK at the next checkpoint; challenge A1 completed. But that factory had already spawned its 4
  enemies and never spawned again (each arena wave has its own factories), so there was nothing to verify.
- dev(spawnproof).lua v6: one EXPERIMENT = one enemy kind -> one other kind on every factory that has NOT spawned yet
  and holds the original (up to 8); each verifies on its own first spawn; a spent factory is never chosen; at most 3
  experiments a session; on-screen names fixed ("SPAWNPROOF ARMED: robot_me should now come as robot_sh").
- Banner dev 10.26. Tests: tests/test_v1026.py (6, real log); test_v1025's simulator tests follow v6. 677 run, 0 failures, 23 skipped.

## Dev 10.25 (kit 10.0.17; not released): the factory's Templates variable

Asked: "still nothing" with the rivet.log of 2026-11-18 (dev 10.24 helper, spawnproof v3 scripts,
tests/data/round35_rivet.log). Seeds unchanged. **Still nothing randomized in the game.**

- Found in the log (first run of the experiment): SceneManager found, 197 nodes, 970 spawns tied - but no swap:
  v3 only changed SpawnerScriptAction variables. The arena's enemies come from SunsetSpawnerFactory nodes whose own
  "Templates" variable (3990217346 = hash "Templates"; also "Locations", "InitialCount") holds the enemy: A1's 11
  factories held 3 Templates values, each always spawning one kind (robot shooter, robot melee, bladeball); the spawn
  location is the factory's Locations value.
- dev(spawnproof).lua v5: lists the level's SunsetSpawnerFactory nodes and their Templates variable; learns Templates
  value -> enemy from every factory spawn; swaps ONE factory's Templates value for another learned enemy's (same role,
  another kind; checked, read back; one experiment at a time, a factory that already spawned first); verifies the next
  spawn of every factory using that variable and logs its next 6; puts it back on the next checkpoint / level, or at
  once if it was not replaced (then a fresh factory is tried). Learned names / roles are no longer overwritten by nil.
- Banner dev 10.25. Tests: tests/test_v1025.py (11). 671 run, 0 failures, 23 skipped.

## Dev 10.24 (kit 10.0.17, rando_give.dll v7 IN THE KIT; not released): the helper that was never copied

Asked: "Nothing changed" with the rivet.log of 2026-11-18 (dev 10.23, tests/data/round34_rivet.log). Seeds unchanged.
**Still nothing randomized in the game**; the experiment has still not run.

- Found in the log: the 10.23 planet fix worked (spawnproof "ON ZURKON - active", RANDO-PLANET Zurkon scarstu, every
  Zurkon checkpoint "on scarstu"). The experiment stopped at its first step: "no script variables: rando_give.dll is
  v6, v7 is needed". v7 lived only in rando_give_source/dev_build and had to be copied by hand.
- The kit's rando_give.dll is now the v7 build (sha256 8055703e...): it ran in your game in round32 (SceneManager found
  1x, direct delivery ready, armor give verified, mission helper ready). dev_build/ is gone. The verified v6 binary moved
  to rando_give_source/release_v6/ and tools/build_public_release.py packages that one (public packages unchanged).
- dev(spawnproof).lua v4: "SPAWNPROOF BLOCKED: <why>" on screen and "BLOCKED:" in rivet.log on every Zurkon level
  where it cannot read script variables.
- Banner dev 10.24 (kit scripts still 10.0.17). Tests: tests/test_v1024.py (10). 659 run, 0 failures, 23 skipped.

## Dev 10.23 (kit 10.0.17, rando_give.dll v7 developer build; not released): the lost planet

Asked: "Enemies/bosses didn't got randomized" with the rivet.log of 2026-11-18 (dev 10.22,
tests/data/round33_rivet.log) and a brief: find the real blocker, no speculative implementation, honest status.
Seeds unchanged. **Still nothing randomized in the game**; nothing of 10.23 has run there.

- Found in the log: spawnproof v2 loaded and wrote nothing else. The companion started late (seed = random), the
  pre-seed event buffer (500) filled on NefCity, and the PlanetChangedEvent to Zurkon was dropped: the session
  logged only "RANDO-PLANET NefCity" and every Zurkon checkpoint "on nefarious_city". v2 only acted on "scarstu",
  so the Factories experiment never ran. Nothing about the Factories mechanism was learned, for or against.
- 10_rando_runtime (kit fix): planet, level, checkpoint, save, mission, objective, item, bolt and purchase events are
  never dropped from the pre-seed buffer (up to 2000); the rest keeps the 500 bound; the replay line says what was
  dropped. Without it, a late companion meant a whole session on the wrong planet (travel, hub, rewards too).
- dev(spawnproof).lua v3: own PlanetChangedEvent / SpawnerSpawnEvent subscriptions (not buffered); "on Zurkon" from
  the event's planet name; a "level reset ... active / inactive" line every level and "inactive: N spawn(s) ignored";
  ARMED and VERIFY shown on screen; a spawn delivered twice counts once.
- ENEMIES_AND_BOSSES.md / CHAOS.md now open with "NOT WORKING IN THE GAME".
- Kit 10.0.17, banner dev 10.23. Tests: tests/test_v1023.py (21). 650 run, 0 failures, 23 skipped.

## Dev 10.22 (kit 10.0.16, rando_give.dll v7 developer build; not released): the Factories variable

Asked: "tried 2 battles, 1 normal enemies, 1 boss. Nothing randomized. Solve." (rivet.log of 2026-11-17 with
dev 10.21, tests/data/round32_rivet.log). Seeds unchanged. **Still nothing randomized in the game**; nothing of
10.22 has run there.

- Found in the log: v1 never armed because the arena's enemy nodes have no "Template" variable; their only
  variable is "Factories" (838143302, a SunsetSpawnerFactory node), cached in their Spawner component at +0x48.
  All 104 Template nodes on Zurkon spawned rift portals. v1's jobs also died on the 8 ms frame budget, and it
  logged only the first 12 spawns of a level.
- dev(spawnproof).lua v2: Template AND Factories slots; spawns tied by LastSpawn or by the Spawner's slot list
  (+0x9C count, +0xDC 12-byte entries, checked on real bytes); up to 4 swaps a session (2 at a time), only on
  nodes not yet seen spawning; the Spawner's cached copy written too when the node is already active; budget
  errors retried; per-level summary; factories described with their own variables.
- Banner dev 10.22. Tests: tests/test_v1022.py (20); test_v1021's simulator tests follow v2's wording.

## Dev 10.21 (kit 10.0.16, generator 10.11.0, rando_give.dll v7 developer build; not released): the Template variable

Asked: make the Enemy / Boss / Chaos Randomizers work, starting with one proven replacement (rivet.log of
2026-11-17 with dev 10.20, tests/data/round31_rivet.log). Seeds unchanged. **Still nothing randomized in the
game**; nothing of 10.21 has run there.

- Found in the log: a SpawnerScriptAction node's variable plugs "Template" / "Location" / "LastSpawn"
  (actors), "NumSpawns" / "MaxAlive" (floats); neither component has Prius data. The probe lost two
  subscriptions to rivet_hook's 64-callback limit, so no arena encounter was observed.
- rando_give.dll v7 (developer build in rando_give_source/dev_build): publishes the SceneManager found with
  rivet_hook's own signature. The kit's rando_give.dll stays the verified v6.
- 16_rando_spawners: SP.listen for developer files (no rivet callback of their own).
- dev(spawnprobe): uses SP.listen; prints actors variables; fewer component lookups per spawn.
- New dev(spawnproof).lua: one controlled Template-variable replacement on Zurkon, verified on the next
  spawn and put back when the encounter's Spawner stops.
- Tests: tests/test_v1021.py (14). 609 run, 0 failures, 23 skipped.

## Dev 10.20 (kit 10.0.15, generator 10.11.0; not released): evidence, not another guess

Asked: "Dev 10.19 still does NOT work in the actual game" (rivet.log of 2026-11-17 with dev 10.19,
tests/data/round30_rivet.log). Seeds unchanged. **The Enemy / Boss / Chaos Randomizers still change nothing
in the game**; this version does not claim otherwise.

- Root cause of 10.19's failure (the log): the Spawner component found through node +0x60 has no Prius
  either (ddlPriusData 0) and no list pointer in the bytes the log kept; no census has ever read a node.
- 16_rando_spawners: dumps in lines of 96 bytes (rivet.log keeps 1024 characters of a line; 10.19's
  432-byte dumps lost 126 bytes); three empty lists (zeroed memory) are no longer a "factory-only spawner".
- New developer file dev(spawnprobe).lua (read-only, never in a release): per level an index of every
  spawner node and its Spawner component (handle checked), the spawned actors, the Spawners that change
  while you fight, deep probes (component type data, bytes, pointers, a rivet.find_uid search for template
  uids).
- Tests: tests/test_v1020.py (17; the 3 on the spawner layer fail against 10.19, the probe tests need the
  new file). 595 run, 0 failures, 23 skipped.

## Dev 10.19 (kit 10.0.14, generator 10.11.0; not released): the node's Spawner component

Asked: "no enemy/boss randomized" (rivet.log of 2026-11-17 with dev 10.18, tests/data/round29_rivet.log).
Seeds unchanged. **Tested in the simulator only.**

- Cause (10.18's dumps): SpawnerScriptAction's ddlPriusData is 0; +0x60 holds the handle of its Spawner
  component (own handle + 1 in all six dumps). Spawner = SpawnerPrius's component (hash 4233548849).
- 16_rando_spawners: SP.spawner_of (the node actor's Spawner component, handle checked against +0x60), its
  Prius via SP.find_prius (short layout; new `inline` route for lists copied into the component); rec
  remembers the component's handle (SpawnerStopped/Started events match it); diagnostics when it is not on
  the node's actor; first start/stop events logged per level.
- The census retries a node interrupted by the frame budget (pcall + yield) instead of restarting; 8
  restarts allowed. The level-wide Spawner scan is off by default.
- Simulator: `comp` node model (prius / holder / inline / elsewhere), bot-sent spawn events.
- Tests: tests/test_v1019.py (11; 8 fail and 1 errors against 10.18). 578 run, 0 failures, 21 skipped.

## Dev 10.18 (kit 10.0.13, generator 10.11.0; not released): spawner Prius reached by hand

Asked: "Still nothing randomized. Take your time, investigate and fix, and make no mistake." (rivet.log of
2026-11-17 with dev 10.17). Seeds unchanged. **Tested in the simulator only** (now modelled on both logs).

- Cause: rivet_hook returns no `prius` for SpawnerScriptAction (its find_component follows only
  ComponentInfo.prius); the 128-byte instance is ScriptAction's header + 32 bytes. 10.17 relied on rivet's
  `prius`, so every node was skipped again.
- 16_rando_spawners: SP.find_prius - rivet's prius, then `ddlPriusData` (+0x08) -> holder -> data, then
  pointers in the node (as Prius or holder), then a bounded deep search; strict candidates need
  ActionType 60 or a loaded actor's uid; the path that worked is followed first; bytes dumped when nothing
  works. Placed `Spawner` components read too. Capacity of the lists no longer checked (only the count).
- Learning from template actors at the census (`rivet.find_uid` + `rivet.components`; Templates are TUIDs).
- Verification log on each changed fight's first spawn; `spawn:` match lines for the first 5 spawns a level.
- Fixes: a census of the previous level is dropped on a level change; spawns before the census mark their
  spawner started; template learning survives the save being replaced; census yields inside long searches.
- Chaos: another planet's template only where its template actor is loaded.
- Simulator: `rivet.uid` / `rivet.components` were defined inside `rivet.component` since 10.17 (only after
  it ran); moved out. New node models: holder (your game), ptr, deep embed/ptr, Spawner components, shared
  Prius, template actors. Real logs kept as tests/data/round27_rivet.log, round28_rivet.log.
- Tests: tests/test_v1018.py (18); 567 run, 0 failures, 21 skipped.

## Dev 10.17 (kit 10.0.12, generator 10.11.0; not released): Enemy / Boss / Chaos Randomizers fixed

Asked: "enemy, boss and chaos randomizer didn't work. Fix it" (rivet.log of 2026-11-17, dev 10.15 kit with
10.16's defaults). Seeds unchanged (generator untouched). **Tested in the simulator only.**

- Cause: all 32 censuses in that log read 0 spawner nodes; every node "cannot read the node". rivet_hook's
  `rivet.component` returns the instance (`size` = class size) and, separately, the Prius data (`prius`).
  The census read only min(0x100, size) bytes of the instance and needed 0x88, so nothing was read,
  nothing learned and nothing changed, for all three randomizers (they share 16_rando_spawners.lua).
- 16_rando_spawners: the census reads the Prius at the DDL's offsets (FactoryGroup +8) with the same
  signature check; the instance search is kept only when rivet gives no Prius. The census line says
  `layout prius +0x8 xN`; a skipped node says why (the Prius, or the instance's size).
- Spawns: handlers also take `ev.sender`; a spawn with no sender is matched by its SpawnLocation actor id
  (`rivet.uid`) in one node's SpawnLocations list (the real event has SpawnFactory / SpawnIndex /
  SpawnLocation / SpawnedHandle).
- Learning: one `rivet.components` call per spawned actor (the old ~90 failing `rivet.component` calls stay as
  fallback); unknown bot classes are logged once (`spawned actor not classified`).
- Frame budget: a census stopped by the 8 ms budget starts again 20 frames later (up to 5 times) instead
  of waiting for the next load.
- Tests: tests/test_v1017.py (10, a simulator model of what the log shows: small instance, Prius, no sender);
  test_v1012's kit-check test fixed for 10.16's ON defaults. 548 run, 0 failures, 21 skipped.

## Dev 10.15 (kit 10.0.11, generator 10.11.0; not released): Omega weapons

Asked: Omega weapons (Challenge Mode / New Game+) in the randomized item pool as items of their own,
with weapon and Omega ownership kept apart and never downgraded. **Nothing of this has run in the
game.** Built on dev 10.13 (the repository's latest; the 10.14 patch was never pushed, so it is not in
here). Seeds unchanged unless `omega_weapons` is turned on. OMEGA.md has everything.

- Research: an Omega weapon is not an item id; it is the bool `WeaponItemPrius.Omega` of the weapon you
  own, set only by Ms. Zurkon's Omega purchase (the game's type data; no Omega config in your dag).
- Data: 20 items `omega:<weapon>` (one per vanilla weapon; category `omega`, the weapon's own id,
  in-game names from the guides). Data version stays 5.1.0.
- Generator: `omega_weapons = false`. On: the same seed plus the 20 Omega versions on locations that
  would give currency (own stream; the placement random streams ignore the new setting); never Gold
  Bolts, shop or random start; `start_items` / `exclude` take `omega:` keys; the audit checks them; the
  spoiler lists them. Off: same fingerprint and spoiler as 10.13 (tested against git).
- Runtime (10): a tier per weapon (`state.weapons`, `state.omega`, `state.omega_prereq`). An Omega
  first gives its weapon first; a weapon after its Omega sends nothing and keeps the Omega; repeated
  rewards are recorded once; saved, merged (furthest status), reset by a New Game.
- `scripts/17_rando_omega.lua` (new, optional, **never in a player package** until it has run in the
  game): finds the weapon records in the hero's inventory component by the item ids, learns the flag's
  byte from two Omega purchases at Ms. Zurkon (or `omega_flag_offset`), writes one byte with read-back
  for weapons the game has confirmed, and sets a cleared flag again after loads and resends.
- 10: `omega_runtime = true`, `omega_flag_offset = -1`; status `Omega n/m`; 17 is an optional kit file.
  Kit 10.0.11, banner `Randomizer dev 10.15`.
- Release tools: `17_rando_omega.lua` is in `HELD_BACK` (builder) and rejected by `validate_release.py`.
  The public release and `release/` are untouched.
- Tests: tests/test_v1015.py (32); 536 run, 0 failures, 21 skipped. Older tests changed only where the
  kit version, the banner, the script list or the subscription count changed.

## Dev 10.13 (kit 10.0.9, generator 10.11.0; not released): Chaos Randomizer

Asked: a third, independent randomizer: **anything can become anything**, with no compatibility
rules and no progression protection. OFF by default, its own key, saved, priority over the Enemy and
Boss Randomizers while ON. **Nothing of this has run in the game.** Seeds unchanged.

- `scripts/chaos.lua` (new, optional, **never in a player package**): **`BACKSPACE`** turns it on /
  off (`Ctrl+BACKSPACE`: what it changed here). Every spawner slot can become any enemy template seen
  on any planet of the save (`state.chaos_seen`) or learned by 10.12: regular, elite, flyer, turret,
  large, boss tier, story boss and unclassified, in both directions. Each slot gets its own seeded
  pick. Repeats are avoided until the pool is used up, and a slot never keeps its own template.
  No guards: no family / tier / planet rule, no timeouts, no retry limit, no story boss areas, no
  "not started" rule, no put-back, nothing that forces progression. Only learned friendly bots and
  mounts are left out (they are not enemies). Code integrity stays: live-instance check, read-back,
  game-used ids only, shared lists not written. `docs/CHAOS.md` explains the risks.
- Priority: while Chaos is ON the Enemy and Boss Randomizers change nothing and keep their own
  settings. Chaos OFF puts its slots back and they plan again (exactly their own picks).
- `16_rando_spawners.lua` (shared integration): priority clients with their own `assign`, clients
  with `guards = false` (their slots skip every safety net), census and restore hooks for clients,
  the record of writes pruned when nodes are gone. Enemy / Boss behaviour unchanged (tests/test_v1012.py
  passes unchanged).
- 10: settings `chaos_randomizer = false`, `key_chaos = "BACKSPACE"`, `chaos_cross_planet = true`; the
  status line; chaos is an optional kit file. Kit 10.0.9, banner `Randomizer dev 10.13`.
- `tools/build_public_release.py` holds `chaos.lua` back (`HELD_BACK`), and
  `release_tools/validate_release.py` rejects a package that contains it.
- Tests: tests/test_v1013.py (23), simulator only (nodes can belong to one planet now). 504 run,
  0 failures, 21 skipped. `TEST_REPORT_10.13.md`.

## Dev 10.12 (kit 10.0.8, generator 10.11.0; not released): Enemy Randomizer and Boss Randomizer

Asked: an Enemy Randomizer and a Boss Randomizer as two separate, independently switchable
features (`enemy.lua`, `boss.lua`), both OFF by default and switched in the game; randomized enemies
and bosses must still open doors, finish objectives and advance the story. **Nothing of this has run
in the game.** Seeds are unchanged (the generator is not touched): a 10.11 save continues.

New files (all optional, ENEMIES_AND_BOSSES.md):
- `scripts/16_rando_spawners.lua`: the layer both share. Reads the level's SpawnerScriptAction
  nodes (the game's combat encounter spawners), finds their Templates list by the DDL layout's
  signature (never a fixed offset), learns what each template is from the bot component of an actor
  the game spawned, and changes **only template ids**. The encounter's own node spawns, counts and
  completes the new enemies, so its doors, objectives, waves and story steps follow from the game's
  own logic, once, after the last enemy. Safety nets put an encounter back (and keep it original for
  the seed) when a replacement spawns nothing for 20 s, stays alive 180 s without a death, is another
  family than planned, or the checkpoint is loaded 3 times during it; story boss areas put every
  change back while you are there.
- `scripts/enemy.lua`: the **Enemy Randomizer** (`-` key; `Ctrl+-` shows what it changed here).
  Regular enemies (turret, flyer, swarmer, ground) become other regular enemies of the same family
  from the same planet's own encounters.
- `scripts/boss.lua`: the **Boss Randomizer** (`=` key; `Ctrl+=`). Boss-tier spawns (large bots and
  any spawned enemy with its own boss health bar) are permuted among the planet's boss-tier enemies
  of the same family: none is added or doubled. The eight story boss fights are left unchanged
  (boss-specific scripts and arenas; `RANDO_BOSS.STORY` lists them and why).

Settings (runtime only, 04 documents them): `enemy_randomizer = false`, `boss_randomizer = false`
(the start of a save that never used the keys), `key_enemies = "-"`, `key_bosses = "="`,
`spawner_runtime = true`. The switches are saved like planet shuffle's (`state.enemy_rando`,
`state.boss_rando`), kept over New Game, a choice before the companion's restore wins. No preset
turns them on.

Runtime changes elsewhere: 10 (`R.subscribe`, the frame call, the status line, New Game keeps the
switches and what was learned, the restore hook, the kit's optional files), 14 (each checkpoint is
passed on). Kit 10.0.8, banner `Randomizer dev 10.12`.

Tests: tests/test_v1012.py (32) against a new simulated encounter model (tests/sim/rivet_sim.lua:
spawner nodes laid out as the DDL says, reading their Templates at each spawn, counting their dead,
firing "all dead"). 481 run, 0 failures, 21 skipped. TEST_REPORT_10.12.md lists passed, failed and
untested cases.

## Dev 10.11 (kit 10.0.7, generator 10.11.0; not released): planet shuffle that starts each new planet at its intro

Asked: make planet shuffle actually work: when the player gets new Coordinates and goes to the new
planet, take them to that planet's intro so the first mission there starts; make sure players get
to Coordinates and first visits first, not revisits. **Nothing of this has run in the game.** Every
seed changes (generator 10.11.0, a new setting): start with New Game.

Why it did not work: the hub started a planet's story only AFTER the ship's planet-menu landing,
then warped on that planet to a landing pad or a learned checkpoint. The game had already played its
arrival without the story, and a pad is not where a first visit begins (Blizar's even sat on the
intact side, round 17 shows the game landing on the destroyed one). A planet whose Coordinates came
before what its first visit waits for (Viceron before Torren IV's Hurlshot) was offered as a
"revisit" with nothing to play, and revisits sat in the `]` list between first visits.

Runtime (15_rando_hub.lua, 03, 10):
- **Next visits made active between stories** (`hub_prime_open`): at the hub, after a finish, when
  Coordinates arrive and on the planet menu's accept, the next visit of every open planet you are not
  on is made active (available, then start; no hero swap, no travel), as the game itself does when a
  visit ends (round 17: MIS_SAV_01 and MIS_BLIZAR together at the end of Zurkie's first visit). Never
  while a story runs (v0.53's rule), never the hub planet or the prologue.
- **Planet-menu landing**: a story already active before the flight is left to the game's own arrival
  (nothing loaded); one started on landing loads the visit's **intro** on that planet. A first visit
  is always loaded at its intro while its story has not left its first step (`hub_planet_intro`).
  A first step still waiting a minute later is loaded once more at the intro (or its second point).
- **Intros** (03 `intros`, from the logs): Zurkie's CHK_ZURK_00_DEFAULT, Savali CHK_SAV_01_LANDING
  (then CHK_SAV_01_START), Blizar CHK_BLIZAR_B_LANDINGPAD_DESTROYED (then the intact pad), Torren IV
  CHK_MOL_START, Cordelion CHK_CORD_A_START, Ardolis CHK_ARD_START, Viceron CHK_ZORDOOM_START,
  Sargasso 2 CHK_SARG_02_MININGPLATFORM_LANDINGPAD, the finale CHK_MEGA_FINALE_START; Sargasso's first
  visit by its arrival scene's hash (C.OPENINGS, 2498464355), else the gel factory pad.
- **No revisit before a first visit** (`hub_blocked_home`): a planet whose first visit cannot be
  played yet is never a "revisit"; the planet menu sends you back with the reason ("needs the Hurlshot
  from the story on Torren IV"). Coordinates say what they open. `]` lists the start missions, then
  first visits, then revisits, then the finale.
- **The game's own trip to an open first visit is played** (`hub_follow_new`): Nefarious City's end
  takes you to Sargasso; with its Coordinates held that is its intro, so the hub carries on there
  instead of going back.
- Kit 10.0.7; banner `Randomizer dev 10.11 (kit 10.0.7)`.

Generator 10.11.0 (`coords_first_visit = true`, a new seed setting):
- No Coordinates and no gadget a location needs on a revisit (Zurkie's 2, Sargasso 2, Savali 2) or the
  finale: the way to the next planet never runs through a revisit.
- A planet's Coordinates only where its first visit can be played the moment they are found: every
  visit it waits for is done there (a story mission, its milestone and a side activity pay when their
  visit finishes; a Gold Bolt or armor pod is found during it). Nefarious City's story counts as done
  elsewhere (the ship's travel is off while it runs). So Viceron's are a reward of Torren IV's story.
  Those Coordinates are placed first. If a seed's settings leave no such place, the nearest fit is
  used and the seed says so (`coords_exceptions`, spoiler, warnings).
- Audit and spoiler updated.

Tests: tests/test_v1011.py (20). Changed where the rules changed: version strings, round 24's
fingerprint, the guard test (now with `hub_follow_new = false`), whole campaigns (also played with
the game's trip followed), the start's reach floor 4 -> 3 items (Zurkie's revisit holds no
progression any more), the catalog's Torren IV name (the simulator lists your game's CHK_MOL_START).
449 run, 0 failures, 21 skipped; big_batch 56,600 of 56,600 valid.

## Dev 10.1 (generator 10.1.0, data 5.1.0; kit stays 10.0.6, not released): Spybots, Lorbs, three weapons as items

Asked: Spybots and Lorbs were defined as locations but the generator never used them, so make them
hold items; put the Burst Pistol, Shatterbomb and RYNO 8 into the item pool. **Nothing of this has run
in the game.** Every seed changes (new generator and data versions): start with New Game.

- Data: 10 Spybots (`spybot:1`-`spybot:10`, any planet: counted in pickup order) and 12 Lorbs
  (`lorb:1`-`lorb:12`, Savali), `holds = "any"`. CraiggerBears stay unused.
- Generator: `collectibles = true` (new setting) puts them in the location pool. They are never in
  logic (no pickup event is bound), so they hold weapons, gadgets nothing needs, armor or currency,
  never Coordinates or a gadget a location needs. With `goldbolts_first` they share the leftover items
  with missions, side activities and armor sources (rank 2).
- Weapons: acquisition `reward` for the Burst Pistol, Shatterbomb and RYNO 8: always at a location,
  never in the 15 normal shop slots, never a random start weapon (`start_items` and `exclude` still
  apply). `12_rando_shop.lua` already closes any vendor slot whose weapon the seed gives at a
  location, so Shatterbomb's and RYNO 8's own slots now show the Burst Pistol.
- The Burst Pistol is still handed out by the game in the prologue, so its reward adds nothing new;
  it is kept off Gold Bolts and early-weapon spots when another place exists, and never counts as a
  weapon `weapon_logic` waits for.
- Audit: no reward-only weapon sold or started at random; no Coordinates at a Spybot or Lorb.
- Until `05_rando_bindings.lua` `collectible_events` binds the Spybot and Lorb pickup events, what
  those 22 locations hold is not handed over in the game (KNOWN_ISSUES.md).
- tests/test_v101.py (10); older tests updated where the rules changed. 429 run, 0 failures, 21
  skipped; big_batch 56,600 of 56,600 valid.

## 10.0.5 / Public Release v0.54 (2026-11-13): planet shuffle on 0, items given back, no stale guard

Reported (round 26, v0.53, tests/data/round26_rivet.log, seed pocket-pocket-zurkie-839, a restored
save): `[` (back to the hub) is useless; after trips with `]` / `Ctrl+]` the whole inventory was
gone; some levels do not work when warped to. Asked: a key to turn the planet randomizer off and on,
remembered. **Nothing of v0.54 has run in the game.**

Round 26, what the log shows:
- The game booted on Nefarious City (the restored state: Gold Bolts 3/25, hub 4/14, `in inventory
  15`), then the save continued on Viceron. No key was pressed (no `RANDO-KEY`), no planet menu was
  used, the hub launched nothing.
- Yet: `the game's own story took you to viceron - back to the hub`, `[ORDER KEPT]`, and the trip
  back was announced. `H.on_arrival`'s guard after a finished destination compared `H.frame` with
  `h.finished_at`, which was SAVED with the hub's state; frames start at 0 in every session, so a
  finish of an earlier session held the 2-minute guard far into the next one. Every load on another
  planet early in a session was undone.
- The Viceron load replayed one gadget and **no weapon**, against 15 items the randomizer counts as
  given: that save had lost them (the user's "lost all my inventory"). The cause is not in this log.
- The banner: `Randomizer 10. - seed ...` (`R.KIT_VERSION:sub(1, 3)`).
- The shop: `only 0 vendor weapon(s) in the array at +0x48` again, and once `ran past the 8 ms frame
  budget` at the id loop of `H.discover` (line 210).

Changes:
- 15: the guards use this session's frames only (`H.session.finished_frame`); `h.finished_at` is no
  longer written and is cleared on restore.
- 15: `[` (`H.key_return`) no longer warps home; it only cancels `H.return_at`. `Ctrl+[` twice is
  unchanged. Messages that offered `[` twice now point to `]` / `Ctrl+]` or the ship.
- 15: `0` (`key_shuffle`) toggles planet shuffle (`H.set_shuffle`). Off: `H.enabled()` is false (no
  arrival handling, no pending action, no auto return, no story ladder, hub keys answer "planet
  shuffle is off"), `14 T.active()` is false (no send-back), `H.take_back_world`. On: `apply_world`
  at the hub when nothing runs. Stored as `state.planet_shuffle_off` (saved by the companion, kept by
  `R.reset_for_new_game` and the test reset); a press before the companion's restore wins
  (`H.after_restore`). Destinations still finish and pay while it is off (no trip back).
- 15: `apply_world` records the travel byte as its own only when it was off before (`r.before ~=
  1`), and `H.on_arrival` drops the record at every planet change (a load sets the save's own
  values), so turning shuffle off never turns off the game's own travel.
- 09: `G.restore_inventory(why)`: every weapon and gadget with status confirmed / owned / failed is
  queued again with `restoring`; an answer adds it back ("Given back: ..."), no answer or "inventory
  changed, nothing new" keeps it owned quietly (no tries, the target is not questioned).
  `G.watch_inventory` / `G.check_inventory`: 420 game frames after the hub's own trip lands, a
  same-planet warp, or a load on another planet with nothing running, fewer reported weapons
  (WeaponAddedEvent since the planet change) than half of the weapons known as yours (at least 2)
  restores. `restore_inventory = false` turns the check off. `Ctrl+0` twice restores by hand.
- 10: `key_shuffle = "0"`, `restore_inventory = true`; RANDO-KEYS lists `planet shuffle 0`; banner
  `Randomizer v0.54 (kit 10.0.5)` (`R.RELEASE`).
- 12: the id loop yields every 256 bytes (was 512); a failed pointer layout's reason is kept in the
  log next to the inline one; the first slot object's bytes are logged once when no slot object
  holds a vendor weapon.
- Kit 10.0.5; generator stays 10.0.2 (seeds and fingerprints unchanged).
- Tests: tests/test_v054.py (22); 13 of them fail against v0.53's scripts. test_v051's way-home test
  calls `H.go_home` (the key no longer does).

## 10.0.4 / Public Release v0.53 (2026-11-13): the boss fight's shifts find planetary travel off

Reported (round 25, v0.52's first run, tests/data/round25_rivet.log, seed pocket-pocket-zurkie-839,
a restored save at nefcity_1): Nefarious City's boss fight sends Ratchet to Sargasso or Savali in
the middle of the level; with the randomizer Ratchet landed **with the ship**, on ground that was not
solid, fell and died, several times. **Nothing of v0.53 has run in the game.**

Round 25, what the log shows:
- The city's story ran (OBJ_NEFCITY_SKIDD_*, ROOFTOP_*, BAZAAR_RETURN, TOWERPATH_*) to
  CHK_NEFCITY_HEAVY_FIGHT; then the story's own rift: PlanetChangedEvent Savali,
  CHK_NEFCITY_HEAVYSHIFT_SAVALI, "arrived on savali during nefcity_1 - the story's own travel".
- Before it, on arriving in the city, the hub had run H.apply_world: `planetary travel: done (0x0 ->
  0x1)` and `level bits 0x0 - unlocking 1-10`. After every death the city loaded again (the load
  clears both, `0x0`), the hub turned the byte on again 180 frames later, and the next shift came:
  three shifts to Savali, each with the byte on.
- The hub also announced "Nefarious City: 2 destination(s) open" on every return.

Cause (inference): the travel byte is SetPlanetaryTravelAction's, all planetary travel on or off.
The game has it off during the city's story (Ratchet has no ship yet); with it on, the shift's
planet change was played as a ship arrival at a spot whose ground the shift does not load. The
level bits (UnlockLevelAction's mask) are also set by nothing in the game at that point.

Changes (15_rando_hub.lua):
- `H.running()`: the destination being played (current, not done).
- `H.apply_world(why)`: does nothing while a destination runs (`planetary travel and level bits
  left to the game while <id> runs`). It records what it turned on in this session
  (`H.session.world`: the byte, each level bit it set).
- `H.take_back_world(why)`: the byte off and the recorded level bits cleared; called by
  `H.launch_dest` for the hub's own story (`/`, `Ctrl+]`), which is played on the planet you are on
  without a load that would clear them. A New Game forgets the record.
- `H.finish`: when the hub's own story finishes on the hub planet, `apply_world` runs (the ship's
  menu works again); returning from elsewhere runs it through `at_hub` as before.
- `H.on_arrival`: back on the hub planet from another planet, with the hub's story running and no
  trip of ours: `back on <hub> from <planet> during <id> - the story's own travel`, no hub message.
- Kit 10.0.4; generator stays 10.0.2 (seeds and fingerprints unchanged).
- Tests: `tests/test_v053.py` (8): the round 25 evidence, the shift and the return, a reload, the
  finished story, the relaunch take-back, the settings. Against v0.52's 15_rando_hub.lua five of its
  six simulator tests fail. test_v100's hub-start test now expects the byte off while the story runs.

Not changed, still open from round 25: the shop (`only 0 vendor weapon(s) in the array at +0x48`,
its weapons given directly). Round 25 is a restored save, so the opening's name is still not in a log.

## 10.0.3 / Public Release v0.52 (2026-11-13): Nefarious City's story starts at its opening scene

Reported (round 24, v0.51's first run, tests/data/round24_rivet.log): the first Nefarious City
mission did not start. Asked for: warp to the city's opening cutscene, so the cutscene then the
gameplay play. **Nothing of v0.52 has run in the game.**

Round 24, what the log shows:
- The warp came after the parade handed Ratchet back, MIS_NEFCITY_01 went inactive -> available ->
  active, the warp landed at CHK_NEFCITY_START, and OBJ_NEFCITY_GO_TO_NEFCITY went to 1. It never
  went to 2: not after the 20 s reload, not after three presses of `/` (6 warps, all to
  CHK_NEFCITY_START). Bolts and Raritanium were picked up after the warp, so Ratchet could move
  (v0.51's walking fix held).
- Round 23 (the game's own order, lines 703-729): MIS_INTRO 2 -> 4; MIS_NEFCITY_01 0 -> 2 and
  MIS_NEFCITY_01_TRAINSTATION 0 -> 1 in the same frame; the rift to NefCity; checkpoint hash
  **3046787773**; only then CHK_NEFCITY_START. In round 24 hash 3046787773 never triggered, the
  train-station mission was never opened, and the prologue was written complete only after the
  story started. CHK_NEFCITY_START is where gameplay picks up after the arrival scene, not where the
  story begins.
- The name of hash 3046787773 is in no log: round 23 had no catalog, and in round 24 nothing
  triggered that checkpoint, so no RANDO-CHECKPOINT line names it. An offline search of 528 million
  name candidates found no plausible name.

Changes:
- 03: `C.OPENINGS.nefcity_1 = { hash = 3046787773, codes = { "NEFCITY", "NEF_" }, with = {
  "MIS_NEFCITY_01_TRAINSTATION" } }`. Not in the seed's hub plan: seeds and fingerprints are
  unchanged (round 24's seed is still 2a5550ece053).
- 14: `T.find_hash(hash, filters)` names a hash from `rivet.checkpoints()` lists; the checkpoint
  catalog also runs for every hub seed.
- 15, hub start (and `Ctrl+]` / `/` for the city's story): the prologue is written complete first
  (`hub_prologue_timing = "before"`; `"after"` is v0.51's order); the story is made available and
  started; inactive `with` missions are made available; then the warp goes to the opening, found by
  its hash (known names, then the codes, then up to `H.OPENING_WAIT` = 900 frames for the catalog).
  If the game does not list it, the warp goes to CHK_NEFCITY_START as in v0.51 and the city's
  catalog is logged.
- 15, watching: a story loaded at its opening gets `H.OPENING_STUCK_WAIT` = 3600 frames before one
  reload, at the opening again (20 s could cut a cutscene short). The opening is used only while the
  story's first mission has no step yet or waits at its GO_TO step; after that, `/` loads
  CHK_NEFCITY_START as before.
- 15, logging: `opening of nefcity_1: <name> (hash ...)`, `opening of nefcity_1 loaded: ...`,
  `with nefcity_1: ...`, and every objective of the current destination's missions
  (`RANDO-HUB objective ...`; RANDO-DISCOVER stops after `discovery_cap` lines of a kind).
- 10: `hub_prologue_timing` (`"before"` | `"after"`) and `hub_opening` (`true` | `false`). 04: both
  as commented lines; your values are unchanged.
- Kit 10.0.3 (every RANDO_FILES tag, R.KIT_VERSION, C.VERSION, TT.VERSION); generator G.VERSION stays
  10.0.2.
- Tests: `tests/test_v052.py` (15): the round 23/24 evidence read from the logs, the opening path, a
  control that reproduces round 24 with `hub_opening = false`, the fallbacks, the timings. The
  simulator's opening name (`CHK_NEFCITY_OPENING_SIMULATED`) is a stand-in. test_v100's
  `hub_game` keeps its old rule (the story moves on at CHK_NEFCITY_START) as the fallback model; the
  intended order change is updated in test_v100 and test_v051.

Not changed, still open from round 24: the shop (`only 0 vendor weapon(s) in the array at +0x48`,
ARSENAL_RESTORED's vendor config, and a frame-budget overrun at 12_rando_shop.lua:210, so its
weapons were given directly) and Glitch (never confirmed by the game).

## 10.0.2 / Public Release v0.51 (2026-11-13): the hub is Nefarious City

Asked for: the hub in Nefarious City; its story must work after the warp there; Ratchet must be
able to walk right after the warp (he could not in 10.0 / v0.5). Versioning from now on: a small
fix +0.01 (this one), a major update +0.5. **Nothing of v0.51 has run in the game.**

- 03: `HUB_PLANET = "nefarious_city"`, `HUB_CHECKPOINTS = { CHK_NEFCITY_START, CHK_NEFCITY_SHIP }`,
  `HUB_STORY = "nefcity_1"`, menu order `HUB_MENU`. `HUB_START` keeps 10.0's order, so placements
  are unchanged (test_v05 compares hub seeds with 10.0 field by field, apart from the hub plan's
  planet, checkpoints and each destination's kind and label).
- 15, start: the story is made active (hero, available, start), then the warp to CHK_NEFCITY_START
  (round 23's order). The prologue is written Complete Finished once on Nefarious City
  (`hub_prologue = "end"`, as kit 8.0 did in round 17), quietly: it pays, with no return trip.
- 15, when: `hub_trigger = "parade"` waits for OBJ_INTRO_GOING_DOWN to finish (round 23: the game
  answered nothing sent to the hero during it, and 10.0 warped right at its start) and for no
  *GOING_DOWN* / *CINE* / *CUTSCENE* objective for 120 frames; 1800 frames after the wrench it goes
  anyway.
- 15, home: START while the city's story is unfinished, SHIP after it. A warp home on the hub planet
  itself no longer waits for an arrival that never comes. No return trip when the game's own travel
  has already brought you to the hub.
- Simulator: the wrench starts GOING_DOWN; `S.parade_release()`; SIMULATED rule `S.hero_held`.
- Tests: `tests/test_v051.py` (15); test_v100 rewritten for the new hub. 356 run, 0 failures.

## 10.0 (2026-11-13): the hub, planet shuffle, spread rewards, shop split from rewards

Asked for: working planet shuffle (on by default), a hub start with the prologue / Battle Arena /
Nefarious City to choose from, better reward distribution, and no weapon both earnable and for sale.
Built on 9.0 (your 8.5.2 values stay the baseline). **Nothing of 10.0 has run in the game.**

### Round 23 (9.0, your log)
- The 9.0 story start worked in game: the parade, then Nefarious City, then Sargasso, then the planet
  menu to Zurkie's. Zurkie's first visit was played; it opened `MIS_BLIZAR` and `MIS_SAV_01`.
- Planet shuffle never did anything: `campaign planet_shuffle: not available yet (missing
  mission_control, travel)`. 9.0's director waits for the lab's "verified" lines, and those had never
  been written, although round 17 had already shown the mission writes working. So the game's own
  order ran.
- The shop ran past the 8 ms frame budget again (`12_rando_shop.lua:98/182`), so the vendor was
  never changed. With ARSENAL_RESTORED's vendor still selling its weapons, Fusion Grenade and
  Combuster were bought **and** given by the randomizer.
- Armor pods, Gold Bolts and missions paid mostly Bolts/Raritanium (`rewards 10/77`).
- New finding: `CheckpointHash` is the engine's CRC-32 of the checkpoint's name (29 names your game
  listed match hashes in rounds 13-23). Round 23 shows the game loading `CHK_NEFCITY_START`
  (2052464476) for Nefarious City's story. 8.x warped to `CHK_NEFCITY_SHIP` instead, and the story
  never left `OBJ_NEFCITY_GO_TO_NEFCITY` there.

### The hub and planet shuffle (`hub = true`, the default)
- `15_rando_hub.lua` (new, 10.0): New Game → Zurkie's at the parade's wrench (round 17's verified
  warp). The prologue is left **active** and is one of three start choices, with the Battle Arena
  (`MIS_ZURK_01_VISIT_01`) and Nefarious City. `]` / `Ctrl+]` choose and go.
- A launch confirms the hero, then runs the mission ladder (active / start / write "available" then
  start, as in round 17 / replay / explore). Then it warps to where the mission really starts:
  `CHK_NEFCITY_START`, `CHK_ZURK_00_DEFAULT`, the parade's own checkpoint, or a start learned from an
  earlier run. A story still at its "go to" step after 20 s is loaded once more **on the same planet**
  (8.4 went out to Zurkie's and back, and round 22 crashed right after that).
- Planet shuffle: every other destination opens with its planet's Coordinates (items of the seed,
  anywhere) and its dependencies. The solver's reach is a fixpoint over the visits, so any order you
  pick can be finished. A finished destination pays its locations and returns you to Zurkie's. The
  game's own follow-on travel (Nefarious City → Sargasso, the prologue → Nefarious City) is undone
  (`[ORDER KEPT]`; `hub_follow_story = true` plays along instead). Round 23 shows the prologue
  turning complete on Ardolis *before* the game rifts to Nefarious City, so the warp home waits for
  the new planet's first loaded checkpoint (or 15 s), not a fixed delay after the arrival event.
- The planet menu: a locked planet sends you back to Zurkie's; an open planet starts its next
  destination. Revisits are in the `]` list.
- `14_rando_travel.lua`: every triggered checkpoint is named (`RANDO-CHECKPOINT`). The engine hash is
  in Lua, and every catalog name is hashed.
- The director (`11`) stays inert for hub seeds. `hub = false` gives 9.0's story start, unchanged.

### Rewards spread (`distribution = "spread"`, the default)
- Progression (Coordinates, gadgets) goes anywhere in logic, with no late bias. `early_weapons` (2)
  weapons and one Coordinates go where the start can reach. Everything else is shared over Gold
  Bolts, story missions, side activities and armor pods in proportion. Gold Bolts may now give
  currency; the game's own Gold Bolt still counts. `"goldbolts_first"` is the 4.0-9.0 fill.
- Over 200 default seeds, every kind of location holds items in more than 30% of its slots, and
  armor pods hold weapons.

### Shop vs rewards (`shop_weapons = 8`)
- Each weapon has exactly one route. Ms. Zurkon sells `shop_weapons` different weapons; her other
  normal slots are closed (they show the Burst Pistol, which every save owns). ARSENAL_RESTORED's
  weapons are never sold. Any slot of the vendor (ARSENAL_RESTORED's, Challenge Mode's) that sells a
  weapon the seed gives elsewhere, or that another slot already sells, is closed too.
  `shop_close_slots = false` keeps those slots.
- Frame budget: hex is parsed with one `gsub` and a lookup table plus `string.byte` (no Lua loop per
  byte). Reads are 256 bytes, a slice yields after 2 ms, and a budget error halves the read size
  instead of counting as a failed try.
- With too few locations switched on, a leftover weapon starts with you instead of having no route
  (found by the batch with random settings).

### Seeds and files
- Generator 10.0.0, format 10, share code `RA10` (RA4-RA9 refused with the reason). New settings:
  `hub`, `distribution`, `shop_weapons`, `early_weapons`. A hub seed forces `planet_locks`,
  `travel_lock` and `campaign_mode = planet_shuffle`, with a note.
- The kit has 14 scripts again. `04_rando_settings.lua` is your file plus the 10.0 lines.
  `rando_give.dll` v6 is unchanged.

### Tests
- `tests/test_v100.py` (39 tests): an independent hub-seed verifier (sphere walk, routes, early
  rewards) over 600 preset seeds and 300 random-settings seeds; distribution and order statistics;
  audit mutations. Simulated: the start menu, each of the three starts, planet shuffle, the planet
  menu, learned starts, whole campaigns (with missing missions too), the shop's closed slots,
  parse speed, budget errors, round 23's real event stream (the hub starts at the wrench), and
  round 13 (it never starts).
- The older suites run with `harness.PRE10_SETTINGS` (no hub, Gold-Bolts-first, 15 shop weapons).
- `big_batch`: 56,600 / 56,600 seeds valid (BATCH_10.0.txt).

## 9.0 (2026-11-12): no hub; the story starts as in the game

Asked for: a version without the Zurkie's hub, starting with the prologue, then Nefarious City.
Built on your edited 8.5.2 scripts (01-06, 09), which are the baseline: your defaults in 02
(`planet_locks = true`, `campaign_mode = "planet_shuffle"`, `shop_prices = "weapon"`, Raritanium
120-1,000) and Punk/Reaver owned from the start are unchanged.

### Removed: the Zurkie's hub (8.0-8.5)
- `15_rando_hub.lua` is gone. A New Game is no longer taken to Zurkie's: the parade plays on, the
  game's own rifts take you to Nefarious City, and finishing its story takes you to Sargasso. The
  randomizer moves you nowhere, writes no mission state, sets no level bits or travel flag, and
  swaps no hero. Round 22's crash followed a warp to `CHK_NEFCITY_SHIP` with the story primed from
  Cordelion (the probable cause, not proven); 9.0 makes no warp of that kind.
- Presets `hub` and `hub_chaos` are retired: they become `balanced` and `chaos`, with a note. The
  seed is then identical to the replacement preset's.
- Seed settings `hub`, `hub_start_coordinates`, `hub_unlocks`, `hub_finale`, `hub_revisits` and
  in-game options `hub_*`, `key_hub`, `key_hub_return`, `story_on_arrival`,
  `story_prime_before_travel`, `story_reload_stuck`, `key_story` are retired. Each one still in a
  settings file is named in rivet.log (`... is gone in 9.0`) and ignored.
- The story-on-arrival starter, the hero checks and the story reload lived in the hub script and
  are gone with it. Test travel (`test_travel = true`) now only moves you.
- The kit check reports a leftover `15_rando_hub.lua` from an older kit (rivet.log and on screen).
  With a 9.0 seed that file does nothing (all of it waits for a hub plan), but it binds the old keys.

### The story's start is fixed in every mission order
- `03_rando_campaign.lua`: `C.STORY_START` = the leading visits the game itself travels to
  (`arrival = "story"`): `corson_intro > nefcity_1 > sargasso_1`. Every order of every mode
  (`planet_shuffle`, `mission_shuffle`, `full`, `chaos`) begins with them; only later visits move.
- `random_start` (a campaign beginning elsewhere) is retired; `full_campaign` and `campaign_chaos`
  keep their mission shuffle with the fixed start. No mode needs `new_game_init` any more.
- The generator's audit checks the start of every campaign order.

### Seeds
- Generator 9.0.0, seed format 9, share code `RA9`. 4.0-8.5 share codes are refused with the reason.
  The generator version is in the fingerprint, so every 9.0 seed is new: start it with New Game.
- The kit's `04_rando_settings.lua` is your 8.5.2 file without its hub lines, with
  `preset = "balanced"` (your G.DEFAULTS as they stand). Your commented values are kept.
- The spoiler's hub section is replaced by a STORY START line.

### Tools and tests
- `tools/build_data.py` reproduces your 8.5.2 `01_rando_data.lua` byte for byte (Punk and Reaver
  are `findable = "start"`; their sources stay as filler-only locations, as in your file). Before
  this, re-running it reverted your edit. `data/game_db.json` matches.
- `tests/test_v90.py` (new): no hub anywhere; retired presets and settings; every mode starts with
  the prologue, Nefarious City and Sargasso; your 9.0 and 8.5.2 settings files; a New Game played to
  Sargasso with no warp, flight, mission write or hero swap; a leftover hub script reported and
  inert; the planet menu still locks planets with levels.
- The tests now pin the settings they were written for (`tests/harness.py`, CLASSIC_TEST_SETTINGS:
  no Coordinates, the game's own order, Raritanium 20-150) instead of relying on the defaults, which
  you changed in 8.5.1. A pinned value never overrides the test's own settings or its preset.
- Removed: `test_hub.py`, `test_regression_v83.py`, `test_regression_v84.py` (9.0 changes seeds on
  purpose), and the hub's story/hero tests in test_v81-v85.

## 8.5 (2026-11-12): robustness pass on 8.4

No round 21 log yet, so nothing here comes from a new game report: every fix comes from reading the
8.4 code, and each has a test in `tests/test_v85.py` that fails on 8.4 and passes on 8.5. Seeds are
identical to 8.4 (`tests/test_regression_v84.py`), saves carry over, rando_give.dll is unchanged
(same bytes as 8.3/8.4). Everything 8.4 still needs to prove in your game (KNOWN_ISSUES.md 1) is
unchanged.

### rando_give.dll requests that were given up on
- **A mission call that timed out stayed in the helper's mailbox.** If the helper then ran it
  (e.g. after a hitch), a story start or state write happened that the hub had already counted
  as failed and handled another way. 8.5 takes the request back first (the same as items and
  currency already did on a load). If the helper answered at that moment, its answer is used.
- **A loading screen counted as a timeout for mission calls** (5 s). Now a call waits while the
  game is loading and the helper's pump is not running, up to 60 s (item deliveries already waited).
- **An item request that got no answer was left in the mailbox too.** A helper that recovered
  later could deliver it on top of the retry. Now it is taken back, and the retry is the only give.
- **A New Game** takes back an item or currency payment of the old run that is still in flight, so
  it never lands in the new run.

### The companion's late restore (round 20: it connected a minute after the game)
8.4 merged only some of this session's progress into the restored save.
- Bolts/Raritanium paid in this session but not yet given are now kept (they were dropped).
- An item the game confirmed in this session is no longer reset to "queued" by the older save. That
  reset could make it be sent again.
- Armor sources and finds, the shop's one-time gifts, gadgets, the hub's objective record and the
  armor baseline are kept as well.

### New Game
- The hub's record of the old run (destinations already reloaded, stories started, the "back to
  Zurkie's" timer) is cleared. Before, a destination reloaded in the old run could not be reloaded
  automatically in the new one.
- The delivery's weapon-type session state (seen types, a purchase in flight) is cleared.
- Delayed hub actions (next mission, back to Ratchet, the hero record) look at the state when they
  run, not the state from when they were scheduled. A restore in between could make them use the
  replaced state.

### Ms. Zurkon's shop
- **Shop-only weapons had no route** when rando_give.dll was missing entirely, stopped working
  during the session, or never found the vendor in memory. The script's own description promised a
  direct gift in those cases. 8.4 only gave them for an older helper. Now all of these give the
  seed's non-vendor shop weapons once, as before.

### Smaller fixes
- A planet-menu landing on an open planet (levels seeds) is now saved right away and filtered like
  every other landing (never a `TRANSITION_TO` point).
- The history in memory is capped at 400-500 entries. The save already kept the last 60, and
  rivet.log keeps everything.
- **Companion:** a save file the game refuses (another seed's content under this seed's name) is
  copied to `rando_<fingerprint>.lua.refused-<time>` before a fresh start. Before, the next saves
  replaced it and its `.bak`, so the progress in it was lost.

## 8.4 (2026-11-12): stabilization after round 20

Built from round 20's rivet.log (kit 8.3, v2.618 install). Generator unchanged (8.0.0): every seed
is the same as in 8.3 (same fingerprint, same items; `tests/test_regression_v83.py`), so your saved
progress carries over.

### Stories that did not start, and Viceron played as Ratchet
- **Cause.** The hub trusted the hero remembered in the save (`rivet`) while the game had Ratchet.
  Every swap was then skipped ("no swap needed") or refused (`already playing as that hero`), and
  the visits ran with the wrong hero. A story's first step ("go to <planet>") finished at once with
  the visit's own hero (Ardolis, Savali, Zurkie's 1 as Ratchet) and never with the other one
  (Torren IV and Viceron as Ratchet in round 20, Nefarious City as Rivet in round 17).
- **The hero is checked with the game.** `rivet.hero_play_as` answers `already playing as that hero`
  exactly when the hero is the one asked for, so 8.4 asks again after each swap until the game
  confirms (up to 15 s). A story is started only after that. One swap request at a time.
- **Four heroes were wrong in the registry** and are fixed, from the walkthroughs and your logs:
  Nefarious City 1 → Ratchet, Sargasso 2 → Rivet, Ardolis → Ratchet, Viceron → Rivet.
- **The story is started before the trip** (`story_prime_before_travel`): a hub trip, or a test
  travel warp, switches to the visit's hero and starts its story first, so the planet loads with the
  story running (round 20: Savali, active before the warp, finished "go to" on landing).
- **A story still at "go to" 20 s after its start is reloaded once** (`story_reload_stuck`): out to
  Zurkie's (or, for Zurkie's own visits, another open planet) and straight back. Round 20's Viceron
  moved on after its reload. The story key `/` reloads again on demand.
- **8.3's automatic restart of an active story is gone.** In round 20 it changed the state but never
  moved a story (Cordelion, Zurkie's 2). Ctrl+/ twice still restarts by hand.
- **Entry points.** Viceron `CHK_ZORDOOM_START`, Cordelion `CHK_CORD_A_START`, Ardolis
  `CHK_ARD_START` (all listed by your game). A planet's story start (`CHK_<code>_START`) now ranks
  first in the checkpoint catalog; `..._COMMAND_SHIP` no longer counts as a landing.
- **Test trips no longer teach the hub a landing.** Round 20's hub trip to Torren IV went to
  `CHK_MOL_SALVAGE_PIRATES_COMMAND_SHIP`, a mid-mission point a round 19 test trip had left as
  "where you last landed". Only the ship's planet menu is remembered now; older saves' entries move
  to test travel's own list.

### Weapons
- **"weapon type 1002 ... 1012 is weapon:burst_pistol".** A load equips your weapon and then replays
  every owned weapon; 8.3 took all of them for the Burst Pistol. Now only a purchase teaches a type
  (in either event order), one type per weapon, never from a load's replay, and wrong lessons in a
  save are dropped at load. A load's replay counts as a late delivery answer only when it holds
  exactly one new type.

### Ms. Zurkon's shop
- **"only 0 vendor weapon(s) in the array at +0x48"**, every try of rounds 18-20. The vendor's slot
  list is an array of pointers to slot objects (rivet's DDL: `List<VendorItemData?>`), not of slots.
  8.4 reads the slot objects through the pointers; the old layout is still tried first.

### ARSENAL_RESTORED
- **The game itself now says the mod is installed** (Mr. Zurkon's item config loaded). Round 20's
  companion answered after the 60 s wait, so the seed was made without the mod's weapons although
  rivet_hook had loaded it. With `seed = "random"` there is no timer at all: the companion answers
  the check before it sends the seed.

### Robustness
- **Kit check.** Every script carries its kit version; the first frame logs `RANDO-KIT all 14
  scripts are 8.4.0`, or names missing files and files from another kit (on screen too).
- **The campaign key is silent in a hub seed** (round 20: the old F12 key, also Steam's screenshot
  key, put "Campaign order is not available yet" on screen).
- **rando_give.dll** is unchanged (v6, the binary rounds 17-20 ran). Its build is now reproducible:
  `build.sh` pins the link time and rebuilds the shipped DLL byte for byte.
- **Settings.** New: `story_prime_before_travel`, `story_reload_stuck` (`story_restart_stuck` is
  retired; `false` there still switches the reload off). `test_travel` is now **off** in the kit's
  settings for a real playthrough.

### Tests
- 318 automated tests, 0 failures (17 skipped: PowerShell 7 and pre-8.3 git history unavailable on
  the build machine). New: `tests/test_v84.py` (31), `tests/test_regression_v83.py` (175 seeds in 7 presets against 8.3).
- 43,000 seeds valid (`BATCH_8.4.txt`). Strict-global audit of the scripts: no stray globals.

## Randomizer 8.3: the story starts where you land, and keyboard keys

8.3 is 8.2 plus two changes from your round 19 log. Your seed and progress carry over: the
generator is still 8.0.0. Nothing here changes a fingerprint. None of 8.3 has run in your game yet.

### Why the story didn't start (round 19)

1. **Test trips did nothing by design.** In 8.2, a test trip only reported the landing. The
   Viceron, Torren IV and Cordelion landings started nothing.
2. **Cordelion's story was already "active" but stuck.** `MIS_CORD_01_FIRST_VISIT` was active
   from an earlier session, so the hub left it alone (`already active`, line 628).

The round 17 log shows why an active story can sit still. Each story mission's first objective
is "go to <planet>":

- `MIS_ZURK_01_VISIT_01` was started while you were at Zurkie's. `OBJ_ZURK_01_GO_TO_ZURKONS`
  finished 2 seconds later, and the whole story played through the arena.
- `MIS_NEFCITY_01` was started from somewhere else. `OBJ_NEFCITY_GO_TO_NEFCITY` never finished,
  even after you got to Nefarious City.

So the "go to" step is checked once, when it starts, by the planet's own level. A story started
on another planet never moves.

### What 8.3 does

- **The story on arrival** (`story_on_arrival = true`). Landing on a planet starts that planet's
  first unfinished story, even if the story before it isn't finished. This covers test travel,
  the ship's planet menu and hub trips. The hub's order is ignored for this. The story is started
  through the same ladder as before: make it available (the v6 record write) if it is inactive,
  then the game's own start, then the replay call. Rivet's stories swap the hero to Rivet first.
  Zurkie's is still the hub: its story starts with the story key or the hub key.
- **Stuck stories are restarted** (`story_restart_stuck = true`). An active story whose last step
  is "go to <planet>", or with no step seen yet, is started again on its planet: available, then
  start. If the game refuses, the record goes back to active and the replay call is tried. A
  story you are in the middle of is left alone.
- **The randomizer remembers each mission's last step** (from `ObjectiveStateChangedEvent`). This
  is saved with your progress.
- **20 seconds after a start,** if the story is still at "go to", the screen tells you to press
  the story key.
- **The story key `/`** starts the story of the planet you are on. **Ctrl+/ twice** starts it again
  from its first step, even when it's running. That is written to the history.

### Keyboard keys

| Key | Does | Old key |
|---|---|---|
| `;` | status | F9 |
| `]` / Ctrl+`]` | next destination / go there | F6 |
| `[` twice / Ctrl+`[` twice | back to Zurkie's / finish this destination by hand | F5 |
| `.` / Ctrl+`.` | test travel: next planet / warp there | F7 |
| `,` / Ctrl+`,` | test travel: next landing point / fly there | F8 |
| `/` / Ctrl+`/` twice | start this planet's story / start it again | (new) |
| `'` | experimental mission order only | F12 |

- **Every key is a setting** in `04_rando_settings.lua`. A key name can be one character
  (`]`, `/`, `K`, `7`), `NUMPAD0`–`NUMPAD9`, `INSERT`, `DELETE`, `HOME`, `END`, `PAGEUP`,
  `PAGEDOWN`, or `F1`–`F24`.
- **The old F keys still work** while `legacy_f_keys = true`.
- **rivet.log lists the keys at start** (`RANDO-KEYS`) and logs every press (`RANDO-KEY`). If a
  key does nothing and has no `RANDO-KEY` line, the game didn't pass it on. Pick another key.
- **If rivet_hook's key numbers aren't Windows key codes,** the keys go back to the F keys, with
  F4 for the story key. A `RANDO-SETTINGS ... cannot be bound here` line says so. The check is
  `rivet.key("F6") == 0x75`.

### Also seen in round 19, not changed

- **rivet_hook said `game version mismatch, invalidating pointers`** (line 3). Round 18 didn't.
  Everything still worked: events, warps, flights, deliveries. If the game updated, keep an eye
  on it.
- **The companion answered late.** The seed was made before it answered, so ARSENAL_RESTORED
  counted as not installed. That gives `kit-bolt-kit-198` → `b25846f17df5`, not round 18's
  `4d170014c0c6`. The two have separate progress files. Start the companion before the game.
- **The shop:** ARSENAL_RESTORED replaces Ms. Zurkon's config (0 vendor weapons at +0x48), as in
  round 18.

### Tests
- 285 run, 0 failed, 17 skipped: 9 need PowerShell, and 8 need the 5.0/6.0 git history.
- New: `tests/test_v83.py` (23 tests) and `tests/data/round19_rivet.log`.

## Randomizer 8.2: test travel, and the round 18 checkpoint catalog fix

8.2 is 8.1 plus two things. Your seed carries over: same generator (8.0.0), same fingerprint
(`kit-bolt-kit-198` → `4d170014c0c6` with ARSENAL_RESTORED), same saved progress. None of 8.2 has
run in your game yet.

### New: test travel (docs/TEST_TRAVEL.md)

F7 picks any planet, F8 its landing point, Ctrl+F7 warps there, Ctrl+F8 flies there with the
ship. While `test_travel = true`, nothing sends you back: not the hub, not locked levels, not
the planet menu. It opens no Coordinates. It's a runtime option, so the seed doesn't change.

### Fixed: the checkpoint catalog never finished (round 18)

| In the log | Cause | 8.2 |
|---|---|---|
| 11 × `14_rando_travel.lua:115 / 140 / 141 / 197: ran past the 8 ms frame budget`, and no `checkpoint catalog:` line | every checkpoint name was compared with every planet's every code; every sort comparison scored both names again; 128 names a frame, sharing the 8 ms with the shop and armor | codes are a table lookup per name token; areas and scores are worked out once per name; a slice stops after 1.5 ms; the best landing point is a linear pick, not a sort |

A test checks that every checkpoint name in your logs (rounds 13-18) gets the same planet as in
8.1. Another fills the catalog with 2,100 extra names and checks that it completes.

### Seen in round 18, not changed in 8.2

- **Shop:** `only 0 vendor weapon(s) in the array at +0x48`. ARSENAL_RESTORED's .stage replaces
  `configs\vendor\ven_weapon_vendor.config` (round 18 line 260), so the vendor's list isn't where
  the shop script looks. After 5 tries the shop gave you the seed's extra shop weapons directly,
  as designed.
- **Armor:** `13_rando_armor.lua:117` and `:256` ran past the frame budget, once each.
- **Pixelizer** was sent 4 times with no answer from the game.
- **This save has the whole story done** (every destination mission reads `complete`). On this
  save, hub destinations finish as soon as you arrive. Test travel is the way to try the travel
  here.

### Files

- `scripts/16_rando_testtravel.lua` (new)
- `scripts/14_rando_travel.lua` (catalog; no send-back during test travel)
- `scripts/15_rando_hub.lua` (`H.check_levels`; no send-back, keeper or startup guard during test travel)
- `scripts/10_rando_runtime.lua` (settings `test_travel`, `key_test_travel`, `key_test_point`; F9 status; KIT 8.2.0)
- `scripts/04_rando_settings.lua` (test travel on, keys F7 / F8)
- `tests/test_v82.py` (15 tests), `tests/data/round18_rivet.log`

## Randomizer 8.1: fixes from your round 17 log

8.1 is 8.0 plus fixes for what your round 17 rivet.log showed. That log came from the install
that worked (the folder named Ratchet.and.Clank.Rift.Apart.v2.618). Your seed carries over: same
fingerprint, same plan, same saved progress. None of 8.1 has run in your game yet.

### What the log showed, and what changed

| In the log | Cause | 8.1 |
|---|---|---|
| `09_rando_real.lua:672: attempt to call a nil value (global 'u32_at')` on every planet change | the line called a local defined 120 lines below it | fixed; a test now checks every script for this kind of mistake |
| `travel to torren_iv impossible: no checkpoint known` (Cordelion too) | Torren IV and Cordelion have no checkpoint named LANDING / SHIP / DEFAULT, and Cordelion's tunnel is called KEDARO, not CORD | **checkpoint catalog** (below) |
| 440 × `12_rando_shop.lua: ran past the 8 ms frame budget`; the shop never changed | the vendor search read up to 16 KB of memory and scanned it in one frame; a failure was retried forever | the search runs a slice per frame (2 reads); it gives up after 5 failed tries and hands out the shop's extra weapons instead |
| levels `unlocked 0x0` after a reload (was `0x7FE`) | a save load resets the level mask; 8.0 only set it at Zurkie's | the level bits are put back on whichever planet you load on |
| `MIS_BLIZAR_01 / MIS_CORD_BOSS / MIS_ZURK_02 / MIS_SARG_02_REVISIT / MIS_MEGA_01_RIVET: not a mission in your game` | guessed names | replaced by names your game has: MIS_BLIZAR, MIS_CORD_01_FIRST_VISIT, MIS_ZURK_02B_VISIT_02B, MIS_SARG_02_REVISIT_SHIPS, MIS_MEGA_FINALE |
| Blizar and Savali chosen in the ship's menu sent you back to Zurkie's | no Coordinates for them yet (by design) | unchanged; the message names the reason |

### The checkpoint catalog (Torren IV, Cordelion and the rest)

`rivet.checkpoints()` lists the level's checkpoints with the **area** each one is in. Round 17
shows these areas: Zurkons, Sargasso (open world), Blizar_Intact, Blizar_Destroyed, Zordoom,
Megalopolis (open world), and interplanetary_space for the planet tunnels.

From about 10 seconds after the game starts, the randomizer fills a catalog. It runs one name
filter every 4 frames, and the last filter lists everything. Each checkpoint goes on a planet by
its area first and its name second. Planet tunnels (CHK_TRANSITION_TO_…) go on none. Each
checkpoint gets a score:

- landing pad 100, landing 90, ship 80, default 70, arrival 45, entrance 40, start 35;
- −60 for each of: cinematic, boss, finale, arena, challenge, return, escape, post-mission,
  teleporter, warp-back, tunnel.

The best one is where the hub warps. rivet.log prints the result once:

    RANDO-TRAVEL checkpoint catalog: corson_v 31=..., torren_iv N=CHK_..., cordelion N=CHK_..., ...

If a trip is asked before the catalog is complete, it waits ("looking for a landing point…"),
for 30 seconds at most.

If a planet still has no checkpoint, the hub says: *"no warp point known for X yet - fly there
from the ship's planet menu"*. Every planet is in that menu (the level bits). A menu landing on a
planet you hold Coordinates for starts its destination as before, and its landing checkpoint is
**remembered**, so the next F6 / Ctrl+F6 trip there works.

Not known yet: whether the catalog's choice for Torren IV and Cordelion is a sensible place to
land. The log line above shows what was chosen, and the menu fallback always works.

### ARSENAL_RESTORED, rivet_hook version

rivet_hook loads loose mods **only** from the paths listed under `[assets] paths` in rivet.toml.
The randomizer's 8.0 rivet.toml listed only `mods/default` (your log: *mod path mods/default does
not exist! skipping*), so a copied ARSENAL_RESTORED folder was never loaded. The companion also
only looked for the Overstrike install, so its weapons stayed out of the seed.

8.1:

- **rivet.toml** lists `mods/ARSENAL_RESTORED` (a folder with info.json) and
  `mods/ARSENAL_RESTORED.stage`. A path that isn't there is skipped, so nothing breaks without the
  mod.
- **companion\Install-ArsenalRestored.bat**: drag the mod's zip onto it. It:
  - copies the mod folder (the one holding info.json) or its .stage into `<game>\mods\ARSENAL_RESTORED`;
  - copies the mod's own .lua files into `<game>\scripts`, never over a randomizer file;
  - adds the path to rivet.toml (the old one is kept as rivet.toml.bak).
- **The companion** finds the rivet_hook version through rivet.toml. If the mod sits in mods\ but
  isn't listed, the companion says so.

The zip itself was not available to this build (Google Drive can't be reached from the build
machine). The installer handles the usual layouts, but it hasn't seen this one. If it says
"nothing copied", send the zip's file list.

### Tested here (offline, simulated game)

247 tests ran: 238 passed, 0 failed, 9 skipped (the PowerShell tests: no PowerShell on the build
machine). 16 of the tests are new in 8.1 (tests/test_v81.py).
The new tests cover:

- the catalog against the 70+ checkpoints your round 17 log listed, placing each on the right
  planet;
- simulated Torren IV and Cordelion trips;
- a trip waiting for the catalog;
- a remembered menu landing;
- level bits put back after a load;
- the shop search spanning frames with at most 2 reads each;
- a failing vendor stopping after 5 tries;
- the registry and the rivet.toml paths.

PowerShell changes (companion detection, installer) are **untested**.

